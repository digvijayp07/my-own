$(function() {

	/********* Set Active Tab *********/
	function setActiveTab(thisTab) {		
		var thisId = thisTab.attr('href');
		$(document).find('.c-tabsContentBox').hide();
		$(document).find(''+thisId+'').show();
	}

		// on DOM ready call function
		var thisTab = $(document).find('.c-tabsNav li.active a');
		setActiveTab(thisTab);

		// on tab click display respective tab content
		$(document).on('click', '.c-tabsNav li a', function(e) {
			// first remove existing active
			$(document).find('.c-tabsNav li').removeClass('active');
			$(this).parent('li').addClass('active');

			setActiveTab($(this));
			e.preventDefault();
		});


	/********* Collapsable Sidebar Menu - for width less than or equal to 767 *********/
	$(document).on('click', '.c-sidebarLeftInner .c-smallHeading', function() {		
		if($(window).width() <= 767) {
			var thisId = $(this).attr('data-id');

			if($(this).find('i').hasClass('fa-plus')) {
				$(document).find(''+thisId+'').show();
				$(this).find('i').removeClass('fa-plus').addClass('fa-minus');
			}
			else {
				$(document).find(''+thisId+'').hide();
				$(this).find('i').removeClass('fa-minus').addClass('fa-plus');
			}
		}
		
	});

});
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Convertíía - A Staffing Agency</title>
	
	<?PHP include('includes/head/meta-css.php'); ?>
</head>
<body>


	<!-- Header section -->
	<header class="header-section">
		<?PHP include('includes/head/menu-top-bar.php'); ?>
	</header>
	<!-- Header section end -->


	<!-- Page header -->
	<div class="page-top-section c-pageHeroOther c-pageWeAre">
		<div class="c-overlayHeroOther"></div>
		<div class="container text-right">
			<div class="page-info">
				<h2>We Are</h2>
				<div class="page-links">
					<span>We get the people business right.</span>
				</div>
			</div>
		</div>
	</div>
	<!-- Page header end -->


	<!-- services section -->
	<div class="services-section spad">
		<div class="container">
			<div class="section-title dark">
				<h2>Brief snapshots of exactly who you'll be dealing with.</h2>
			</div>
			

			<div class="row">
				<div class="col-md-6">
					<p class="c-grayBgBox c-mediumBoldText">At Convertíía, we’ve made our home in the space between job search and hiring needs. Yes, we help great companies find the talent they need (fast!), but to us, our work means much more than that.</p>
				</div>
				<div class="col-md-6">
					<p class="mt10">We are all about loving what we do. Our commitment to, and passion for, helping our talent connect with the perfect career opportunities is what makes us successful and keeps us on the cutting edge of the staffing industry.</p>
					<p>And, despite the hours of hard work that go into making each and every match, our ultimate commitment is to providing the best customer experience possible. Simply put, we'll never refer a candidate to a job that doesn't exactly match their experience and career goals, and we don’t offer our clients talent that won’t precisely fill their hiring and cultural needs.</p>
				</div>
			</div>

		</div>
	</div>
	<!-- services section end -->


	<!-- features section -->
	<div class="team-section spad" id="why-convertiia">
		<div class="overlay"></div>
		<div class="container">
			
			<div class="row c-visionMission">
				<div class="col-md-6 col-sm-6">
					<div class="section-title">
						<h2>Our Vision</h2>
						<div class="icon light">
							<i class="flaticon-vision-1"></i>
						</div>
					</div>
				</div>
				<div class="col-md-6 col-sm-6 features">
					<div class="icon-box light">						
						<div class="service-text">
							<p>To be successful in our mission, we tirelessly seek to obtain a clear and complete understanding of our clients’ challenges and of our candidates’ strengths and preferences. We believe that only through aligning these two tiers of understanding can we ensure the mutual satisfaction of our clients and candidates — and continue to drive our own business growth.</p>
						</div>
					</div>
				</div>
			</div>

			<div class="row c-visionMission">
				<div class="col-md-6 col-sm-6">
					<div class="section-title">
						<h2>Our Mission</h2>
						<div class="icon light">
							<i class="flaticon-mountain"></i>
						</div>
					</div>
				</div>
				<div class="col-md-6 col-sm-6 features">
					<div class="icon-box light">
						<div class="service-text">
							<p>The mission of Convertíía is to help our clients achieve their business objectives in the most productive and efficient manner possible, while aligning our job candidates with opportunities that allow them to enjoy career satisfaction by attaining their professional goals.</p>
						</div>						
					</div>
				</div>
			</div>			
			
		</div>
	</div>
	<!-- features section end-->


	<!-- CONTACT-->
	<?PHP include('includes/body/cta.php'); ?>

	<!-- CONTACT-->
	<?PHP //include('includes/body/contact.php'); ?>	


	<?PHP include('includes/body/footer-js.php'); ?>
</body>
</html>

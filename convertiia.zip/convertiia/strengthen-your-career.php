<!DOCTYPE html>
<html lang="en">
<head>
	<title>Convertíía - A Staffing Agency</title>
	
	<?PHP include('includes/head/meta-css.php'); ?>
</head>
<body>


	<!-- Header section -->
	<header class="header-section">
		<?PHP include('includes/head/menu-top-bar.php'); ?>
	</header>
	<!-- Header section end -->


	<!-- Page header -->
	<div class="page-top-section c-pageHeroOther c-pageSyc">
		<div class="c-overlayHeroOther"></div>
		<div class="container text-right">
			<div class="page-info">
				<h2>Strengthen your career</h2>
				<div class="page-links">
					<span>Some text goes here</span>
				</div>
			</div>
		</div>
	</div>
	<!-- Page header end -->


	<!-- services section -->
	<div class="services-section spad">
		<div class="container">
			<div class="section-title dark">
				<h2>We're Committed to Furthering Your Career!</h2>
			</div>
			

			<div class="row">
				<div class="col-md-6">
					<p class="c-grayBgBox c-mediumBoldText">Convertíía is so much more than a staffing agency.  We match candidates with careers. Most importantly, you'll land a job that you'll want to go to on a Monday morning.</p>
				</div>
				<div class="col-md-6">
					<p>We work with our candidates on a personal level, following up with them periodically after career matches to make sure that they are enjoying their new role and feel satisfied with their career choice. Our team will help you define your goals, figure out what you want to do in life, and pair you with incredible job opportunities. We work closely with you to learn your strengths, understand your needs, and create a career path that will set you up for long-term success.</p>
				</div>
			</div>

		</div>
	</div>
	<!-- services section end -->


	<!-- services section -->
	<div class="services-section spad c-grayBgSection c-halfSectionWrapper c-sycHalfSectionImg">
		<div class="container-fluid">
		
			<div class="row">
				<div class="col-sm-12 visible-sm text-center mt-20 c-halfSectionImg">
					<img src="img/p1.jpeg" class="img-responsive">
				</div>
				<div class="col-md-6 col-sm-12 pull-right c-halfSectionText">
					<p>The job market can be difficult to navigate.  Sending a résumé to a posted job and securing a dream job isn’t that easy anymore – it takes work and we have the experience to bring you closer to that ideal position. In today’s competitive workplace environment, you need to be one step ahead of your peers. You need the advantage that Convertíía can give you.</p>
				</div>				
			</div>

		</div>
	</div>
	<!-- services section end -->


	


	<!-- CONTACT-->
	<?PHP include('includes/body/cta-strengthen-your-career.php'); ?>

	<!-- CONTACT-->
	<?PHP //include('includes/body/contact.php'); ?>	


	<?PHP include('includes/body/footer-js.php'); ?>
</body>
</html>

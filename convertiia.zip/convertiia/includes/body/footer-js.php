<!-- Footer section -->
<footer class="footer-section">
	<h2>&copy; 2018. All rights reserved <a href="https://convertiia.com" target="_blank">Convertíía</a></h2>

    <p class="c-flatIconInfo"><small>Icon made by Freepik from www.flaticon.com</small></p>
</footer>
<!-- Footer section end -->


<!-- Page Preloder -->
<div id="preloder">
	<div class="loader">
		<img src="img/convertiia-logo.png" alt="">
		<h2>Loading.....</h2>
	</div>
</div>



<!--====== Javascripts & Jquery ======-->	
<script src="js/bootstrap.min.js"></script>
<script src="js/magnific-popup.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/circle-progress.min.js"></script>

<!-- MENU -->
<script src="plugins/menu/bootsnav.js"></script>

<!-- TEXT ROTATOR -->
<script src="plugins/text-rotator/morphext.js"></script>
<script>
    $("#js-rotating").Morphext({
        animation: "rotateIn",
        complete: function () {
            console.log("This is called after a phrase is animated in! Current phrase index: " + this.index);
        }
    });
</script>

<script src="plugins/text-type/typingEffect.js"></script>

<script src="js/main.js"></script>
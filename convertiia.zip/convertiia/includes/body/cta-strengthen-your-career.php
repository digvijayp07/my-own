<!-- Promotion section -->
<div class="promotion-section">
	<i class="c-ctaIconBg flaticon-question"></i>
	<div class="container">
		<div class="row">
			<div class="col-md-9 c-ctaInfo">
				<h2>Thinking about a career move?</h2>
				<p>Don't wait – you're just a few easy steps away from a fulfilling, rewarding career path.</p>

				<div class="promo-btn-area">
					<a href="contact-us.php" class="site-btn btn-2">Let's Talk</a>
				</div>
			</div>
			<div class="col-md-3">
				
			</div>
		</div>
	</div>
</div>
<!-- Promotion section end-->
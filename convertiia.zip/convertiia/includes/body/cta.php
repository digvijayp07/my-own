<!-- Promotion section -->
<div class="promotion-section">
	<i class="c-ctaIconBg flaticon-question-2"></i>
	<div class="container">
		<div class="row">
			<div class="col-sm-9 c-ctaInfo">
				<h2>Ready to find the talent?</h2>
				<p>Contact us today. We look forward to finding you the perfect match.</p>

				<div class="promo-btn-area">
					<a href="contact-us.php" class="site-btn btn-2">Let's Talk</a>
				</div>
			</div>
			<div class="col-md-3">
				
			</div>
		</div>
	</div>
</div>
<!-- Promotion section end-->
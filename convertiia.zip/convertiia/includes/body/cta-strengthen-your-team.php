<!-- Promotion section -->
<div class="promotion-section">
	<i class="c-ctaIconBg flaticon-interview"></i>
	<div class="container">
		<div class="row">
			<div class="col-md-9 c-ctaInfo">
				<h2>Need help?</h2>
				<p>Looking to strengthen YOUR team? We’d like to get to know you.</p>

				<div class="promo-btn-area">
					<a href="contact-us.php" class="site-btn btn-2">Let's Talk</a>
				</div>
			</div>
			<div class="col-md-3">
				
			</div>
		</div>
	</div>
</div>
<!-- Promotion section end-->
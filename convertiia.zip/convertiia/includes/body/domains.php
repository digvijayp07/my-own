<!-- Services section -->
	<div class="services-section spad c-domainSectionWrap">
		<div class="container">
			<div class="section-title dark">
				<h2>We are Expert in following Domains</h2>
			</div>
			<div class="row c-ourDomains">
				<!-- single service -->
				<div class="col-md-4 col-sm-6">
					<div class="service">
						<div class="icon">
							<i class="flaticon-consulting"></i>
						</div>
						<div class="service-text">
							<h2>IT Consulting</h2>
							<p><a href="javascript:void(0);" class="read-more" data-toggle="modal" data-target="#IT-Consulting">View Domains</a></p>
						</div>
					</div>
				</div>
				<!-- single service -->
				<div class="col-md-4 col-sm-6">
					<div class="service">
						<div class="icon">
							<i class="flaticon-job-search"></i>
						</div>
						<div class="service-text">
							<h2>ERP</h2>
							<p><a href="javascript:void(0);" class="read-more" data-toggle="modal" data-target="#ERP">View Domains</a></p>
						</div>
					</div>
				</div>
				<!-- single service -->
				<div class="col-md-4 col-sm-6">
					<div class="service">
						<div class="icon">
							<i class="flaticon-warning"></i>
						</div>
						<div class="service-text">
							<h2>AERS &amp; Risk Governance</h2>
							<p><a href="javascript:void(0);" class="read-more" data-toggle="modal" data-target="#AERS">View Domains</a></p>
						</div>
					</div>
				</div>
				<!-- single service -->
				<div class="col-md-offset-4 col-md-4 col-sm-6">
					<div class="service">
						<div class="icon">
							<i class="flaticon-tax"></i>
						</div>
						<div class="service-text">
							<h2>FAS &amp; TAX</h2>
							<p><a href="javascript:void(0);" class="read-more" data-toggle="modal" data-target="#FAS">View Domains</a></p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>


	<!-- Modal - IT-Consulting -->
	<div id="IT-Consulting" class="modal fade c-customModal" role="dialog">
	  <div class="modal-dialog modal-lg">
	    <div class="modal-content">
	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal">&times;</button>
	        <h4 class="modal-title">IT Consulting</h4>
	      </div>
	      <div class="modal-body">
	        <div class="col-md-4 col-sm-6 col-xs-12">
	        	<ul>
	        		<li>.Net Developer/Manager/Architect</li>
					<li>AbInitio</li>
					<li>ADF</li>
					<li>Java/J2EE, Adobe CQ </li>
					<li>Android </li>
					<li>Application Security </li>
					<li>Apttus </li>
					<li>ASP .Net/MVC/Sitecore </li>
					<li>Associate Manager - BI &amp; applications </li>
					<li>ATG Commerce/Developer </li>
					<li>BD Presales </li>
					<li>BI Qlikview </li>
					<li>Big Machines </li>
					<li>Business Analytics</li> 
					<li>Business Valuation Associate </li>
					<li>C# Winforms </li>
					<li>Compensation Benefits</li> 
					<li>Control Assurance </li>
					<li>Core Java </li>
					<li>CP Malaysia </li>
					<li>CRM Developer </li>
					<li>Data Modelling </li>
					<li>Data Quality </li>
					<li>Data Visualization</li> 
					<li>DCPS </li>
					<li>Digital Designer</li> 
					<li>E Discovery </li>
					<li>Exigen </li>
					<li>Flex Designer</li>
	        	</ul>
	        </div>
			<div class="col-md-4 col-sm-6 col-xs-12">
	        	<ul>
	        		<li>Front End Consultant</li> 
					<li>Global Mobility </li>
					<li>Graphic Designer </li>
					<li>HRSD </li>
					<li>Hybris Ecommerce </li>
					<li>Hyperion Planning &amp; Essbase</li> 
					<li>IBM Websphere </li>
					<li>ICD AHIMA </li>
					<li>Informatica - Data Quality/MDM</li> 
					<li>Instructional Designer </li>
					<li>Interwoven Consultant</li> 
					<li>IOS Engineer</li> 
					<li>ITGC </li>
					<li>Python/Angular JS/Hybris</li> 
					<li>LAMP </li>
					<li>Mainframe </li>
					<li>MB,MQ,IBM Websphere </li>
					<li>OA PTP Functional </li>
					<li>OA SCM Distribution</li> 
					<li>OBIA/OBIEE </li>
					<li>Opentext </li>
					<li>PLSQL </li>
					<li>SCM Domain </li>
					<li>SDL Tridion Consultant</li> 
					<li>SFDC </li>
					<li>Sharepoint Functional/Technical</li> 
					<li>Siebel Development</li> 
					<li>Sitecore </li>
					<li>SQL DBA</li>
	        	</ul>
	        </div>
	        <div class="col-md-4 col-sm-6 col-xs-12">
	        	<ul>
	        		<li>UI Developer</li>
					<li>UX Designer </li>
					<li>VB Programmer </li>
					<li>Visual Designer </li>
					<li>WCS </li>
					<li>Web Developer</li> 
					<li>Websphere Developer</li> 
					<li>WMB </li>
					<li>WPS ESB </li>
					<li>Software Development Engineer</li> 
					<li>Bio Stats Lead </li>
					<li>IBM Message broker, Process server</li> 
					<li>IBM process server </li>
					<li>IBM Datapower, WebMethods</li> 
					<li>IBM WebMethods </li>
					<li>DOORS System Admin </li>
					<li>SAS Configuration </li>
					<li>Enovia </li>
					<li>IBM IIS </li>
					<li>Mongo DB </li>
					<li>BizTalk </li>
					<li>Taleo </li>
					<li>Tableau, Qlickview, Spotfire</li> 
					<li>SDL Tridion </li>
					<li>Datastage </li>
					<li>Agile </li>
					<li>Murex </li>
					<li>Endeca </li>
					<li>SSIS </li>
	        	</ul>
	        </div>

	        <div class="clearfix"></div>
	      </div>
	    </div>
	  </div>
	</div>
	<!-- END Modal - IT-Consulting -->


	<!-- Modal - ERP -->
	<div id="ERP" class="modal fade c-customModal" role="dialog">
	  <div class="modal-dialog modal-lg">
	    <div class="modal-content">
	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal">&times;</button>
	        <h4 class="modal-title">ERP</h4>
	      </div>
	      <div class="modal-body">
	        <div class="col-md-4 col-sm-6 col-xs-12">
	        	<ul>
	        		<li>ERP </li>
					<li>SAP APO, Basis, BI/BW, BPC</li> 
					<li>SAP HR, MM, SD, PP, ABAP, FICA/CO</li> 
					<li>SAP CRM/SCM </li>
					<li>SAP Oil &amp; Gas</li> 
					<li>SAP SD Vistex </li>
					<li>SAP MDG/BODS </li>
					<li>SAP MM IS Auto </li>
					<li>SD- IS Retail </li>
				</ul>
			</div>
			<div class="col-md-4 col-sm-6 col-xs-12">
	        	<ul>
					<li>SAP MM IS Retail </li>
					<li>SAP HANA, Cloud </li>
					<li>SAP CS, EWM, WM </li>
					<li>SAP Dell Boomi </li>
					<li>SAP Success Factor </li>
					<li>Oracle Demantra </li>
					<li>Oracle Fusion </li>
					<li>Oracle Apps Technical/Functional</li> 
					<li>Oracle Apps EBS RiceW </li>
				</ul>
			</div>
			<div class="col-md-4 col-sm-6 col-xs-12">
	        	<ul>					
					<li>Oracle Sales Cloud </li>
					<li>Peoplesoft Technical/Functional</li> 
					<li>JD Edwards Technical/Functional/CNC </li>
					<li>Microsoft Dynamics </li>
					<li>Workday Technical/Functional</li>
	        	</ul>
	        </div>

	        <div class="clearfix"></div>
	      </div>
	    </div>
	  </div>
	</div>
	<!-- END Modal - ERP -->


	<!-- Modal - AERS -->
	<div id="AERS" class="modal fade c-customModal" role="dialog">
	  <div class="modal-dialog modal-lg">
	    <div class="modal-content">
	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal">&times;</button>
	        <h4 class="modal-title">AERS &amp; Risk Governance</h4>
	      </div>
	      <div class="modal-body">
	        <div class="col-md-4 col-sm-6 col-xs-12">
	        	<ul>
	        		<li>AERS </li>
					<li>External Audit</li> 
					<li>Internal Audit </li>
					<li>Finance Associate </li>
					<li>Finance Domain </li>
					<li>IA Assistant Manager</li> 
					<li>IA Consultant </li>
					<li>IA Deputy Manager </li>					
					<li>IA ERS Consultant </li>
					<li>IAP Sales - Malaysia </li>
				</ul>
			</div>
			<div class="col-md-4 col-sm-6 col-xs-12">
	        	<ul>
					<li>AVA FIV &amp; S </li>
					<li>Identity &amp; Access Management (IAM)</li> 
					<li>Application Security/Assessment Services</li> 
					<li>Infrastructure Security </li>
					<li>R &amp; D </li>
					<li>Financial Instrument Valuation &amp; Securitization</li> 
					<li>USI AERS Communication Leader </li>
					<li>PDC-BPG Treasury </li>
					<li>AVP-BPO Operation </li>
				</ul>
			</div>
			<div class="col-md-4 col-sm-6 col-xs-12">
	        	<ul>					
					<li>ISMS </li>
					<li>ITGC </li>
					<li>GRR </li>
					<li>VAPT </li>
					<li>Advisory (Compliance)</li> 
					<li>ARIS </li>
					<li>Governance Compliance Control</li> 
					<li>Governance IT Control</li> 
					<li>Security Management</li>
				</ul>
			</div>
	        <div class="clearfix"></div>
	      </div>
	    </div>
	  </div>
	</div>
	<!-- END Modal - AERS -->

	<!-- Modal - FAS -->
	<div id="FAS" class="modal fade c-customModal" role="dialog">
	  <div class="modal-dialog modal-lg">
	    <div class="modal-content">
	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal">&times;</button>
	        <h4 class="modal-title">FAS &amp; TAX</h4>
	      </div>
	      <div class="modal-body">
	        <div class="col-md-4 col-sm-6 col-xs-12">
	        	<ul>
	        		<li>LHSC Sr. Analyst - Market Insights </li>
					<li>Public Sector Analyst - Market Insights </li>
					<li>Private Equity Sr. Analyst - Market Insights </li>
					<li>C &amp; IP Asst.Manager - Market Insights </li>
					<li>SBI-SAS Asst. Manager/Senior Analys </li>
					<li>Project Financials </li>
					<li>Real Estate Valuation </li>	
					<li>Senior Finance Associate - Operational Reporting &amp; Data Quality</li> 				
				</ul>
			</div>
			<div class="col-md-4 col-sm-6 col-xs-12">
	        	<ul>					
					<li>TMT Senior Analyst - Market Insights </li>
					<li>USI AERS Communication Leader </li>
					<li>Business Valuation </li>
					<li>Real Estate - Senior Assocaite</li> 
					<li>Analytics_Modelling EFM </li>
					<li>Analytics_AD </li>
					<li>Analytics_MSBI </li>
					<li>DPRS - Financial Viability, DPRS - LHSC &amp; Healthcare</li> 
				</ul>
			</div>
			<div class="col-md-4 col-sm-6 col-xs-12">
	        	<ul>					
					<li>DA Manager </li>
					<li>Strategy Development, Corporate Strategy</li> 
					<li>SBI - PE/MF/HF </li>
					<li>Content Management </li>
					<li>Competitive Intelligence</li> 
					<li>Analytics AD/MSBI </li>
					<li>UK Corporate Tax </li>
					<li>UK Individual Tax</li>
				</ul>
			</div>
	        <div class="clearfix"></div>
	      </div>
	    </div>
	  </div>
	</div>
	<!-- END Modal - FAS -->
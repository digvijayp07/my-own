<!-- Contact section -->
<div class="contact-section spad fix">
	<div class="container">
		<div class="row">
			<!-- contact info -->
			<div class="col-md-5 col-md-offset-1 contact-info col-push">
				<div class="section-title left">
					<h2>Contact us</h2>
					<p class="mt10"><i>let's have a cup of coffee together at our office.</i></p>
				</div>
				
				
				<div class="con-item">					
					<ul class="link fa-ul">
					  <li>
					  	<i class="fa-li fa fa-building"></i>
					  	Plot No. 2, Arun housing Society No. 2,  <br> Near Om Super Market, Model Colony,<br> Pune, Maharashtra, INDIA 411 016
					  </li>
					  <li><a href="mailto:hello@convertiia.com"><i class="fa-li fa fa-envelope"></i>hello@convertiia.com</a></li>
					</ul>
				</div>
			</div>
			<!-- contact form -->
			<div class="col-md-6 col-pull">
				<form name="frmResumeForm" class="form-class frmResumeForm" id="con_form" method="POST" enctype="multipart/form-data">
					<div class="row">
						<div class="col-sm-6">
							<input type="text" name="name" placeholder="Your name">
						</div>
						<div class="col-sm-6">
							<input type="text" name="email" placeholder="Your email">
						</div>
						<div class="col-sm-12">
							<input type="text" name="phone" placeholder="Your mobile number">
						</div>
						<div class="col-sm-12">
							<!-- <input type="text" name="subject" placeholder="Subject"> -->
							<!-- <input type="file" name="file_attach" id="file"> -->
							<textarea name="message" placeholder="Message"></textarea>							
							<button type="button" class="site-btn btnResumeForm">send</button>
							<img src="img/ajax-loader.gif" class="loading-img" style="display:none">
						</div>
					</div>
				</form>

				<div id="result"></div>
			</div>
		</div>
	</div>
</div>
<!-- Contact section end -->
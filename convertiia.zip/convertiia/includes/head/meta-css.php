<meta charset="UTF-8">
<meta name="description" content="Convertíía - A Staffing Agency">
<meta name="keywords" content="">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- Favicon -->
<link href="img/convertiia-logo.ico" rel="shortcut icon"/>

<!-- Google Fonts -->
<!-- <link href="https://fonts.googleapis.com/css?family=Oswald:300,400,500,700|Roboto:300,400,700" rel="stylesheet"> -->
<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800" rel="stylesheet">

<!-- Stylesheets -->
<link rel="stylesheet" href="css/bootstrap.min.css"/>
<link rel="stylesheet" href="css/font-awesome.min.css"/>
<link rel="stylesheet" href="css/flaticon.css"/>
<link rel="stylesheet" href="fonts/flaticons/flaticon.css"/>
<link rel="stylesheet" href="css/magnific-popup.css"/>
<link rel="stylesheet" href="css/owl.carousel.css"/>


<!-- MENU -->
<link href="plugins/menu/animate.css" rel="stylesheet">
<link href="plugins/menu/bootsnav.css" rel="stylesheet">
<link href="plugins/menu/style.css" rel="stylesheet">

<!-- CUSTOM CSS -->
<link rel="stylesheet" href="css/style.css"/>
<link rel="stylesheet" href="css/custom.css"/>
<!-- THEME CSS -->
<link href="css/theme-default.less" type="text/css" rel="stylesheet/less">

<!-- JS -->
<script src="js/jquery-2.1.4.min.js"></script>
<script src="js/less.min.js"></script>


<!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
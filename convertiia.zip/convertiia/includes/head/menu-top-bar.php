<!-- Start Navigation -->
	    <nav class="navbar navbar-default bootsnav navbar-fixed">

	        <!-- Start Top Search 
	        <div class="top-search">
	            <div class="container">
	                <div class="input-group">
	                    <span class="input-group-addon"><i class="fa fa-search"></i></span>
	                    <input type="text" class="form-control" placeholder="Search">
	                    <span class="input-group-addon close-search"><i class="fa fa-times"></i></span>
	                </div>
	            </div>
	        </div>-->
	        <!-- End Top Search -->

	        <div class="container">     
	        	<div class="progressContainer"><div id="progress" class="progress"></div></div>       
	            <!-- Start Atribute Navigation -->
	            <div class="attr-nav">
	                <ul>                    
	                    <!-- <li class="search"><a href="#"><i class="fa fa-search"></i></a></li> -->
	                    <li class="side-menu"><a href="javascript:void(0);"><i class="fa fa-bars"></i></a></li>
	                </ul>
	            </div>
	            <!-- End Atribute Navigation -->

	            <!-- Start Header Navigation -->
	            <div class="navbar-header logo">
	                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
	                    <a href=javascript:void(0);"><i class="fa fa-bars"></i></a>
	                </button>
	                <a href="index.php"><span class="logo-text">Convert<small>íí</small>a</span></a>
					<!--<a href="index.php"><img src="img/convertiia.png" alt="Convertiia" title="Convertiia"></a> --><!-- Logo -->
	            </div>
	            <!-- End Header Navigation -->

	            <!-- Collect the nav links, forms, and other content for toggling -->
	            <div class="collapse navbar-collapse" id="navbar-menu">
	                <ul class="nav navbar-nav navbar-right" data-in="fadeInDown" data-out="fadeOutUp">
	                    <li class="active"><a href="index.php">Home</a></li>
	                    <li><a href="we-are.php">We Are</a></li>
	                    
	                    <li class="dropdown">
	                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" >Solutions</a>
	                        <ul class="dropdown-menu">
	                            <li class="dropdown">
	                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" >People Solutions</a>
	                                <ul class="dropdown-menu">
	                                    <li><a href="solutions-staffing.php">Staffing</a></li>
	                                </ul>
	                            </li>
	                            <!-- <li class="dropdown">
	                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" >Digital Marketing</a>
	                                <ul class="dropdown-menu">
	                                    <li><a href="#">Search Engine Optimization (SEO)</a></li>
	                                    <li><a href="#">Social Media Marketing (SMM)</a></li>
	                                    <li><a href="#">Content Marketing</a></li>
	                                    <li><a href="#">Email Marketing</a></li>
	                                    <li><a href="#">Mobile Marketing</a></li>
	                                    <li><a href="#">Pay Per Click Management (PPC)</a></li>
	                                    <li><a href="#">Local SEO</a></li>
	                                </ul>
	                            </li>
	                            <li class="dropdown">
	                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" >Web Design &amp; Development</a>
	                                <ul class="dropdown-menu">
	                                    <li><a href="#">Website Designing</a></li>
	                                    <li><a href="#">Web Application Development</a></li>                                    
	                                </ul>
	                            </li> -->
	                        </ul>
	                    </li>
	                    <li><a href="strengthen-your-team.php">Strengthen Your Team</a></li>
	                    <li><a href="strengthen-your-career.php">Strengthen Your Career</a></li>
	                    <li><a href="contact-us.php">Let's Talk</a></li>
	                </ul>
	            </div><!-- /.navbar-collapse -->
	        </div>   

	        <!-- Start Side Menu -->
	        <div class="side">
	            <a href="#" class="close-side"><i class="fa fa-times"></i></a>
	            <div class="widget">
	                <h6 class="title">say hello</h6>
	                <p><i>let's have a cup of coffee together at our office.</i></p>
	                <ul class="link fa-ul">
					  <li>
					  	<i class="fa-li fa fa-building"></i>
					  	Plot No. 2, Arun housing Society No. 2,  <br> Near Om Super Market, Model Colony<br> Pune, Maharashtra, INDIA 411 016
					  </li>
					  <li><a href="mailto:hello@convertiia.com"><i class="fa-li fa fa-envelope"></i>hello@convertiia.com</a></li>
					</ul>
	            </div>
	        </div>
	        <!-- End Side Menu -->
	    </nav>
	    <!-- End Navigation -->

	    <div class="clearfix"></div>
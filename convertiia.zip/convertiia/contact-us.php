<!DOCTYPE html>
<html lang="en">
<head>
	<title>Convertiia - A Staffing Agency</title>
	
	<?PHP include('includes/head/meta-css.php'); ?>
</head>
<body>
	


	<!-- Header section -->
	<header class="header-section">
		<?PHP include('includes/head/menu-top-bar.php'); ?>
	</header>
	<!-- Header section end -->



	<!-- Page header -->
	<div class="page-top-section c-pageHeroOther c-pageContact">
		<div class="c-overlayHeroOther"></div>
		<div class="container text-right">
			<div class="page-info">
				<h2>Contact</h2>
				<div class="page-links">
					<span>Some text goes here</span>
				</div>
			</div>
		</div>
	</div>
	<!-- Page header end -->

	<!-- CONTACT-->
	<?PHP include('includes/body/contact.php'); ?>	

	<!-- Google map -->
	<div id="map-area">
		<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3782.9117419917393!2d73.83189961426804!3d18.532890073635816!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc2bf79657e8c07%3A0xbcc41bcaeb55c3a7!2sOm+Super+Market!5e0!3m2!1sen!2sin!4v1524885195181" width="600" height="450" frameborder="0" style="border:0; width: 100%;" allowfullscreen></iframe>
	</div>

	


	<?PHP include('includes/body/footer-js.php'); ?>
</body>
</html>

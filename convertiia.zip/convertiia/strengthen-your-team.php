<!DOCTYPE html>
<html lang="en">
<head>
	<title>Convertíía - A Staffing Agency</title>
	
	<?PHP include('includes/head/meta-css.php'); ?>
</head>
<body>


	<!-- Header section -->
	<header class="header-section">
		<?PHP include('includes/head/menu-top-bar.php'); ?>
	</header>
	<!-- Header section end -->


	<!-- Page header -->
	<div class="page-top-section c-pageHeroOther c-pageSyt">
		<div class="c-overlayHeroOther"></div>
		<div class="container text-right">
			<div class="page-info">
				<h2>Strengthen your team</h2>
				<div class="page-links">
					<span>Some text goes here</span>
				</div>
			</div>
		</div>
	</div>
	<!-- Page header end -->


	<!-- services section -->
	<div class="services-section spad">
		<div class="container">
			<div class="section-title dark">
				<h2>Our process is built around YOU!</h2>
			</div>
			

			<div class="row">
				<div class="col-md-6">
					<p class="c-grayBgBox c-mediumBoldText">We pride ourselves on providing comprehensive solutions for all areas of hiring. You can always rely on us to strengthen your team.</p>
				</div>
				<div class="col-md-6">
					<p>From the very first conversation, our team takes the time to understand your organization’s culture and your hiring manager’s individual needs. We rely on our knowledge of your business to connect you with the top industry talent within the region. We believe our team-based approach, extensive network, and sound process deliver the best results possible. Our Recruitment Specialists and Executive search consultants are the best the region has to offer.</p>
				</div>
			</div>

		</div>
	</div>
	<!-- services section end -->


	<!-- features section -->
	<div class="team-section spad c-grayBgSection">
		<div class="overlay"></div>
		<div class="container">
			<div class="section-title dark">
				<h2>Get Everything You Need from One Source</h2>
			</div>
			<div class="row">
				<div class="col-md-12">
					<p class="c-mediumBoldText">
						Strong, close relationships with our partners give Convertíía behind-the-scenes knowledge about what heads of companies and department heads need from new talent. 
					</p>
					<p>
						We have the unique ability to outfit your brand with virtually everything you need, including:
					</p>

					<div class="row c-sytListBoxes">
							<!-- Single -->
							<div class="col-md-3 col-sm-6">
								<div class="icon-box">
									<div class="icon">
										<i class="flaticon-interview"></i>
									</div>
									<div class="icon-box-text">
										<h2>Direct Hire</h2>
									</div>
								</div>
							</div>
							<!-- Single -->
							<div class="col-md-3 col-sm-6">
								<div class="icon-box">
									<div class="icon">
										<i class="flaticon-human-resources"></i>
									</div>
									<div class="icon-box-text">
										<h2>Executive Search</h2>
									</div>
								</div>
							</div>
							<!-- Single -->
							<div class="col-md-3 col-sm-6">
								<div class="icon-box">
									<div class="icon">
										<i class="flaticon-pen"></i>
									</div>
									<div class="icon-box-text">
										<h2>Contract – Hire</h2>
									</div>
								</div>
							</div>
							<!-- Single -->
							<div class="col-md-3 col-sm-6">
								<div class="icon-box">
									<div class="icon">
										<i class="flaticon-cash-money"></i>
									</div>
									<div class="icon-box-text">
										<h2>Payrolling</h2>
									</div>
								</div>
							</div>
						</div>

					<p>
						With years of talent sourcing experience, we know exactly how to find the ideal candidate for your unique needs. Convertíía partners with companies in all industries, pairing talent with the ideal careers for their skill sets, experience, education level and goals, and desires. We customize searches that include writing job descriptions and sourcing candidates.
					</p>
				</div>
			</div>
		</div>
	</div>
	<!-- features section end-->


	<!-- services section -->
	<div class="services-section spad c-halfSectionWrapper c-sytHalfSectionImg">
		<div class="container-fluid">
		
			<div class="row">
				<div class="col-sm-12 visible-sm text-center mt-20 c-halfSectionImg">
					<img src="img/p2.jpg" class="img-responsive">
				</div>
				<div class="col-md-6 col-sm-12 pull-right c-halfSectionText">
					<p>No matter what position you're trying to fill, Convertíía has a candidate who not only fits the mold, but also wants to be there. Our secret lies in talent retention – we cultivate close relationship with our candidates to facilitate genuine job satisfaction. We’ll find the right hire for you each and every time.</p>
				</div>				
			</div>

		</div>
	</div>
	<!-- services section end -->


	<!-- CONTACT-->
	<?PHP include('includes/body/cta-strengthen-your-team.php'); ?>

	<!-- CONTACT-->
	<?PHP //include('includes/body/contact.php'); ?>	


	<?PHP include('includes/body/footer-js.php'); ?>
</body>
</html>

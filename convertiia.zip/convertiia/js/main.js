/* =================================
------------------------------------
	Labs - Design Studio
	Version: 1.0
 ------------------------------------ 
 ====================================*/

'use strict';

/*------------------
	Preloder
--------------------*/
function loader() {
	$(window).on('load', function() { 
		$(".loader").fadeOut(); 
		$("#preloder").delay(400).fadeOut("slow");
	});
}



/*------------------
	Navigation
--------------------*/
function responsive() {
	// Responsive 
	$('.responsive').on('click', function(event) {
		$('.menu-list').slideToggle(400);
		event.preventDefault();
	});
}



/*------------------
	Hero Section
--------------------*/
function heroSection() {
	//Slide item bg image.
	$('.hero-item').each(function() {
		var image = $(this).data('bg');
		$(this).css({
			'background-image'  : 'url(' + image + ')',
			'background-size'   : 'cover',
			'background-repeat' : 'no-repeat',
			'background-position': 'center bottom'
		});
	});
	//slider auto height 
	var iit = setInterval(slide_item, 1);

	function slide_item() {
		var bh = $('body').height();
		$('.hero-item').height(bh);
	}
	slide_item();

	var time = 5;
	var $progressBar,
		$bar, 
		$elem, 
		isPause, 
		tick,
		percentTime;

	// Init the carousel
	$('#hero-slider').owlCarousel({
		loop: true,
		nav: true,
		items: 1,
		autoHeight:true,
		animateOut: 'fadeOut',
		animateIn: 'fadeIn',
		navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
		onInitialized: progressBar,
		onTranslated: moved,
		onDrag: pauseOnDragging
	});

	// Init progressBar where elem is $("#owl-demo")
	function progressBar(){    
		// build progress bar elements
		//buildProgressBar();

		// start counting
		//start();
	}

	// create div#progressBar and div#bar then prepend to $("#owl-demo")
	function buildProgressBar(){
		$progressBar = $("<div>",{
			id:"progressBar"
		});
		$bar = $("<div>",{
			id:"bar"
		});
		$progressBar.append($bar).prependTo($("#hero-slider"));
	}

	function start() {
		// reset timer
		percentTime = 0;
		isPause = false;
		// run interval every 0.01 second
		tick = setInterval(interval, 10);
	};

	function interval() {
		if(isPause === false){
			percentTime += 1 / time;

			$bar.css({
				width: percentTime+"%"
			});

			// if percentTime is equal or greater than 100
			if(percentTime >= 100){
				// slide to next item 
				$("#hero-slider").trigger("next.owl.carousel");
				percentTime = 0; // give the carousel at least the animation time ;)
			}
		}
	}

	// pause while dragging 
	function pauseOnDragging(){
		isPause = true;
	}

	// moved callback
	function moved(){
		// clear interval
		clearTimeout(tick);
		// start again
		start();
	}

}



/*------------------
	Video Popup
--------------------*/
function videoPopup() {
	$('.video-popup').magnificPopup({
		type: 'iframe',
		autoplay : true
	});
}



/*------------------
	Testimonial
--------------------*/
function testimonial() {
	// testimonial Carousel 
	$('#testimonial-slide').owlCarousel({
		loop:true,
		autoplay:true,
		margin:30,
		nav:false,
		dots: true,
		responsive:{
			0:{
				items:1
			},
			600:{
				items:2
			},
			800:{
				items:2
			},
			1000:{
				items:2
			}
		}
	});
}



/*------------------
	Progress bar
--------------------*/
function progressbar() {

	$('.progress-bar-style').each(function() {
		var progress = $(this).data("progress");
		var prog_width = progress + '%';
		if (progress <= 100) {
			$(this).append('<div class="bar-inner" style="width:' + prog_width + '"><span>' + prog_width + '</span></div>');
		}
		else {
			$(this).append('<div class="bar-inner" style="width:100%"><span>' + prog_width + '</span></div>');
		}
	});
}



/*------------------
	Accordions
--------------------*/
function accordions() {
	$('.panel').on('click', function (e) {
		$('.panel').removeClass('active');
		var $this = $(this);
		if (!$this.hasClass('active')) {
			$this.addClass('active');
		}
		e.preventDefault();
	});
}



/*------------------
	Progress Circle
--------------------*/
function progressCircle() {
	//Set progress circle 1
	$("#progress1").circleProgress({
		value: 0.75,
		size: 175,
		thickness: 5,
		fill: "#2be6ab",
		emptyFill: "rgba(0, 0, 0, 0)"
	});
	//Set progress circle 2
	$("#progress2").circleProgress({
		value: 0.83,
		size: 175,
		thickness: 5,
		fill: "#2be6ab",
		emptyFill: "rgba(0, 0, 0, 0)"
	});
	//Set progress circle 3
	$("#progress3").circleProgress({
		value: 0.25,
		size: 175,
		thickness: 5,
		fill: "#2be6ab",
		emptyFill: "rgba(0, 0, 0, 0)"
	});
	//Set progress circle 4
	$("#progress4").circleProgress({
		value: 0.95,
		size: 175,
		thickness: 5,
		fill: "#2be6ab",
		emptyFill: "rgba(0, 0, 0, 0)"
	});

}

(function($) {
	// Call all functions
	loader();
	responsive();
	heroSection();
	testimonial();
	progressbar();
	videoPopup();
	accordions();
	progressCircle();

})(jQuery);


/* CUSTOM */
// detect scroll & append class to body
$(window).scroll(function(){
	if($(this).scrollTop() > 0){
	   $('body').removeClass('c-menuFixed');
	}
	else {
		$('body').addClass('c-menuFixed');
	}
});

/// fill progress bar as user scrolls the page down. The progress bar gets filled as per page's length scroll
function updateProgress(num1, num2){
  var percent = Math.ceil( num1 / num2 * 100 ) + '%';
  document.getElementById('progress').style.width = percent;
}

window.addEventListener('scroll', function(){
  var top = window.scrollY;
  var height = $(document)["0"].body.scrollHeight - window.innerHeight
  updateProgress(top, height);
});


// SEND RESUME
$(".btnResumeForm").click(function() { 
        //get input field values
        var user_name       = $('input[name=name]').val(); 
        var user_email      = $('input[name=email]').val();
        var user_phone      = $('input[name=phone]').val();
		//var attach_file     = $('input[name=file_attach]')[0].files[0];
        var user_message    = $('textarea[name=message]').val();
        
        //simple validation at client's end
        //we simply change border color to red if empty field using .css()
        var proceed = true;
        if(user_name==""){ 
            $('input[name=name]').css('border','1px solid red'); 
            $('input[name=name]').focus();
            proceed = false;
        }
        else if(user_email==""){ 
            $('input[name=email]').css('border','1px solid red'); 
            $('input[name=email]').focus();
            proceed = false;
        }
        else if(user_phone=="") {    
            $('input[name=phone]').css('border','1px solid red'); 
            $('input[name=phone]').focus();
            proceed = false;
        }
        else if(user_message=="") {  
            $('textarea[name=message]').css('border','1px solid red'); 
            $('textarea[name=message]').focus();
            proceed = false;
        }
        // else if(attach_file == undefined) {
        // 	$('input[name=file_attach]').css('border','1px solid red'); 
        // 	proceed = false;
        // }
        else {
        	proceed = true;
        }

        //everything looks good! proceed...
        if(proceed) 
        {
			$(".loading-img").show(); //show loading image
			$(".submit_btn").hide(); //hide submit button
			
			//data to be sent to server			
			var post_data = new FormData();    
			post_data.append( 'userName', user_name );
			post_data.append( 'userEmail', user_email );
			post_data.append( 'userPhone', user_phone );
			post_data.append( 'userMessage',user_message);
			//post_data.append( 'file_attach', attach_file );
			
			//instead of $.post() we are using $.ajax()
			//that's because $.ajax() has more options and can be used more flexibly.
			$.ajax({
			  url: 'send-resume.php',
			  data: post_data,
			  processData: false,
			  contentType: false,
			  type: 'POST',
			  dataType:'json',
			  success: function(data){
			  	var output;
					//load json data from server and output message     
					if(data.type == 'error')
					{
						output = '<div class="error">'+data.text+'</div>';
					}else{
						output = '<div class="success">'+data.text+'</div>';
						
						//reset values in all input fields
						$('.frmResumeForm input').val(''); 
						$('.frmResumeForm textarea').val(''); 
					}
					
					$("#result").hide().html(output).slideDown(); //show results from server
					$(".loading-img").hide(); //hide loading image
					$(".submit_btn").show(); //show submit button
			  }
			});

        }
    });
    
    //reset previously set border colors and hide all message on .keyup()
    $(".frmResumeForm input, .frmResumeForm textarea").keyup(function() { 
        $(".frmResumeForm input, .frmResumeForm textarea").css('border-color',''); 
        $("#result").slideUp();
    });




    ///// HOME TEXT TYPING
    $("#typed2").typing({
        strings: ['Staffing', 'UI/UX', 'Digital Marketing', 'Data Mining'],
        eraseDelay: 10,
        typeDelay: 70,
        stringStartDelay: 4000,
        color: 'white',
        typingColor: 'black',
        typingOpacity: '0.1',
        loopCount: 1000,
        cursorBlink: false,
        cursorChar: '<small>_</small>',
        fade: true,
        onTyping: function () {
            console.log('onTyping');
        },
        onFinishedTyping: function () {
            console.log('onFinishedTyping');
            var abc = $('#typed2').text();

            if(abc == 'Staffing') {
                $('.owl-item .item.hero-item').css('background-image', 'url(img/slider/staffing.jpg)');
            }
            else if(abc == 'UI/UX') {
                $('.owl-item .item.hero-item').css('background-image', 'url(img/slider/uiux.jpg)');
            }
            else if(abc == 'Digital Marketing') {
                $('.owl-item .item.hero-item').css('background-image', 'url(img/slider/digital-marketing.jpg)');
            }
            else if(abc == 'Data Mining') {
                $('.owl-item .item.hero-item').css('background-image', 'url(img/slider/research.jpg)');
            }                        
            
        },
        onErasing: function () {
            console.log('onErasing');
        },
        onFinishedErasing: function () {
            console.log('onFinishedErasing');
        },
        onAllTypingCompleted: function () {
            console.log('onAllTypingCompleted');            
        },
        onFinishedFadeErasing: function () {
            console.log('onFinishedFadeErasing');
        }
    });
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Convertíía - A Staffing Agency</title>
	
	<?PHP include('includes/head/meta-css.php'); ?>
</head>
<body>
	


	<!-- Header section -->
	<header class="header-section">

		<?PHP include('includes/head/menu-top-bar.php'); ?>

	</header>
	<!-- Header section end -->


	<!-- Intro Section -->
	<div class="hero-section">
		<div class="c-overlayHero"></div>
		<div class="hero-content">
			<div class="hero-center">				
				<!-- CURRENT <p><span>Leaders in</span><br> <span id="js-rotating">Staffing., Data Mining., UI/UX., Digital Marketing.</span></p> -->
				<!-- OLD 1 <p><span id="js-rotating">Leaders in, Staffing., Data Mining., UI/UX., Digital Marketing.</span></p> -->


				<p>
					<span>Leaders in</span><br>
		        	<span id="typed2"></span>
		        	<span class="cursor"></span>
		        </p>
			</div>
		</div>
		<!-- slider -->

		<div id="hero-slider" class="owl-carousel">			
			<div class="item  hero-item" data-bg="img/slider/staffing.jpg"></div>
			<!-- <div class="item  hero-item" data-bg="img/02.jpg"></div> -->
		</div>
	</div>
	<!-- Intro Section -->


	<!-- About section -->
	<div class="about-section">
		<div class="overlay"></div>
		<!-- card section -->
		<div class="card-section">
			<div class="container">
				<div class="row">
					<!-- single card -->
					<div class="col-md-4 col-sm-6">
						<a href="strengthen-your-career.php">
						<div class="lab-card">
							<div class="icon">
								<i class="flaticon-interview"></i>
							</div>
							<h2>For Jobseekers</h2>
							<p>We work closely with you to learn your strengths, understand your needs, and create a career path that will set you up for long-term success.</p>
							<a href="strengthen-your-career.php" class="c-boxArrow"><i class="flaticon-right-arrow"></i></a>
						</div>
						</a>
					</div>
					<!-- single card -->
					<div class="col-md-4 col-sm-6">
						<a href="strengthen-your-team.php">
						<div class="lab-card">
							<div class="icon">
								<i class="flaticon-company"></i>
							</div>
							<h2>For Employers</h2>
							<p>We believe our team-based approach, extensive network, and sound process deliver the best results possible.</p>
							<a href="strengthen-your-team.php" class="c-boxArrow"><i class="flaticon-right-arrow"></i></a>
						</div>
						</a>
					</div>
					<!-- single card -->
					<div class="col-md-4 col-sm-12">
						<a href="we-are.php#why-convertiia">
						<div class="lab-card">
							<div class="icon">
								<i class="flaticon-question"></i>
							</div>
							<h2>Why Convertíía?</h2>
							<p>Convertíía is so much more than a staffing agency. We match candidates with careers. We are here to strengthen your team.</p>
							<a href="we-are.php#why-convertiia" class="c-boxArrow"><i class="flaticon-right-arrow"></i></a>
						</div>
						</a>
					</div>
				</div>
			</div>
		</div>
		<!-- card section end-->


		<!-- About contant -->
		<div class="about-contant">
			<div class="container">
				<!-- <div class="section-title">
					<h2>We are <span>Convertíía</span></h2>
				</div> -->
				<div class="row">
					<div class="col-md-12">
						<p><span class="c-inlineBigText">Welcome to Convertíía</span>, where we deliver the right people solutions so you can tackle your toughest business challenges. With deep recruiting expertise in virtually every industry we’re able to pinpoint your resource needs and provide solutions that match the right people, to the right job, at the right time. At Convertíía we get the people business right.</p>
					</div>
					<div class="col-md-12">
						<!-- <blockquote> --><p>From temporary staffing to direct hire… from long-term consulting to project based staffing… we craft flexible, targeted solutions to your staffing needs.<br>
						Find out why we're one of the most-recommended and top-performing staffing resource providers in the nation.</p><!-- </blockquote> -->
					</div>
				</div>
				<div class="text-right mt20">
					<a href="we-are.php" class="site-btn">Know More</a>
				</div>
				<!-- popup video -->
				<!-- <div class="intro-video">
					<div class="row">
						<div class="col-md-8 col-md-offset-2 c-introVideoWrapper">
							<img src="img/video.jpg" alt="">

							<p>
								In recruiting, there are no good or bad experiences - just learning experiences.
								<br>
								<a href="contact-us.php" class="site-btn">Let's start new experience</a>
							</p>
							
						</div>
					</div>
				</div> -->

				
			</div>
		</div>
	</div>
	<!-- About section end -->


	<!-- TESTIMONIALS-->
	<?PHP //include('includes/body/testimonials.php'); ?>



	<!-- DOMAIN SECTION-->
	<?PHP include('includes/body/domains.php'); ?>


	<!-- Team Section -->
	<!--<div class="team-section spad">
		<div class="overlay"></div>
		<div class="container">
			<div class="section-title">
				<h2>Get in <span>the Lab</span> and  meet the team</h2>
			</div>
			<div class="row">
				<div class="col-sm-4">
					<div class="member">
						<img src="img/team/1.jpg" alt="">
						<h2>Christinne Williams</h2>
						<h3>Project Manager</h3>
					</div>
				</div>
				single member
				<div class="col-sm-4">
					<div class="member">
						<img src="img/team/2.jpg" alt="">
						<h2>Christinne Williams</h2>
						<h3>Junior developer</h3>
					</div>
				</div>
				<div class="col-sm-4">
					<div class="member">
						<img src="img/team/3.jpg" alt="">
						<h2>Christinne Williams</h2>
						<h3>Digital designer</h3>
					</div>
				</div>
			</div>
		</div>
	</div>-->
	<!-- Team Section end-->


	<!-- CTA-->
	<?PHP include('includes/body/cta.php'); ?>


	<!-- CONTACT-->
	<?PHP //include('includes/body/contact.php'); ?>


	<?PHP include('includes/body/footer-js.php'); ?>




</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>Convertíía - A Staffing Agency</title>
	
	<?PHP include('includes/head/meta-css.php'); ?>
</head>
<body>


	<!-- Header section -->
	<header class="header-section">
		<?PHP include('includes/head/menu-top-bar.php'); ?>
	</header>
	<!-- Header section end -->


	<!-- Page header -->
	<div class="page-top-section c-pageHeroOther c-pageSolStaffing">
		<div class="c-overlayHeroOther"></div>
		<div class="container text-right">
			<div class="page-info">
				<h2>Staffing</h2>
				<div class="page-links">
					<span>Some text goes here</span>
				</div>
			</div>
		</div>
	</div>
	<!-- Page header end -->


	<!-- services section -->
	<div class="services-section spad">
		<div class="container">
			<div class="section-title dark">
				<h2>Convertíía - Leaders in staffing</h2>
			</div>
			

			<div class="row">
				<div class="col-md-12">
					<p class="c-mediumBoldText">We pride ourselves on providing comprehensive solutions for all areas of hiring. You can always rely on us to strengthen your team. Our core focus is the placement of mid to executive level professionals in three distinct capacities.</p>
				</div>

				<div class="col-md-6">
					<div class="site-accordions">
						<div class="panel-group" id="accordion">
							<!-- Single Accordions -->
							<div class="panel">
								<div class="panel-heading">
									<h4 class="panel-title">Retained Search</h4>
									<a data-toggle="collapse" data-parent="#accordion" href="#accordion1"></a>
								</div>
								<div id="accordion1" class="panel-collapse collapse">
									<div class="panel-body">
										<p>Our Executive level searches are conducted in a retained capacity.  Our retained searches are confidential, highly specialized, and conducted on a national scale. Our Executive Search Consultants have a deep understanding of the industries we service and are able to give you access to a network of passive talent that is unparalleled in the region.  We ascertain how a candidate's experience and skills align with your position and company culture ensuring you make the right hire for the long term.</p>
									</div>
								</div>
							</div>
							<!-- Single Accordions -->
							<div class="panel">
								<div class="panel-heading">
									<h4 class="panel-title">Contingency Search</h4>
									<a data-toggle="collapse" data-parent="#accordion" href="#accordion2"></a>
								</div>
								<div id="accordion2" class="panel-collapse collapse">
									<div class="panel-body">
									<p>We conduct the majority of our mid- to senior-level placements on a contingency basis. We use our thorough understanding of our service areas and strategic partnerships to align businesses and candidates with one another in a timely manner. We pride ourselves on cultivating deep-rooted relationships throughout the nation and have unparalleled access to talent throughout all the region.</p>
									</div>
								</div>
							</div>
							<!-- Single Accordions -->
							<div class="panel">
								<div class="panel-heading">
									<h4 class="panel-title">Professional Staffing</h4>
									<a data-toggle="collapse" data-parent="#accordion" href="#accordion3"></a>
								</div>
								<div id="accordion3" class="panel-collapse collapse">
									<div class="panel-body">
									<p>We also specialize in the sourcing, screening, and placement of skilled professionals, with a focus in IT &amp; ERP, Banking &amp; Finance, Oil &amp; Gas Industry verticals. We can help with your permanent, contract, contract-to-hire, and project-related needs.</p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="col-md-6">
					<p class="c-grayBgBox mt40">With years of talent sourcing experience, we know exactly how to find the ideal candidate for your unique needs. Convertíía partners with companies in all industries, pairing talent with the ideal careers for their skill sets, experience, education level and goals, and desires. We customize searches that include writing job descriptions and sourcing candidates.</p>
				</div>
			</div>

		</div>
	</div>
	<!-- services section end -->


	<!-- PROCESS -->
	<div class="services-section spad c-grayBgSection">

		<div class="container">
			<div class="section-title dark">
				<h2>Our Process</h2>
			</div>
			

			<div class="row">
				<div class="col-md-12">
					<!-- Progress bars -->
					<div class="col-md-12">
						<div class="single-progress-item p1">							
							<div class="progress-bar-style" data-progress="20"></div>
							<p>1. Understanding the requirements</p>
						</div>
						<div class="single-progress-item p2">
							<div class="progress-bar-style" data-progress="30"></div>
							<p>2. Musts, ideals, keywords, and search strings</p>
						</div>
						<div class="single-progress-item p3">
							<div class="progress-bar-style" data-progress="40"></div>
							<p>3. Customizing searches</p>
						</div>
						<div class="single-progress-item p4">
							<div class="progress-bar-style" data-progress="50"></div>
							<p>4. Explore the huge internal database to find "The Right One"</p>
						</div>
						<div class="single-progress-item p5">
							<div class="progress-bar-style" data-progress="60"></div>
							<p>5. Passive search through exclusive sourcing team</p>
						</div>
						<div class="single-progress-item p6">
							<div class="progress-bar-style" data-progress="80"></div>
							<p>6. Exclusive Head Hunting to target organizations</p>
						</div>
						<div class="single-progress-item p7">
							<div class="progress-bar-style" data-progress="100"></div>
							<p>7. QA of resumes before delivery</p>
						</div>
						
					</div>
				</div>
			</div>
		</div>
		
	</div>
	<!-- END PROCESS -->


	<!-- DOMAIN SECTION-->
	<?PHP include('includes/body/domains.php'); ?>

	
	<!-- TESTIMONIALS -->
	<?PHP //include('includes/body/testimonials-other.php'); ?>

	<!-- CTA-->
	<?PHP include('includes/body/cta.php'); ?>

	<!-- CONTACT-->
	<?PHP //include('includes/body/contact.php'); ?>	


	<?PHP include('includes/body/footer-js.php'); ?>
</body>
</html>

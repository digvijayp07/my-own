myApp.controller('dashboardCtrl', dashboardCtrl);

function dashboardCtrl($scope, $rootScope, $http, $location, localStorageService, $timeout, myConfig) {	
	
	// set page title
    $rootScope.pageTitle = 'Dashboard | Operator';
	
	// set session and view type(login or after login).. so that related view is rendered
	$rootScope.setViewType('afterLogin');
	$rootScope.sessionActive = true;
	
	//console.log('Dashboard Controller');	
	//// init
	init();
	function init() {
		initPlugins();
		
		// check session
		$timeout(function() {
			$scope.checkSessionExists();
		}, 0);
	}
	
}
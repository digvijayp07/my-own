myApp.controller('accountCtrl', accountCtrl);

function accountCtrl($scope, $rootScope, $http, $location, localStorageService, $timeout, myConfig) {	
	
	// set page title
    $rootScope.pageTitle = 'My Account | Operator';
	
	// set session and view type(login or after login).. so that related view is rendered
	$rootScope.setViewType('afterLogin');
	$rootScope.sessionActive = true;
	
	//console.log('Account Controller');
	//// init
	init();
	function init() {
		initPlugins();
		
		// check session
		$timeout(function() {
			$scope.checkSessionExists();
		}, 0);
	}
	
}
<div class="sidebar-nav slimscrollsidebar">	
	<ul class="nav" id="side-menu">
		<li style="padding: 70px 0 0;">
			<a ng-href="#/dashboard/" data-urls="#/dashboard" 
				class="waves-effect c-brad4"><i class="flaticon-dashboard" aria-hidden="true"></i>Dashboard</a>
		</li>
		<li>
			<a ng-href="#/myAccount/" data-urls="#/myAccount,#/editAccount" 
				class="waves-effect c-brad4"><i class="flaticon-id-card" aria-hidden="true"></i>My Account</a>
		</li>
		<li>
			<a ng-href="#/myCustomers/" data-urls="#/myCustomers" 
				class="waves-effect c-brad4"><i class="flaticon-team" aria-hidden="true"></i>My Customers</a>
		</li>
		<li>
			<a ng-href="#/packageRequests/" data-urls="#/packageRequests" 
				class="waves-effect c-brad4"><i class="flaticon-technology-1" aria-hidden="true"></i>Package Requests</a>
		</li>
		<li>
			<a ng-href="#/bills/" data-urls="#/bills" 
				class="waves-effect c-brad4"><i class="flaticon-invoice" aria-hidden="true"></i>Bills</a>
		</li>
		<li>
			<a ng-href="#/complaints/" data-urls="#/complaints" 
				class="waves-effect c-brad4"><i class="flaticon-speech-bubble" aria-hidden="true"></i>Complaints</a>
		</li>
		<li>
			<a href="javascript:void(0);" ng-click="userLogout();" 
				class="waves-effect c-brad4"><i class="flaticon-power-sign" aria-hidden="true"></i>Log Out</a>
		</li>
	</ul>	
</div>
<!DOCTYPE html>
<html lang="en" ng-app="myApp"  ng-controller="applicationCtrl">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/ico" sizes="16x16" href="../plugins/images/favicon.ico">
	
	    
	<title ng-bind="pageTitle"></title>

    
	<!-- Bootstrap Core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <!-- Menu CSS -->
    <link href="../plugins/sidebar-nav/sidebar-nav.min.css" rel="stylesheet">
    <!-- toast CSS -->
    <link href="../plugins/toast-master/jquery.toast.css" rel="stylesheet">
    
    <!-- animation CSS -->
    <link href="../css/animate.css" rel="stylesheet">
	
	<!-- POPOVER -->
    <link href="../plugins/popover/bootstrap-popover-x.min.css" rel="stylesheet">
	
    <!-- Style CSS -->
    <link href="../css/style.css" rel="stylesheet">	
	
	<link href="../css/flaticon.css" rel="stylesheet">
	
    <!-- color CSS -->
    <link href="../css/colors/default.css" id="theme" rel="stylesheet">
	
	<!-- Custom CSS -->
    <link href="../css/custom.css" rel="stylesheet">
    
	
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
		<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
	<![endif]-->
</head>

<body class="fix-header show-sidebar" ng-class="viewType == 'beforeLogin' ? 'c-loginPageBody' : ''">
    
	
	<!-- Before Login -->
    <div id="wrapper" ng-if="!sessionActive" ng-class="{{viewType}}">
		<div id="page-wrapper" class="c-loginPagesWrapper">
			
			<div class="c-loginPageWrapperInner">

				<div class="col-md-3 col-sm-4 col-xs-12 c-loginSideBox">
					<div class="c-overlay"></div>
					<div class="c-loginSideContent">
						<div class="c-loginLogo">
							<i class="flaticon-technology"></i> cabl
						</div>
						
						<div class="c-loginQuote">
							<p>Connecting hearts<br />via cabl</p>
						</div>
						
					</div>
					<div class="c-loginSideFooter" ng-bind-html="footerCopyright"></div>
				</div>
				<div class="col-md-9 col-sm-8 col-xs-12 c-loginMainBox">
					<div class="c-loginMainContent">
						<div class="c-loginMainContentInner" ng-view>
							
						</div>
					</div>
				</div>

			</div>
			
		</div>
    </div>
    <!-- End Before Login -->
	
	
    <!-- After Login -->
    <div id="wrapper" ng-if="sessionActive" ng-class="{{viewType}}">
        <!-- Topbar header - style you can find in pages.scss -->
        <nav class="navbar navbar-default navbar-static-top m-b-0 c-mainNavbar" ng-include="'includes/head/topbar.php'"></nav>
        <!-- End Top Navigation -->        
		
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <div class="navbar-default sidebar" role="navigation" ng-include="'includes/body/sidebar.php'"></div>
        <!-- End Left Sidebar -->
        
        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid" ng-view>
				
            </div>
            <footer class="footer text-center c-mainFooter" ng-include="'includes/body/footer.php'"></footer>
        </div>
        <!-- End Page Content -->
    </div>
    <!-- End After Login -->
	
	
	
	
	
    	
	
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="../js/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="../js/bootstrap.min.js"></script>
	
	<!-- Menu Plugin JavaScript -->
    <script src="../plugins/sidebar-nav/sidebar-nav.min.js"></script>
    <!--slimscroll JavaScript -->
    <script src="../js/jquery.slimscroll.js"></script>
    <!--Wave Effects -->
    <script src="../js/waves.js"></script>    	
	<!-- POPOVER -->
    <script src="../plugins/popover/bootstrap-popover-x.js"></script>
	<!-- ALERTIFY -->
	<script src="plugins/alertify/alertify.min.js"></script>
    
	
	<!-- Angular Dependencies -->
	<script src="../js/angular.min.js"></script>
	<script src="../js/angular-local-storage.min.js"></script>	
	<script src="../js/angular-sanitize.js"></script>
	<script src="../js/angular-route.js"></script>
	
	<!-- Angular controllers -->
	<script src="../scripts/app.js"></script>
	<script src="scripts/config/routeConfig.js"></script>
	<script src="../scripts/controller/applicationCtrl.js"></script>
	<script src="scripts/controller/dashboardCtrl.js"></script>
	<script src="scripts/controller/accountCtrl.js"></script>
	<script src="scripts/controller/complaintsCtrl.js"></script>
	<script src="scripts/controller/billsCtrl.js"></script>
	<script src="scripts/controller/customersCtrl.js"></script>
	
	<!-- Custom Theme JavaScript -->
    <script src="../js/custom.js"></script>
</body>

</html>

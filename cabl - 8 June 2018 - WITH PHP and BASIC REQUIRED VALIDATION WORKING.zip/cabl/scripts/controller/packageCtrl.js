myApp.controller('packageCtrl', packageCtrl);

function packageCtrl($scope, $rootScope, $http, $location, localStorageService, $timeout, myConfig) {	
	
	// set page title
    $rootScope.pageTitle = 'My Package';
	
	// set session and view type(login or after login).. so that related view is rendered
	$rootScope.setViewType('afterLogin');
	$rootScope.sessionActive = true;
	
	//console.log('Package Controller');
	//// init
	init();
	function init() {
		initPlugins();
		
		// check session
		$timeout(function() {
			$scope.checkSessionExists();
		}, 0);
	}
	
}
myApp.controller('loginCtrl', loginCtrl);

function loginCtrl($scope, $rootScope, $http, $location, localStorageService, $timeout, myConfig) {	
	
	// set page title
    $rootScope.pageTitle = 'Login';	
	
	// set session and view type(login or after login).. so that related view is rendered
	$rootScope.setViewType('beforeLogin');
	$rootScope.sessionActive = false;
	
	// set scope variables
	$scope.frmUserLoginData = {};
	
	//console.log('Login Controller');
	//// init
	init();
	function init() {
		initPlugins();
		
		// check session
		if(localStorageService.get("userDetails") == null || localStorageService.get("userDetails") == undefined) {
			//$location.path('/login');			
		}
		else {
			$rootScope.login.userSessionDetails = localStorageService.get("userDetails");
			$location.path('/dashboard');	
		}			
	}
	
	
	//--------------------------------------------------------------//
	//***************** User Login *******************//
	//------------------------------------------------------------//
	$scope.userLogin = function(frmLogin, formData) {
		$scope.isFormValid = false;
		
		if(frmLogin.$valid) {
			$scope.isFormValid = true;
			
			$http({
				url: 'php/userLogin.php', 
				method: "POST",
				data: {
						httpRequest: 'userLogin',
						customerId: formData.customerId,
						password: formData.password					
				},
				headers : {
						'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
				}
			})
			.success(function(data){	
			    //console.log(data);
				if(data.statusCode == 200) {
					alertify.success(data.statusMessage);
					
					// set user data in rootscope variable
					$rootScope.login.userSessionDetails = data[0];					
					localStorageService.set('userDetails', $rootScope.login.userSessionDetails);			
					
					// reset form data
					$scope.frmUserLoginData = angular.copy({});
					$scope.frmLogin.$setPristine();
					$scope.frmLogin.$setUntouched();
					$scope.frmLogin.$rollbackViewValue();
					
					$timeout(function() {
						$location.path("/dashboard");
					}, 2000);
				}
				
				if(data.statusCode == 400) {
					alertify.error(data.statusMessage);
				}
			});
		}
		else {
			$scope.isFormValid = false;
		}
		
	}
	//--------------------------------------------------------------//
	
}
-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 08, 2018 at 02:09 PM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_cabl`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `id` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `isOnline` int(1) NOT NULL DEFAULT '0',
  `isActive` int(1) NOT NULL DEFAULT '0',
  `createdDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `password`, `isOnline`, `isActive`, `createdDate`) VALUES
('1', 'a8f5f167f44f4964e6c998dee827110c', 0, 1, '2018-06-07 05:34:05'),
('2', 'a8f5f167f44f4964e6c998dee827110c', 0, 1, '2018-06-07 05:35:50'),
('3', 'a8f5f167f44f4964e6c998dee827110c', 0, 1, '2018-06-07 05:37:15'),
('4', 'a8f5f167f44f4964e6c998dee827110c', 0, 1, '2018-06-08 13:34:18');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users_info`
--

CREATE TABLE `tbl_users_info` (
  `id` varchar(50) NOT NULL,
  `firstName` varchar(50) DEFAULT NULL,
  `middleName` varchar(50) DEFAULT NULL,
  `lastName` varchar(50) DEFAULT NULL,
  `countryCode` varchar(5) DEFAULT NULL,
  `mobileNumber` bigint(12) DEFAULT NULL,
  `address` varchar(250) DEFAULT NULL,
  `createdDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` varchar(50) DEFAULT NULL,
  `modifiedDate` timestamp NULL DEFAULT NULL,
  `modifiedBy` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_users_info`
--

INSERT INTO `tbl_users_info` (`id`, `firstName`, `middleName`, `lastName`, `countryCode`, `mobileNumber`, `address`, `createdDate`, `createdBy`, `modifiedDate`, `modifiedBy`) VALUES
('1', 'Digvijay', 'K', 'Patil', '+91', 9970804658, 'Phulewadi', '2018-06-07 00:04:05', '1', '2018-06-07 00:04:05', '1'),
('2', 'Rohan', 'S', 'Gaikwad', '+91', 8788451147, 'Hari Om Nagar', '2018-06-07 00:05:50', '2', '2018-06-07 00:05:50', '2'),
('3', 'Sangram', 'S', 'Patil', '+91', 8888221144, 'Shivaji Peth', '2018-06-07 00:07:15', '3', '2018-06-07 00:07:15', '3'),
('4', 'Sachin', 'Ramesh', 'Tendulkar', '+91', 1010101010, 'Mumbai', '2018-06-07 20:04:18', '4', '2018-06-07 20:04:18', '4');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_users_info`
--
ALTER TABLE `tbl_users_info`
  ADD PRIMARY KEY (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

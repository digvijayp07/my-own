<div class="row bg-title">
	<div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
		<h4 class="page-title">My Bills</h4> 
	</div>		
	<!--<div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
		<a href="https://wrappixel.com/templates/ampleadmin/" target="_blank" class="btn btn-danger pull-right m-l-20 hidden-xs hidden-sm waves-effect waves-light">Upgrade to Pro</a>			
	</div>-->
</div>
<!-- /.row -->
<!-- .row -->
<div class="row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="white-box c-myBillsWrapper c-brad4 p-0">
			
			<div class="c-tableFilters c-brad4">
				<div class="c-filterBtnGroup c-btnGroupMonth">
					<h5>Year</h5>
					<div class="btn-group" role="group">
					  <button type="button" class="btn btn-default btn-sm"><i class="fa fa-angle-left"></i></button>
					  <!--<div class="btn-group" role="group">
						<button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						  May
						  <span class="caret"></span>
						</button>
						<ul class="dropdown-menu">
						  <li><a href="#">January</a></li>
						  <li><a href="#">February</a></li>
						  <li><a href="#">March</a></li>
						  <li><a href="#">April</a></li>
						  <li><a href="#">May</a></li>
						  <li><a href="#">June</a></li>
						  <li><a href="#">July</a></li>
						  <li><a href="#">August</a></li>
						  <li><a href="#">September</a></li>
						  <li><a href="#">October</a></li>
						  <li><a href="#">November</a></li>
						  <li><a href="#">December</a></li>
						</ul>
					  </div>-->
					  <div class="btn-group" role="group">
						<button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						  2018
						  <span class="caret"></span>
						</button>
						<ul class="dropdown-menu">
						  <li><a href="#">2015</a></li>
						  <li><a href="#">2016</a></li>
						  <li><a href="#">2017</a></li>
						  <li><a href="#" class="active">2018</a></li>
						</ul>
					  </div>
					  <button type="button" class="btn btn-default btn-sm"><i class="fa fa-angle-right"></i></button>
					</div>
				</div>
				<div class="c-filterBtnGroup c-btnGroupPaymentMode">
					<h5>Payment Mode</h5>
					<div class="btn-group" role="group">					  
					  <div class="btn-group" role="group">
						<button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						  Select
						  <span class="caret"></span>
						</button>
						<ul class="dropdown-menu">
						  <li><a href="#">Cash</a></li>
						  <li><a href="#">Debit Card</a></li>
						</ul>
					  </div>
					</div>
				</div>
			</div>
			
			<div class="table-responsive c-customTable">
				<table class="table">
					<thead>
						<tr>
							<th width="100">Bill No.</th>							
							<th width="150">Month</th>
							<th width="150">Status</th>
							<th width="200">Payment Mode</th>
							<th width="100">Amount</th>
							<th width="150">Date</th>
							<th width="150">By</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td width="100">0006</td>
							<td width="150">June</td>
							<td width="150"><span class="badge badge-warning">Unpaid</span></td>
							<td width="200">
								<div>
									<button type="button" data-target="#c-payMyBillModal" data-toggle="modal" class="btn btn-default text-info btn-rounded btn-sm">Pay Now</button>
								</div>
							</td>
							<td width="100">250.00</td>
							<td width="150">-</td>
							<td width="150">-</td>
						</tr>
						<tr>
							<td width="100">0005</td>
							<td width="150">May</td>
							<td width="150"><span class="badge badge-danger">Failed</span></td>
							<td width="200">
								<div>
									<button type="button" data-target="#c-payMyBillModal" data-toggle="modal" class="btn btn-default text-info btn-rounded btn-sm">Pay Now</button>
								</div>
								<div>
									<button type="button" data-target="#c-allInOneModal" data-toggle="modal" class="btn btn-link btn-sm text-info p-0">Details</button>
								</div>
							</td>
							<td width="100">250.00</td>
							<td width="150">30 May, 2018</td>
							<td width="150">Rana Da</td>
						</tr>
						<tr>
							<td width="100">0004</td>
							<td width="150">April</td>
							<td width="150"><span class="badge badge-success">Paid</span></td>
							<td width="200">Debit Card 
								<div>
									<button type="button" data-target="#c-allInOneModal" data-toggle="modal" class="btn btn-link btn-sm text-info p-0">Details</button>
								</div>
							</td>
							<td width="100">250.00</td>
							<td width="150">29 Apr, 2018</td>
							<td width="150">Rana Da</td>
						</tr>
						<tr>
							<td width="100">0003</td>
							<td width="150">March</td>
							<td width="150"><span class="badge badge-success">Paid</span></td>
							<td width="200">Cash</td>
							<td width="100">250.00</td>
							<td width="150">28 Mar, 2018</td>
							<td width="150">Rana Da</td>
						</tr>
						<tr>
							<td width="100">0002</td>
							<td width="150">February</td>
							<td width="150"><span class="badge badge-success">Paid</span></td>
							<td width="200">Cash</td>
							<td width="100">250.00</td>
							<td width="150">27 Feb, 2018</td>
							<td width="150">Rana Da</td>
						</tr>
						<tr>
							<td width="100">0001</td>
							<td width="150">January</td>
							<td width="150"><span class="badge badge-success">Paid</span></td>
							<td width="200">Cash</td>
							<td width="100">250.00</td>
							<td width="150">29 Jan, 2018</td>
							<td width="150">Rana Da</td>
						</tr>
					</tbody>
				</table>
			</div>
			
		</div>
	</div>
</div>
<!-- /.row -->


<!-- MODAL BILL DETAILS -->
<div id="c-allInOneModal" class="modal fade c-customModal">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header"> 
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">X</button>
				<h4 class="modal-title text-info">Bill Details (May-0005)</h4>
			</div>
			<div class="modal-body">
				
				<div class="c-infoKeyValWrapper">
					<div class="c-infoKeyValRow">
						<div class="c-infoKey col-md-3 col-sm-4 col-xs-12">Date &amp; Time</div>
						<div class="c-infoVal col-md-9 col-sm-8 col-xs-12">29 Apr, 2018 @10:30 AM</div>
					</div>
					<div class="c-infoKeyValRow">
						<div class="c-infoKey col-md-3 col-sm-4 col-xs-12">Payment Mode</div>
						<div class="c-infoVal col-md-9 col-sm-8 col-xs-12">Debit Card</div>
					</div>
					<div class="c-infoKeyValRow">
						<div class="c-infoKey col-md-3 col-sm-4 col-xs-12">Transaction ID</div>
						<div class="c-infoVal col-md-9 col-sm-8 col-xs-12">123456789</div>
					</div>					
					<div class="c-infoKeyValRow">
						<div class="c-infoKey col-md-3 col-sm-4 col-xs-12">Bank Name</div>
						<div class="c-infoVal col-md-9 col-sm-8 col-xs-12">HDFC Bank Ltd.</div>
					</div>
					<div class="c-infoKeyValRow">
						<div class="c-infoKey col-md-3 col-sm-4 col-xs-12">Card's Last 4 Digit</div>
						<div class="c-infoVal col-md-9 col-sm-8 col-xs-12">XXXX-XXXX-XXXX-5458</div>
					</div>
					<div class="c-infoKeyValRow">
						<div class="c-infoKey col-md-3 col-sm-4 col-xs-12">Transaction Status</div>
						<div class="c-infoVal col-md-9 col-sm-8 col-xs-12"><span class="badge badge-success">Success</span></div>
					</div>
					<div class="c-infoKeyValRow">
						<div class="c-infoKey col-md-3 col-sm-4 col-xs-12">Amount</div>
						<div class="c-infoVal col-md-9 col-sm-8 col-xs-12">250.00</div>
					</div>
				</div>
				
				
			</div>
			<div class="modal-footer c-singleBtn">  
				<button type="button" class="btn btn-info c-btnAction" id="" data-dismiss="modal">Okay</button>
			</div>
		</div>
	</div>
</div>
<!-- END MODAL BILL DETAILS -->



<!-- MODAL PAY MY BILL -->
<div id="c-payMyBillModal" class="modal fade c-customModal">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header"> 
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">X</button>
				<h4 class="modal-title text-info">Bill Payment (June-0006)</h4>
			</div>
			<div class="modal-body">
				
				<div class="c-infoKeyValWrapper">
					<div class="c-infoKeyValRow">
						<div class="c-infoKey col-md-3 col-sm-4 col-xs-12">Amount</div>
						<div class="c-infoVal col-md-9 col-sm-8 col-xs-12">250.00</div>
					</div>
				</div>

				<div class="c-paymentFormModal">
					<form class="form-horizontal form-material">
						<div class="form-group">
							<label class="col-md-3 col-sm-4 col-xs-12">Payment Mode</label>
							<div class="col-md-9 col-sm-8 col-xs-12">
								<label class="radio-inline m-r-10"><input type="radio" name="txtPayMode" value="cash" data-target-div="c-pmodeCashDiv" class="c-txtPayMode"> Cash</label>
								<label class="radio-inline m-r-10"><input type="radio" name="txtPayMode" value="debit card" data-target-div="c-pmodeDebitDiv" class="c-txtPayMode"> Debit Card</label>
								<label class="radio-inline m-r-10"><input type="radio" name="txtPayMode" value="credit card" data-target-div="c-pmodeCreditDiv" class="c-txtPayMode"> Credit Card</label>								
							</div>
						</div>
						
						<div class="c-pmodeDiv c-pmodeCashDiv">
							<div class="form-group">
								<label class="col-md-3 col-sm-4 col-xs-12">Amount</label>
								<div class="col-md-9 col-sm-8 col-xs-12">
									<input type="text" name="txtPaidAmount" class="form-control" value="250.00" readonly="readonly" disabled="disabled">								
								</div>
							</div>
						</div>
						
						<div class="c-pmodeDiv c-pmodeDebitDiv">
							<div class="form-group">
								<label class="col-md-3 col-sm-4 col-xs-12">Bank Name</label>
								<div class="col-md-9 col-sm-8 col-xs-12">
									<input type="text" name="txtBankName" class="form-control">								
								</div>
							</div>
							<div class="form-group">
								<label class="col-md-3 col-sm-4 col-xs-12">Card Holder Name</label>
								<div class="col-md-9 col-sm-8 col-xs-12">
									<input type="text" name="txtCardHolderName" placeholder="As per card" class="form-control">								
								</div>
							</div>
							<div class="form-group">
								<label class="col-md-3 col-sm-4 col-xs-12">Card Type</label>
								<div class="col-md-9 col-sm-8 col-xs-12">
									<select class="form-control form-control-line">
										<option value="">Select</option>
										<option value="">American Express</option>
										<option value="">RuPay</option>
										<option value="">Master Card</option>
										<option value="">Visa</option>										
									</select>						
								</div>
							</div>
							<div class="form-group">
								<label class="col-md-3 col-sm-4 col-xs-12">Card Number</label>
								<div class="col-md-9 col-sm-8 col-xs-12">
									<div class="col-md-3 col-sm-3 col-xs-3 p-l-0 c-cardNumberInput">
										<input type="text" name="txtCardNo1" class="form-control" placeholder="XXXX" maxlength="4">
									</div>
									<div class="col-md-3 col-sm-3 col-xs-3 p-l-0 c-cardNumberInput">
										<input type="text" name="txtCardNo2" class="form-control" placeholder="XXXX" maxlength="4">
									</div>
									<div class="col-md-3 col-sm-3 col-xs-3 p-l-0 c-cardNumberInput">
										<input type="text" name="txtCardNo3" class="form-control" placeholder="XXXX" maxlength="4">
									</div>
									<div class="col-md-3 col-sm-3 col-xs-3 p-l-0 c-cardNumberInput">
										<input type="text" name="txtCardNo4" class="form-control" placeholder="XXXX" maxlength="4">
									</div>
								</div>
							</div>
							<div class="form-group">
								<label class="col-md-3 col-sm-4 col-xs-12">Expiry Date</label>
								<div class="col-md-9 col-sm-8 col-xs-12">
									<div class="col-md-2 col-sm-3 col-xs-3 p-l-0 c-expiryDateInput">
										<input type="text" name="txtExpiryMonth" class="form-control" placeholder="XX" maxlength="2">
									</div>
									<div class="col-md-2 col-sm-3 col-xs-3 p-l-0">
										<input type="text" name="txtExpiryYear" class="form-control" placeholder="XX" maxlength="2">
									</div>
								</div>
							</div>
							<div class="form-group">
								<label class="col-md-3 col-sm-4 col-xs-12">CVV Code</label>
								<div class="col-md-3 col-sm-4 col-xs-4">
									<input type="password" name="txtCvv" class="form-control" placeholder="XXX" maxlength="3">
								</div>
							</div>							
						</div>
						
						<div class="c-pmodeDiv c-pmodeCreditDiv">
							<div class="form-group">
								<label class="col-md-3 col-sm-4 col-xs-12">Bank Name</label>
								<div class="col-md-9 col-sm-8 col-xs-12">
									<input type="text" name="txtBankName" class="form-control">								
								</div>
							</div>
							<div class="form-group">
								<label class="col-md-3 col-sm-4 col-xs-12">Card Holder Name</label>
								<div class="col-md-9 col-sm-8 col-xs-12">
									<input type="text" name="txtCardHolderName" placeholder="As per card" class="form-control">								
								</div>
							</div>
							<div class="form-group">
								<label class="col-md-3 col-sm-4 col-xs-12">Card Type</label>
								<div class="col-md-9 col-sm-8 col-xs-12">
									<select class="form-control form-control-line">
										<option value="">Select</option>
										<option value="">American Express</option>
										<option value="">RuPay</option>
										<option value="">Master Card</option>
										<option value="">Visa</option>										
									</select>						
								</div>
							</div>
							<div class="form-group">
								<label class="col-md-3 col-sm-4 col-xs-12">Card Number</label>
								<div class="col-md-9 col-sm-8 col-xs-12">
									<div class="col-md-3 col-sm-3 col-xs-3 p-l-0 c-cardNumberInput">
										<input type="text" name="txtCardNo1" class="form-control" placeholder="XXXX" maxlength="4">
									</div>
									<div class="col-md-3 col-sm-3 col-xs-3 p-l-0 c-cardNumberInput">
										<input type="text" name="txtCardNo2" class="form-control" placeholder="XXXX" maxlength="4">
									</div>
									<div class="col-md-3 col-sm-3 col-xs-3 p-l-0 c-cardNumberInput">
										<input type="text" name="txtCardNo3" class="form-control" placeholder="XXXX" maxlength="4">
									</div>
									<div class="col-md-3 col-sm-3 col-xs-3 p-l-0 c-cardNumberInput">
										<input type="text" name="txtCardNo4" class="form-control" placeholder="XXXX" maxlength="4">
									</div>
								</div>
							</div>
							<div class="form-group">
								<label class="col-md-3 col-sm-4 col-xs-12">Expiry Date</label>
								<div class="col-md-9 col-sm-8 col-xs-12">
									<div class="col-md-2 col-sm-3 col-xs-3 p-l-0 c-expiryDateInput">
										<input type="text" name="txtExpiryMonth" class="form-control" placeholder="XX" maxlength="2">
									</div>
									<div class="col-md-2 col-sm-3 col-xs-3 p-l-0">
										<input type="text" name="txtExpiryYear" class="form-control" placeholder="XX" maxlength="2">
									</div>
								</div>
							</div>
							<div class="form-group">
								<label class="col-md-3 col-sm-4 col-xs-12">CVV Code</label>
								<div class="col-md-3 col-sm-4 col-xs-4">
									<input type="password" name="txtCvv" class="form-control" placeholder="XXX" maxlength="3">
								</div>
							</div>							
						</div>
						
						<div class="form-group">
							<label class="col-md-3 col-sm-4 col-xs-12">Narration</label>
							<div class="col-md-9 col-sm-8 col-xs-12">
								<input type="text" name="txtNarration" class="form-control" value="">								
							</div>
						</div>
						
						<div class="form-group">
							<label class="col-md-3 col-sm-4 col-xs-12">Paid By</label>
							<div class="col-md-9 col-sm-8 col-xs-12">
								<input type="text" name="txtPaidBy" class="form-control" value="Rana Da">								
							</div>
						</div>
					</form>
				</div>
				
			</div>
			<div class="modal-footer c-singleBtn">  
				<button type="button" class="btn btn-info c-btnAction" id="" data-dismiss="modal">Pay Now</button>
			</div>
		</div>
	</div>
</div>
<!-- END MODAL PAY MY BILL -->
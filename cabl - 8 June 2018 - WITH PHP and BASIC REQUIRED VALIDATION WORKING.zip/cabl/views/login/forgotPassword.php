<div class="c-loginHeading">
	<h3>Recover Password</h3>
	<p>Enter your 8 digit Customer ID to reset your password.</p>
</div>
<div class="c-loginForm">
	<form class="form-material">
		<div class="form-group">
			<label for="inputId">Customer ID</label>
			<input type="text" name="customerid" class="form-control" id="inputId" placeholder="e.g. 00001234">
		</div>
		
		<div class="form-group text-center">
			<button type="submit" class="btn btn-info btn-rounded c-btnMain">Submit</button>
		</div>
		<div class="c-forgotPassword">Know your password? <a ng-href="#/login/">Sign in</a></div>
	</form>					
</div>
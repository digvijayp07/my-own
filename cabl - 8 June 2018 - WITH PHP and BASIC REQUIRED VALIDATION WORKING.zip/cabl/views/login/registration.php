<div class="c-loginHeading">
	<h3>Registration</h3>
	<p>This is your first step towards connecting with us.</p>
</div>
<div class="c-loginForm">
	<form class="form-material c-frmRegisterNewUser" name="frmRegisterNewUser" method="POST" novalidate>
		<div class="form-group">
			<label>Customer ID <span class="c-requiredSign">*</span></label> <!-- value="CUST-{{customerId}}" -->
			<div class="input-group">
                <span class="input-group-addon c-width45">
					<input type="text" class="form-control" 
					name="txtPrefix" 
					value="CUST-" 
					readonly="readonly" 
					disabled="disabled">
				</span>
				<input type="text" class="form-control" 
				name="txtCustomerId" 
				ng-model="frmRegistrationData.customerId" 
				readonly="readonly" 
				disabled="disabled">
			</div>
		</div>
		<div class="form-group">
			<label>First Name <span class="c-requiredSign">*</span></label>
			<input type="text" class="form-control" 
			name="txtFirstName" 
			ng-model="frmRegistrationData.firstName" 
			required 
			tabindex="1">
			
			<div class="c-errorMessages" ng-show="(frmRegisterNewUser.txtFirstName.$invalid)">
				<p ng-show="(frmRegisterNewUser.txtFirstName.$touched && frmRegisterNewUser.txtFirstName.$error.required) || (frmRegisterNewUser.txtFirstName.$error.required && isFormValid==false)">First Name is required</p>
			</div>
		</div>
		<div class="form-group">
			<label>Middle Name</label>
			<input type="text" class="form-control" 
			name="txtMiddleName" 
			ng-model="frmRegistrationData.middleName" 
			tabindex="2">
		</div>
		<div class="form-group">
			<label>Last Name <span class="c-requiredSign">*</span></label>
			<input type="text" class="form-control" 
			name="txtLastName" 
			ng-model="frmRegistrationData.lastName" 
			required 
			tabindex="3">
			
			<div class="c-errorMessages" ng-show="(frmRegisterNewUser.txtLastName.$invalid)">
				<p ng-show="(frmRegisterNewUser.txtLastName.$touched && frmRegisterNewUser.txtLastName.$error.required) || (frmRegisterNewUser.txtLastName.$error.required && isFormValid==false)">Last Name is required</p>
			</div>
		</div>
		
		<div class="form-group">
			<label>Mobile Number <span class="c-requiredSign">*</span></label>			
			<div class="input-group">
                <span class="input-group-addon c-width100">
					<select class="form-control" 
						name="txtCountryCode" 
						ng-model="frmRegistrationData.countryCode" 
						required 
						tabindex="4">
						<option value="" selected="selected">Select</option>
						<option value="+91">India +91</option>
						<option value="+1">USA +1</option>
					</select>
				</span>
				<input type="text" class="form-control" 
					name="txtMobileNumber" 
					ng-model="frmRegistrationData.mobileNumber" 
					required 
					tabindex="5">
			</div>
			<div class="c-errorMessages" ng-show="(frmRegisterNewUser.txtCountryCode.$invalid)">
				<p ng-show="(frmRegisterNewUser.txtCountryCode.$touched && frmRegisterNewUser.txtCountryCode.$error.required) || (frmRegisterNewUser.txtCountryCode.$error.required && isFormValid==false)">Country Code is required</p>
			</div>
			
			<div class="c-errorMessages" ng-show="(frmRegisterNewUser.txtMobileNumber.$invalid)">
				<p ng-show="(frmRegisterNewUser.txtMobileNumber.$touched && frmRegisterNewUser.txtMobileNumber.$error.required) || (frmRegisterNewUser.txtMobileNumber.$error.required && isFormValid==false)">Mobile Number is required</p>
			</div>
		</div>
		
		<div class="form-group">
			<label>Address</label>
			<textarea class="form-control" 
				name="txtAddress" 
				ng-model="frmRegistrationData.address" 
				tabindex="6"></textarea>
		</div>
		
		
		<div class="form-group">
			<label>Password <span class="c-requiredSign">*</span></label>
			<input type="password" class="form-control" 
				name="txtPassword" 
				ng-model="frmRegistrationData.password" 
				required 
				tabindex="7">
				
			<div class="c-errorMessages" ng-show="(frmRegisterNewUser.txtPassword.$invalid)">
				<p ng-show="(frmRegisterNewUser.txtPassword.$touched && frmRegisterNewUser.txtPassword.$error.required) || (frmRegisterNewUser.txtPassword.$error.required && isFormValid==false)">Password is required</p>
			</div>
		</div>
		<div class="form-group">
			<label>Confirm Password <span class="c-requiredSign">*</span></label>
			<input type="password" class="form-control" 
				name="txtConfirmPassword" 
				ng-model="frmRegistrationData.confirmPassword" 
				required 
				tabindex="8">
				
			<div class="c-errorMessages" ng-show="(frmRegisterNewUser.txtConfirmPassword.$invalid)">
				<p ng-show="(frmRegisterNewUser.txtConfirmPassword.$touched && frmRegisterNewUser.txtConfirmPassword.$error.required) || (frmRegisterNewUser.txtConfirmPassword.$error.required && isFormValid==false)">Confirm Password is required</p>					
			</div>
			<div class="c-errorMessages">
				<p ng-show="(frmRegisterNewUser.txtConfirmPassword.$touched && frmRegistrationData.confirmPassword != null) 
					&& (frmRegistrationData.confirmPassword != frmRegistrationData.password)">Confirm Password does not match with Password</p>
			</div>
		</div>
		
		<div class="form-group text-center">
			<button type="button" class="btn btn-info btn-rounded c-btnMain" id="btnRegisterNewUser" 
			ng-click="registerNewUser(frmRegisterNewUser, frmRegistrationData);" 
			ng-enter="registerNewUser(frmRegisterNewUser, frmRegistrationData);" 
			tabindex="9">Submit</button>
		</div>
		<div class="c-forgotPassword"><a ng-href="#/login/" tabindex="10">Sign in</a> instead</div>
	</form>					
</div>
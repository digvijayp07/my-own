<div class="row bg-title">
	<div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
		<h4 class="page-title">Edit Account</h4> 
	</div>		
	<!--<div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
		<a href="https://wrappixel.com/templates/ampleadmin/" target="_blank" class="btn btn-danger pull-right m-l-20 hidden-xs hidden-sm waves-effect waves-light">Upgrade to Pro</a>			
	</div>-->
</div>
<!-- /.row -->
<!-- .row -->
<div class="row">
	<div class="col-md-4 col-xs-12">
		<div class="white-box c-userAccountInfoSide c-brad4">
			<div class="user-bg c-bradTopOnly4"> 
				<img width="100%" alt="user" src="plugins/images/large/img1.jpg">
				<div class="overlay-box">
					<div class="user-content">
						<a href="javascript:void(0)"><img src="plugins/images/users/varun.jpg" class="thumb-lg img-circle" alt="img"></a>
						<h4 class="text-white">Mr. Rana Da</h4>
						<!--<h5 class="text-white">Cust. ID- 00001234</h5> -->
					</div>
				</div>
			</div>
			<div class="user-btm-box text-center">				
				<a ng-href="#/myAccount" class="btn btn-link"><i class="fa fa-eye"></i>&nbsp; View Account</a>
			</div>
		</div>
	</div>
	<div class="col-md-8 col-xs-12">
		<div class="white-box c-userAccountInfoMain c-brad4">
			
			<form class="form-horizontal form-material">
				<div class="form-group">
					<label class="col-md-12">Customer ID</label>
					<div class="col-md-12">
						<input type="text" value="00001234" class="form-control form-control-line disabled" readonly="readonly" disabled="disabled"> 
					</div>
				</div>
				<div class="col-md-4 col-sm-6 col-xs-12 c-inlineInput">
					<div class="form-group">
						<label class="col-md-12 p-0">First Name</label>
						<div class="col-md-12 p-0">
							<input type="text" value="Rana Da" class="form-control form-control-line"> 
						</div>
					</div>
				</div>
				<div class="col-md-4 col-sm-6 col-xs-12 c-inlineInput">
					<div class="form-group">
						<label class="col-md-12 p-0">Middle Name</label>
						<div class="col-md-12 p-0">
							<input type="text" value="" class="form-control form-control-line"> 
						</div>
					</div>
				</div>
				<div class="col-md-4 col-sm-6 col-xs-12 c-inlineInput">
					<div class="form-group">
						<label class="col-md-12 p-0">Last Name</label>
						<div class="col-md-12 p-0">
							<input type="text" value="Vasagadekar" class="form-control form-control-line"> 
						</div>
					</div>
				</div>
				
				<div class="form-group">
					<label for="example-email" class="col-md-12">Email</label>
					<div class="col-md-12">
						<input type="email" value="rana.da@gmail.com" class="form-control form-control-line" name="example-email" id="example-email"> 
					</div>
				</div>
				
				<div class="col-md-4 col-sm-6 col-xs-12 c-inlineInput">
					<div class="form-group">
						<label class="col-md-12 p-0">Country Code</label>
						<div class="col-md-12 p-0">
							<select class="form-control form-control-line">
								<option value="">Select</option>
								<option value="+91" selected="selected">India +91</option>
								<option value="+1">Usa +1</option>
							</select>
						</div>
					</div>
				</div>
				<div class="col-md-8 col-sm-6 col-xs-12 c-inlineInput">
					<div class="form-group">
						<label class="col-md-12 p-0">Mobile No.</label>
						<div class="col-md-12 p-0">
							<input type="text" value="9955885544" class="form-control form-control-line"> 
						</div>
					</div>
				</div>
				
				<div class="form-group">
					<label class="col-md-12">Address</label>
					<div class="col-md-12">
						<textarea rows="5" class="form-control form-control-line">121, B Ward, Vasagade. Tal - Karvir. Dist - Kolhapur</textarea>
					</div>
				</div>
				<div class="col-md-6 col-sm-6 col-xs-12 c-inlineInput">
					<div class="form-group">
						<label class="col-sm-12 p-0">Colony / Lane / Ward</label>
						<div class="col-sm-12 p-0">
							<select class="form-control form-control-line">
								<option value="">Select</option>
								<option value="" selected="selected">Ingawale Colony</option>
								<option value="">Chenani Park</option>
								<option value="">Sarvesh Park</option>
								<option value="">Ajinkya Tarun Mandal</option>
							</select>
						</div>
					</div>
				</div>
				
				<div class="col-md-6 col-sm-6 col-xs-12 c-inlineInput">
					<div class="form-group">
						<label class="col-sm-12 p-0">Select Country</label>
						<div class="col-sm-12 p-0">
							<select class="form-control form-control-line">
								<option value="">Select</option>
								<option value="India" selected="selected">India</option>
								<option value="USA">USA</option>
							</select>
						</div>
					</div>
				</div>
				<div class="col-md-6 col-sm-6 col-xs-12 c-inlineInput">
					<div class="form-group">
						<label class="col-sm-12 p-0">Select State</label>
						<div class="col-sm-12 p-0">
							<select class="form-control form-control-line">
								<option value="">Select</option>
								<option value="Maharashtra" selected="selected">Maharashtra</option>
								<option value="Goa">Goa</option>
							</select>
						</div>
					</div>
				</div>
				<div class="col-md-6 col-sm-6 col-xs-12 c-inlineInput">
					<div class="form-group">
						<label class="col-sm-12 p-0">Select District</label>
						<div class="col-sm-12 p-0">
							<select class="form-control form-control-line">
								<option value="">Select</option>
								<option value="Kolhapur" selected="selected">Kolhapur</option>
								<option value="Sangli">Sangli</option>
								<option value="Miraj">Miraj</option>
								<option value="Satara">Satara</option>
							</select>
						</div>
					</div>
				</div>
				<div class="col-md-6 col-sm-6 col-xs-12 c-inlineInput">				
					<div class="form-group">
						<label class="col-sm-12 p-0">Select Taluka</label>
						<div class="col-sm-12 p-0">
							<select class="form-control form-control-line">
								<option value="">Select</option>
								<option value="Karvir" selected="selected">Karvir</option>
							</select>
						</div>
					</div>
				</div>
				<div class="col-md-6 col-sm-6 col-xs-12 c-inlineInput">
					<div class="form-group">
						<label class="col-sm-12 p-0">Select City</label>
						<div class="col-sm-12 p-0">
							<select class="form-control form-control-line">
								<option value="">Select</option>
								<option value="Kolhapur" selected="selected">Kolhapur</option>
								<option value="Sangli">Sangli</option>
								<option value="Miraj">Miraj</option>
								<option value="Satara">Satara</option>
							</select>
						</div>
					</div>
				</div>
				<div class="form-group c-formFooter">
					<div class="col-sm-12">
						<button class="btn btn-info btn-rounded c-btnMain">Update Profile</button>
					</div>
				</div>
			</form>
			
			<div class="clearfix"></div>	
		</div>
	</div>
</div>
<!-- /.row -->
myApp.config(['$routeProvider', function($routeProvider) {
		
		$routeProvider
		.when('/dashboard', {
			controller: 'dashboardCtrl',
            templateUrl: 'views/dashboard/dashboard.html'
		})
		
		/* LOGIN PAGES */
		.when('/login', {
			controller: 'loginCtrl',
            templateUrl: 'views/login/login.html'
		})
		.when('/forgotPassword', {
			controller: 'loginCtrl',
            templateUrl: 'views/login/forgotPassword.html'
		})
		
		/* ACCOUNT */
		.when('/myAccount', {
			controller: 'accountCtrl',
            templateUrl: 'views/account/myAccount.html'
		})
		.when('/editAccount', {
			controller: 'accountCtrl',
            templateUrl: 'views/account/editAccount.html'
		})
		
		/* PACKAGE */
		.when('/myPackage', {
			controller: 'packageCtrl',
            templateUrl: 'views/package/myPackage.html'
		})
		
		/* BILLS */
		.when('/myBills', {
			controller: 'billsCtrl',
            templateUrl: 'views/bills/myBills.html'
		})
		
		/* COMPLAINTS */
		.when('/myComplaints', {
			controller: 'complaintsCtrl',
            templateUrl: 'views/complaints/myComplaints.html'
		})				
		
		/* ERROR PAGES */
		.when('/404', {
			controller: 'applicationCtrl',
            templateUrl: 'views/errorPage/pageNotFound.html'
		})
		.otherwise({
			redirectTo: '/404'
		});		
		
		
		
}]);
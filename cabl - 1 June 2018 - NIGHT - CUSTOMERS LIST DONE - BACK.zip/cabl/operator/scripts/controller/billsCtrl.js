myApp.controller('billsCtrl', billsCtrl);

function billsCtrl($scope, $rootScope) {
	
	// set page title
    $rootScope.pageTitle = 'Bills | Operator';
	
	// set session and view type(login or after login).. so that related view is rendered
	$rootScope.setViewType('afterLogin');
	$rootScope.sessionActive = true;
	
	//console.log('Bills Controller');
	//// init
	init();
	function init() {
		initPlugins();
	}
	
}
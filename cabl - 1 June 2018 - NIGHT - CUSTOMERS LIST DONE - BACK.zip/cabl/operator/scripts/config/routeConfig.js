myApp.config(['$routeProvider', function($routeProvider) {
		
		$routeProvider
		.when('/dashboard', {
			controller: 'dashboardCtrl',
            templateUrl: 'views/dashboard/dashboard.html'
		})	

		/* ACCOUNT */
		.when('/myAccount', {
			controller: 'accountCtrl',
            templateUrl: 'views/account/myAccount.html'
		})
		.when('/editAccount', {
			controller: 'accountCtrl',
            templateUrl: 'views/account/editAccount.html'
		})
		
		/* COMPLAINTS */
		.when('/complaints', {
			controller: 'complaintsCtrl',
            templateUrl: 'views/complaints/complaints.html'
		})

		/* BILLS */
		.when('/bills', {
			controller: 'billsCtrl',
            templateUrl: 'views/bills/bills.html'
		})	
			
		/* CUSTOMERS */
		.when('/myCustomers', {
			controller: 'customersCtrl',
            templateUrl: 'views/customers/myCustomers.html'
		})
		
		/* ERROR PAGES */
		.when('/404', {
			controller: 'applicationCtrl',
            templateUrl: 'views/errorPage/pageNotFound.html'
		})
		.otherwise({
			redirectTo: '/404'
		});		
		
		
		
}]);
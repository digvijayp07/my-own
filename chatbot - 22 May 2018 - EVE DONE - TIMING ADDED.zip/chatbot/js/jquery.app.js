/**
 * Theme: Adminox Admin Template
 * Author: Coderthemes
 * Module/App: Main Js
 */


(function ($) {

    'use strict';
	
	
	function setChatHeight() {
		var windowHt = $('html')["0"].clientHeight;     //get window height

		// SIDEBAR USER LIST HEIGHT
		var tabsHt = $(document).find('.c-sidebarHeader')["0"].offsetHeight;
		var tabsSearchHt = tabsHt;
		var finalSidebarContentHt = windowHt - tabsSearchHt;
		//SET HEIGHT
		$('.c-sideContentWrapper').css('height', finalSidebarContentHt + 'px');
		$('.c-chatSidebarWrapper').css('height', windowHt + 'px');

		// CHAT SECTION HEIGHT
		if($('.c-csTopSectionWrapper').length > 0) {
			var userInfoTopHt = $(document).find('.c-csTopSectionWrapper')["0"].clientHeight;
			var footerInputHt = $(document).find('.c-mainChatFooterWrapper')["0"].clientHeight + 10; //+10 margin bottom
			var userFooterHt = userInfoTopHt + footerInputHt + 38;  //3 + 35  padding top + bottom .c-mainChatSection
			var finalChatSectionHt = windowHt - userFooterHt;
			//SET HEIGHT
			$('.c-mainChatSectionInner').css('height', finalChatSectionHt + 'px');
			
			//SET HEIGHT OF WINDOW
			$('.c-chatSectionWrapper').css('height', windowHt + 'px');
		}
		else {
			//SET HEIGHT OF WINDOW
			$('.c-chatSectionWrapper').css('height', windowHt + 'px');
		}
		
		//scrolll to bottom recent chat
		setTimeout(function() {	
			$(".c-mainChatSectionInner").scrollTop($(document).height()); //$(".c-mainChatSectionInner")[0].scrollHeight
		}, 500);
	}
	setChatHeight();
	
	$(window).resize(function (e) {
        setChatHeight();
    });	
	
	
	/* LOADER */
	function loaderStart() {
		$('body').prepend('<div class="modal-backdrop fade in"></div>');
		$('.c-chatSectionWrapper').append(htmlLoader);
		$('.c-customLoader').fadeIn();
	}
	function loaderStop() {
		$('.modal-backdrop').remove();
		$('.c-customLoader').fadeOut();
		$('.c-customLoader').remove();
	}
	
	/* REMOVE MODAL HTML AFTER CLOSE */
	$(document).on('click', 'button[data-dismiss="modal"]', function () {
		setTimeout(function() {
			$('#c-allInOneModal').remove();
		}, 500);
	});
	
	////////// CHAT START
	var htmlTopUserInfo = '<div class="c-csTopSectionWrapper"><div class="c-csTopUserInfo"><div class="c-chatUserImg"> <img src="images/icons/manager.svg" class="img-circle user-img thumb-md" alt="" /></div><div class="c-chatUserInfo"><p class="c-cuiUsername"></p></div><div class="c-csTopActions"> <span class="c-csTopIcon"> <a href="javascript:void(0);" id="c-csTopIconCloseSession"><i class="fi-cross"></i></a> </span></div></div></div>';
	
	
	var htmlFooterInput = '<div class="c-mainChatFooterWrapper"></div>';
	/* <div class="c-userTypingWrapper"><div id="dancing-dots-text" class="c-userTypingWrapperInner"> <span class="img-circle thumb-sm c-userDefaultInitials"> <i class="mdi mdi-emoticon"></i> </span> <span class="text-warning"> <span><i class="fa fa-circle"></i></span> <span><i class="fa fa-circle"></i></span> <span><i class="fa fa-circle"></i></span> </span></div></div><div class="c-mainChatFooterInput"><textarea class="form-control c-mainChatTextarea wdt-emoji-bundle-enabled wdt-emoji-open-on-colon" readonly="readonly" disabled="disabled"></textarea></div><div class="c-mainChatFooterActions"> <button type="button" class="btn btn-primary waves-effect waves-light btn-rounded c-chatSubmitBtn"> <i class="fa fa-paper-plane fa-2x"></i> </button></div> */
	
	var htmlStartConversation = '<div class="c-infoMessage"><div class="c-infoMessageInner"><div class="c-imiIcons"> <i class="fi-speech-bubble"></i></div><p>Yet to start the conversation?</p><h4>Enter your name to proceed.</h4><div class="c-infoFormWrapper"><div class="c-infoInputWrapper"><div class="c-infoInput c-withButton"> <input type="text" name="txtUsername" class="form-control c-txtUsername" maxlength="15" /></div><div class="c-infoInputBtn"> <button type="button" class="btn btn-default waves-effect waves-light" id="c-btnSubmitUsername"> <i class="fa fa-paper-plane"></i> </button></div><div class="c-inputNote text-muted">Max. length 15 characters</div></div></div></div></div>';
	
	var htmlNoBrowserSupport = '<div class="c-infoMessage"><div class="c-infoMessageInner"><div class="c-imiIcons"> <i class="mdi mdi-google-chrome"></i></div><h4>No Browser Support.</h4><p>Kindly, upgrade your browser to proceed.</p></div></div>';
	
	var htmlGoodbyeMessage = '<div class="c-infoMessage"><div class="c-infoMessageInner"><div class="c-imiIcons"> <i class="mdi mdi-emoticon-sad"></i></div><h4>Sorry to see you go.</h4><p>But, glad that you stopped by.</p><p><button type="button" class="btn btn-link" id="c-btnRestartAgain"> <i class="fi-reload"></i> Re-start Again</button></p></div></div>';
	
	var htmlMessageSectionWrapper = '<div class="c-mainChatSection"><div class="c-mainChatSectionInner"></div></div>';	
	var htmlChatSectionWrapper = '<div class="c-mainChatSection"><div class="c-mainChatSectionInner"><div class="c-mainChatSectionInnerFlexFix"></div></div></div>';
	
	var htmlAllInOneModal = '<div id="c-allInOneModal" class="modal fade c-customModal"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"> <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="fi-cross"></i></button><h4 class="modal-title"></h4></div><div class="modal-body"></div><div class="modal-footer"> <button type="button" class="btn btn-default c-btnCancel" data-dismiss="modal">Cancel</button> <button type="button" class="btn btn-default text-primary c-btnAction" id=""></button></div></div></div></div>';
	
	var htmlLoader = '<div class="c-customLoader"> <i class="pe-7s-cloud c-clCloud1"></i> <i class="pe-7s-cloud c-clCloud2"></i> <i class="pe-7s-cloud c-clCloud3"></i> <i class="fi-sun c-clSun"></i><div class="c-clInner"> <img src="images/car-loader.png" alt="" /></div></div>';
	
	var htmlChatOtherUser = '<div class="c-chatRow c-chatOtherUser animated bounceInLeft"><div class="c-chatUser"> <span class="img-circle thumb-sm c-userDefaultInitials"> <i class="mdi mdi-emoticon"></i> </span></div><div class="c-chatBubbleWrapper"><div class="c-chatTime"> <span title=""></span></div><div class="c-chatBubble"></div></div><div class="clearfix"></div></div>';
	
	var htmlChatGuestUser = '<div class="c-chatRow c-chatSelfUser c-chatGuestUser animated bounceInRight"><div class="c-chatBubbleWrapper"><div class="c-chatTime"> <span title=""></span></div><div class="c-chatBubble"></div></div><div class="clearfix"></div></div>';
	
	
	///************** 1. Check browser support ************************************************************************************///
	if (typeof(Storage) !== "undefined") {
		// CHECK USER IS IN		
		if(localStorage.getItem("ls-username") === null || localStorage.getItem("ls-username") == '') { 
			localStorage.setItem("ls-username", "");
			
			//If username is not set then show enter username screen			
			setTimeout(loaderStart, 0);
			setTimeout(loaderStop, 3000);
			setTimeout(showEnterUsernameWindow, 3500);
		}
		else {
			//If username is set / exist in localstorage, then display chat window
			showWelcomeChatWindow(); 						
		}				
	} 
	else {
		// If browser does not support localstorage, then display message
	}	
	// END Check browser support	
	
	
	//************** 1.1 Enter Username Window **********************************************************************///
	function showEnterUsernameWindow() {
		//1.
		$('.c-chatSectionWrapper').html('');
		
		//2.
		$('.c-chatSectionWrapper').html(htmlStartConversation);
	}	
	
	///************** 2. Get Username from user **********************************************************************///
	$(document).on('click', '#c-btnSubmitUsername', function() {
		var txtUsername = $('.c-txtUsername').val();		
		
		if(txtUsername != ''){ //validate username, enter here if validates else throw error
			//1.
			$('.c-chatSectionWrapper').html('');
		
			localStorage.setItem("ls-username", txtUsername);
			setTimeout(loaderStart, 0);
			setTimeout(loaderStop, 3000);
			setTimeout(showWelcomeChatWindow, 3500);
		}
		else {  //throw error
			$('body').append(htmlAllInOneModal);
			$('#c-allInOneModal').modal('show');			
			
			if($('#c-allInOneModal').find('.modal-body').html().length == 0) {
				$('#c-allInOneModal').find('.modal-title').addClass('text-danger');
				$('#c-allInOneModal').find('.modal-title').html('Error');
				
				$('#c-allInOneModal').find('.modal-body').append('<p>Please enter your name.</p>');	
				
				$('#c-allInOneModal').find('.modal-footer').addClass('c-singleBtn');
				$('#c-allInOneModal').find('.c-btnCancel').remove();
				$('#c-allInOneModal').find('.c-btnAction').attr('data-dismiss', 'modal');	
				$('#c-allInOneModal').find('.c-btnAction').html('Okay');
			}
		}
	});		
	
	//************** 3. Welcome Chat Window **********************************************************************///
	function showWelcomeChatWindow() {
		//1.	
		$('.c-chatSectionWrapper').append(htmlTopUserInfo);
		$('.c-cuiUsername').html(localStorage.getItem("ls-username"));
		
		//2.
		$('.c-chatSectionWrapper').append(htmlChatSectionWrapper);
		
		//3.
		$('.c-chatSectionWrapper').append(htmlFooterInput);
		
		//4.
		setChatHeight();
		
		//5.
		startChat();
	}
	//************** 3.1 Start Chat **********************************************************************///
	function startChat() {
		localStorage.setItem("ls-messageId", 0);	// SET first message key as local storage & default message id as 0 
		
		speakOtherUser('<p>Hi '+ localStorage.getItem("ls-username")+',<br/> How may I assist you today?</p>', getCurrentMessageId());
	}
	//************** 3.2 Print Other User Message (Bot) **********************************************************************///
	function speakOtherUser(msg, msgId) {
		$('.c-mainChatSectionInnerFlexFix').append(htmlChatOtherUser);
		
		//if first message
		if($('.c-chatOtherUser').length == 1) { 			
			$('.c-chatOtherUser').attr('data-msg-id', msgId); // Print Message Id			
			$('.c-chatOtherUser').find('.c-chatBubble').append(msg); // Print Message
			$('.c-chatOtherUser').find('.c-chatTime span').html(getCurrentTime); // Print time
			$('.c-chatOtherUser').find('.c-chatTime span').attr('title', getCurrentTime); // Print time title
			setTimeout(function() {
				Q001();
			}, 2000);
		} 
		// oher than 1st messgae
		else {
			var mostRecentMessage = $('.c-chatOtherUser').length - 1; //total length - 1 = most recent printed message
			$('.c-chatOtherUser').eq(mostRecentMessage).attr('data-msg-id', msgId); // Print Message Id			
			$('.c-chatOtherUser').eq(mostRecentMessage).find('.c-chatBubble').append(msg); // Print Message
			$('.c-chatOtherUser').eq(mostRecentMessage).find('.c-chatTime span').html(getCurrentTime); // Print time
			$('.c-chatOtherUser').eq(mostRecentMessage).find('.c-chatTime span').attr('title', getCurrentTime); // Print time title
		}
		
		
		//scrolll to bottom recent chat
		setTimeout(function() {	
			setChatHeight();
			$(".c-mainChatSectionInner").scrollTop($(document).height()); //$(".c-mainChatSectionInner")[0].scrollHeight
		}, 500);
		
	}
	//************** 3.3 Print Guest User Message (Actual User) **********************************************************************///
	function speakGuestUser(msg, msgId) {
		$('.c-mainChatSectionInnerFlexFix').append(htmlChatGuestUser);
		
		//if first message
		if($('.c-chatGuestUser').length == 1) { 			
			$('.c-chatGuestUser').attr('data-msg-id', msgId); // Print Message Id			
			$('.c-chatGuestUser').find('.c-chatBubble').append(msg); // Print Message
			$('.c-chatGuestUser').find('.c-chatTime span').html(getCurrentTime); // Print time
			$('.c-chatGuestUser').find('.c-chatTime span').attr('title', getCurrentTime); // Print time title
		} 
		// oher than 1st messgae
		else {
			setTimeout(function() {				
				var mostRecentMessage = $('.c-chatGuestUser').length - 1; //total length - 1 = most recent printed message
				$('.c-chatGuestUser').eq(mostRecentMessage).attr('data-msg-id', msgId); // Print Message Id			
				$('.c-chatGuestUser').eq(mostRecentMessage).find('.c-chatBubble').append(msg); // Print Message
				$('.c-chatGuestUser').eq(mostRecentMessage).find('.c-chatTime span').html(getCurrentTime); // Print time
				$('.c-chatGuestUser').eq(mostRecentMessage).find('.c-chatTime span').attr('title', getCurrentTime); // Print time title
			}, 500);
		}
		
		//scrolll to bottom recent chat
		setTimeout(function() {	
			setChatHeight();
			$(".c-mainChatSectionInner").scrollTop($(document).height()); //$(".c-mainChatSectionInner")[0].scrollHeight
		}, 500);
	}	
	//************** Get Current Time **********************************************************************///
	function getCurrentTime() {
		var d = new Date(); // for now		
		return d.getHours() +':'+d.getMinutes();
	}
	//************** Get Current Message Id **********************************************************************///
	function getCurrentMessageId() {
		var currentMessageId = parseInt(localStorage.getItem("ls-messageId")) + 1;
		localStorage.setItem("ls-messageId", currentMessageId);
		return localStorage.getItem("ls-messageId");
	}
	
	///************** 4. Close Session **********************************************************************///
	$(document).on('click', '#c-csTopIconCloseSession', function() {
		//1.
		$('#c-closeSessionModal').modal('show');
	});
	$(document).on('click', '#c-closeSessionModalConfirmBtn', function() {
		//2.
		$('#c-closeSessionModal').modal('hide');
		
		//3.
		localStorage.clear();		
		showGoodbyeChatWindow();
	});
	function showGoodbyeChatWindow() {
		//4.
		$('.c-chatSectionWrapper').html('');
		$('.c-chatSectionWrapper').append(htmlGoodbyeMessage);
	}
	
	///************** 5. Re-start Again **********************************************************************///
	$(document).on('click', '#c-btnRestartAgain', function() {
		//1.
		showEnterUsernameWindow();
	});
	
	
	
	
	///************** QUESTIONS **********************************************************************///
	// Q1.
	function Q001(){
		//speakGuestUser('<div class="c-optionsBubble"><div class="radio radio-success"><input type="radio" name="radBuyNewCar" id="c-radBuyNewCar" class="c-radBuyNewCar c-selectAnswer" value="A001" data-question-id="Q001" data-next-question-id="Q002" data-answer-text="I want to buy a new car"><label for="c-radBuyNewCar"> I want to buy a new car</label></div></div>', getCurrentMessageId());
		
		$('.c-mainChatFooterWrapper').append('<div class="c-optionsBubble"><div class="radio radio-success"><input type="radio" name="radBuyNewCar" id="c-radBuyNewCar" class="c-radBuyNewCar c-selectAnswer" value="I want to buy a new car" data-answer-text="I want to buy a new car" data-answer-id="A001" data-question-id="Q001"><label for="c-radBuyNewCar"> I want to buy a new car</label></div> <div class="c-optionsMainButton"><button type="button" class="btn btn-primary btn-xs c-chatSubmitBtn"> <i class="fa fa-paper-plane"></i> Sumbit</button></div></div>');
		setChatHeight();
	}
	// Q2.
	function Q002(){		
		//Get unique car manufacturer names from json data
		var optionsStr = '';
		$.getJSON( "data/cars.json", function( carsData ) {		  
		  
			var uniqueManufacturerNames = [];
			for(var i = 0; i < carsData.length; i++){    
				if(uniqueManufacturerNames.indexOf(carsData[i].Manufacturer) === -1){
					uniqueManufacturerNames.push(carsData[i].Manufacturer);        
				}        
			}
			uniqueManufacturerNames.sort();
			for(var i = 0; i < uniqueManufacturerNames.length; i++){ 
				optionsStr += '<div class="radio radio-success"><input type="radio" name="radMfgName" id="c-radMfgName'+i+'" class="c-radMfgName c-selectAnswer" value="'+uniqueManufacturerNames[i]+'" data-answer-text="'+uniqueManufacturerNames[i]+'" data-answer-id="A002" data-question-id="Q002"><label for="c-radMfgName'+i+'">'+uniqueManufacturerNames[i]+'</label></div>';
			}
		  
			$('.c-mainChatFooterWrapper').append('<div class="c-optionsBubble">'+optionsStr+'<div class="c-optionsMainButton"><button type="button" class="btn btn-primary btn-xs c-chatSubmitBtn"> <i class="fa fa-paper-plane"></i> Sumbit</button></div></div>');
			setChatHeight();
		});	
	}
	
	// Q3.
	function Q003(){		
		//Get car list of selected manufacturer and get all unique mileage
		var optionsStr = '';
		$.getJSON( "data/cars.json", function( carsData ) {		
			
			var allCarsByManufacturer = [];
			for(var i = 0; i < carsData.length; i++){    
				if(carsData[i].Manufacturer === localStorage.getItem("ls-selectedManufacturer")){
					allCarsByManufacturer.push(carsData[i]);        
				}        
			}
			
			var allCarsByMileage = [];
			for(var i = 0; i < allCarsByManufacturer.length; i++){ 				
				if(allCarsByManufacturer.indexOf((allCarsByManufacturer[i].Miles_per_Gallon) === -1)){
					allCarsByMileage.push(allCarsByManufacturer[i].Miles_per_Gallon); 
				} 				
			}			
			
			var minMileage = Math.min.apply(Math,allCarsByMileage);			
			var maxMileage = Math.max.apply(Math,allCarsByMileage); 
			
			optionsStr += '<input type="text" name="txtMinMileage" id="c-txtMinMileage" class="c-txtMinMileage c-selectAnswer" data-answer-text="" data-answer-id="A003" data-question-id="Q003" data-slider-min="'+minMileage+'" data-slider-max="'+maxMileage+'" data-slider-step="1" data-slider-value="'+minMileage+'">';		
		  
			$('.c-mainChatFooterWrapper').append('<div class="c-optionsBubble">'+optionsStr+'<div class="c-optionsMainButton"><button type="button" class="btn btn-primary btn-xs c-chatSubmitBtn"> <i class="fa fa-paper-plane"></i> Sumbit</button></div></div>');
			
			setTimeout(function() {
				//1.
				$('#c-txtMinMileage').slider({
					tooltip: 'always'				
				});
				
				
				//2. store data in local storage
				localStorage.setItem("ls-questionId", $('#c-txtMinMileage').attr('data-question-id'));		
				localStorage.setItem("ls-answerId", $('#c-txtMinMileage').attr('data-answer-id'));
				localStorage.setItem("ls-answerText", minMileage);
				//3. auto-enter answer text in textarea
				$('.c-mainChatTextarea').val(minMileage);
			}, 500);
			
			setTimeout(function() {
				setChatHeight();
			}, 500);
		});	
	}
	
	// Q4.
	function Q004(){		
		//Get all cars which matches with selected car manufacturer and mileage expectation
		var optionsStr = '';
		$.getJSON( "data/cars.json", function( carsData ) {		  
			
			var allCarsByManufacturer = [];
			for(var i = 0; i < carsData.length; i++){    
				if(carsData[i].Manufacturer === localStorage.getItem("ls-selectedManufacturer") && 
				carsData[i].Miles_per_Gallon >= parseInt(localStorage.getItem("ls-answerText"))){
					allCarsByManufacturer.push(carsData[i].Name);        
				}        
			}
			allCarsByManufacturer.sort();
			
			for(var i = 0; i < allCarsByManufacturer.length; i++){ 
				optionsStr += '<div class="radio radio-success"><input type="radio" name="radCarName" id="c-radCarName'+i+'" class="c-radCarName c-selectAnswer" value="'+allCarsByManufacturer[i]+'" data-answer-text="'+allCarsByManufacturer[i]+'" data-answer-id="A004" data-question-id="Q004"><label for="c-radCarName'+i+'">'+allCarsByManufacturer[i]+'</label></div>';
			}
		  
			$('.c-mainChatFooterWrapper').append('<div class="c-optionsBubble">'+optionsStr+'<div class="c-optionsMainButton"><button type="button" class="btn btn-primary btn-xs c-chatSubmitBtn"> <i class="fa fa-paper-plane"></i> Sumbit</button></div></div>');
			setChatHeight();
		});	
	}
	
	// ON SELECT ANSWER
	$(document).on('click', '.c-selectAnswer', function() {
		var currentAnswerText = $(this).attr('data-answer-text');
		//1. store data in local storage
		localStorage.setItem("ls-questionId", $(this).attr('data-question-id'));		
		localStorage.setItem("ls-answerId", $(this).attr('data-answer-id'));
		localStorage.setItem("ls-answerText", currentAnswerText);
		
		//2. auto-enter answer text in textarea
		$('.c-mainChatTextarea').val(currentAnswerText);
	});
	$(document).on("slide", "#c-txtMinMileage", function(slideEvt) {
		var currentAnswerText = $(this).val();
		//1. store data in local storage
		localStorage.setItem("ls-questionId", $(this).attr('data-question-id'));		
		localStorage.setItem("ls-answerId", $(this).attr('data-answer-id'));
		localStorage.setItem("ls-answerText", currentAnswerText);
		
		//2. auto-enter answer text in textarea
		$('.c-mainChatTextarea').val(currentAnswerText);
	});
	$(document).on('click', '.c-viewCarDetailsBtn', function() {		
		//1. Get car details
		$.getJSON( "data/cars.json", function( carsData ) {			
			for(var i = 0; i < carsData.length; i++){    
				if(carsData[i].Manufacturer === localStorage.getItem("ls-selectedManufacturer") && 
				carsData[i].Name === localStorage.getItem("ls-selectedCar")){
					console.log(carsData[i]);  
					//1. clear existing chat content
					$('.c-mainChatSectionInnerFlexFix').html('');
					
					//2. build string
					var str1= '';
					$.each(carsData[i], function(key, value){
						if(key != 'Image') {
							//console.log(key+' : '+value);
							str1 += '<div class="row"><div class="col-xs-6 c-cdPoint">'+key+'</div><div class="col-xs-6 c-cdValue">'+value+'</div></div>';
						}
					});
					var str2 = '<div class="c-carDetailsWrapper"><div class="c-cdImgWrap"> <img src="'+carsData[i].Image+'" class="img-responsive"></div><div class="c-cdList">'+str1+'</div><div><button type="button" class="btn btn-primary btn-lg btn-block" id="c-btnRestartAgain"> <i class="fi-reload"></i> Re-start Again</button></div></div>';
					
					$('.c-mainChatSectionInnerFlexFix').html(str2);
				}        
			}
			
			//2.
			setChatHeight();
			
			//3.
			localStorage.clear();
		});		
	});
	
	// ON SUBMIT ANSWER
	$(document).on('click', '.c-chatSubmitBtn', function() {
		var textareaAnswer = $('.c-mainChatTextarea').val();
		
		if( 
			($('input[type=radio]').length > 0) && ($(document).find('input[type=radio]:checked').length == 0) || 
			($('input[type=checkbox]').length > 0) && ($('input[type=checkbox]:checked').length == 0) 
		) {
			$('body').append(htmlAllInOneModal);
			$('#c-allInOneModal').modal('show');
			
			if($('#c-allInOneModal').find('.modal-body').html().length == 0) {
				$('#c-allInOneModal').find('.modal-title').addClass('text-danger');
				$('#c-allInOneModal').find('.modal-title').html('Error');
				
				$('#c-allInOneModal').find('.modal-body').append('<p>Please select an option to proceed.</p>');	
				
				$('#c-allInOneModal').find('.modal-footer').addClass('c-singleBtn');
				$('#c-allInOneModal').find('.c-btnCancel').remove();
				$('#c-allInOneModal').find('.c-btnAction').attr('data-dismiss', 'modal');	
				$('#c-allInOneModal').find('.c-btnAction').html('Okay');
			}
			
			//1.
			$('.c-mainChatTextarea').val('');
		}
		else {
			if(textareaAnswer == localStorage.getItem("ls-answerText")) { //if answer is valid
				//1.
				$('.c-mainChatFooterWrapper').find('.c-optionsBubble').remove();
				
				//2.
				speakGuestUser('<p>'+textareaAnswer+'</p>', getCurrentMessageId());
				$('.c-mainChatTextarea').val('');
				
				//3. Analyze answer and ask next question to user	
				setTimeout(function() {
					switch (localStorage.getItem("ls-answerId").toString()) {
						case 'A001':
							speakOtherUser('<p>That sounds good.<br> Can you tell me, which car brand you are looking for?</p>', getCurrentMessageId());
							setTimeout(Q002, 3000);
							break;							
							
						case 'A002':
							localStorage.setItem("ls-selectedManufacturer", localStorage.getItem("ls-answerText").toString());
							speakOtherUser('<p>'+localStorage.getItem("ls-selectedManufacturer")+' !!!<br> That\'s a very good choice.</p>', getCurrentMessageId());
							setTimeout(function() {
								speakOtherUser('<p>What is your preferable minimum mileage expectation?</p>', getCurrentMessageId());
							}, 2000);
							setTimeout(Q003, 4000);
							break;

						case 'A003':
							localStorage.setItem("ls-minMileage", localStorage.getItem("ls-answerText").toString());
							speakOtherUser('<p>Wait, I will find you the best possible match.</p>', getCurrentMessageId());
							setTimeout(function() {
								speakOtherUser('<p>I have found following models for you. Please select the one you wish to buy.</p>', getCurrentMessageId());
							}, 2000);
							setTimeout(Q004, 4000);
							break;
						
						case 'A004':
							localStorage.setItem("ls-selectedCar", localStorage.getItem("ls-answerText").toString());
							speakOtherUser('<p>That\'s great!!!<br> So, finally you got your dream car.<br><div class="c-optionsMainButton"><button type="button" class="btn btn-primary btn-xs c-viewCarDetailsBtn"> <i class="fa fa-info"></i>&nbsp; View Your Car</button></div><div class="clearfix"></div></p>', getCurrentMessageId());
							break;						
					}
					
				}, 2000);				
				
			}
			else {  // ask same question
				//1.
				$('.c-mainChatFooterWrapper').find('.c-optionsBubble').remove();
				
				//2.
				speakOtherUser('<p>Sorry, <br> I did not get your answer.</p>', getCurrentMessageId());
			}
		}
	});
})(jQuery)
myApp.config(['$routeProvider', function($routeProvider) {
		
		$routeProvider
		.when('/dashboard', {
			controller: 'dashboardCtrl',
            templateUrl: 'views/dashboard/dashboard.php'
		})
		
		/* LOGIN PAGES */
		.when('/login', {
			controller: 'loginCtrl',
            templateUrl: 'views/login/login.php'
		})
		.when('/forgotPassword', {
			controller: 'loginCtrl',
            templateUrl: 'views/login/forgotPassword.php'
		})		
		.when('/registration', {
			controller: 'registrationCtrl',
            templateUrl: 'views/login/registration.php'
		})
		
		/* ACCOUNT */
		.when('/myAccount', {
			controller: 'accountCtrl',
            templateUrl: 'views/account/myAccount.php'
		})
		.when('/editAccount', {
			controller: 'accountCtrl',
            templateUrl: 'views/account/editAccount.php'
		})
		
		/* PACKAGE */
		.when('/myPackage', {
			controller: 'packageCtrl',
            templateUrl: 'views/package/myPackage.php'
		})
		
		/* BILLS */
		.when('/myBills', {
			controller: 'billsCtrl',
            templateUrl: 'views/bills/myBills.php'
		})
		
		/* COMPLAINTS */
		.when('/myComplaints', {
			controller: 'complaintsCtrl',
            templateUrl: 'views/complaints/myComplaints.php'
		})				
		
		/* ERROR PAGES */
		.when('/404', {
			controller: 'applicationCtrl',
            templateUrl: 'views/errorPage/pageNotFound.php'
		})
		.otherwise({
			redirectTo: '/404'
		});		
		
		
		
}]);
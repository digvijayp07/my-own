myApp.factory('modalService', ['$uibModal', function($uibModal) {

	return {
		openMenuModal: function(templateLink, controllerName) {
			
			var modalObj = $uibModal.open({
				templateUrl: templateLink,
				backdrop: 'static',
				windowClass: 'c-customModal animated slideInDown',
				controller: controllerName,
				
				/*function($scope,$modalInstance){
					$scope.ok = function(id){
						//Process OK Button Click
						$modalInstance.close(); 
					},
					$scope.cancel = function(){
						$modalInstance.dismiss('cancel');
					}
				},*/
				size: 'md',
				keyboard: true,
				resolve: {
					/*someData: function () {
						return 'Return some Data';
					}*/
				}
			});
			
		}
	};
	
}]);
myApp.controller('applicationCtrl', applicationCtrl);

function applicationCtrl($scope, $rootScope, $http, $location, localStorageService, $timeout, myConfig) {	
	// set page title
    $rootScope.pageTitle = 'Cabl Inc.';
	
	// set footer copyright
    $rootScope.footerCopyright = '&copy; 2018 Cabl Inc.';
	
	// set session true or false.. so that related view is rendered
	$rootScope.sessionActive;	
	$rootScope.login = {};
	$rootScope.login.userSessionDetails = {};
	
	$rootScope.setViewType = function (vt) {
		$rootScope.viewType = vt;
	}
	
	// set scope variables
	$rootScope.allActiveChoiceMastersOptions = {};
	
	//console.log('Application Controller');
	//// init
	init();
	function init() {
		initPlugins();
		
		// check session
		$timeout(function() {
			$rootScope.checkSessionExists();
		}, 0);
	}
	
	$rootScope.checkSessionExists = function(){
		if(localStorageService.get("userDetails") == null || localStorageService.get("userDetails") == undefined) {
			//console.log(myConfig.baseRouteUrl+'login');
			$location.path('/login');			
		}
		else {
			$rootScope.login.userSessionDetails = localStorageService.get("userDetails");
		}
	};
	
	
	
	
	//--------------------------------------------------------------//
	//***************** User Logout *******************//
	//------------------------------------------------------------//
	$scope.userLogout = function() {		
		$http({
			url: 'php/userLogin.php', 
			method: "POST",
			data: {
					httpRequest: 'userLogout',
					customerId: $rootScope.login.userSessionDetails.id					
			},
			headers : {
					'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
			}
		})
		.success(function(data){	
			//console.log(data);
			if(data.statusCode == 200) {
				alertify.success(data.statusMessage);
				
				$rootScope.login.userSessionDetails = {};
				localStorageService.clearAll();
				
				$timeout(function() {
					$location.path( "/login" );	
				}, 1000);
			}
			
			if(data.statusCode == 400) {
				alertify.error(data.statusMessage);
			}
		});		
	}
	//--------------------------------------------------------------//
	
	
	
	
	
	/* ================ GLOBAL FUNCTIONS ================ */
	//--------------------------------------------------------------//
	//***************** Remove Status Code & Messages From Data *******************//
	//------------------------------------------------------------//
	$rootScope.removeNonData = function(allData, removeThis) {		
		for(var i = 0; i < removeThis.length; i++) {
			delete allData[removeThis[i]];			
		}
	}
	//--------------------------------------------------------------//	
	
	//---------------------------------------------------------------//
	//***************** Get All Masters From Choice Master *****************//
	//-------------------------------------------------------------//
	$rootScope.getAllActiveChoiceMasters = function(chType) {
		$http({
			url: 'php/admin/choiceMaster.php', 
			method: "GET",
			params: {	
				httpRequest: 'getAllActiveChoiceMasters', 
				chTypeId: chType
			}
		})
		.success(function(data){
			//console.log(data);			
			$rootScope.removeNonData(data, ['statusCode', 'statusMessage']);			
			$rootScope.allActiveChoiceMastersOptions = data;
		});		
	};
	//--------------------------------------------------------------//	
}
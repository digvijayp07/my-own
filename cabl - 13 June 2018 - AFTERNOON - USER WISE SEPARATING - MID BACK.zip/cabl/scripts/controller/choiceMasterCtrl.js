myApp.controller('choiceMasterCtrl', choiceMasterCtrl);

function choiceMasterCtrl($scope, $rootScope, $http, $location, localStorageService, $timeout, myConfig, $uibModal, modalService) {	
	
	// set page title
    $rootScope.pageTitle = 'Choice Master';
	
	// set session and view type(login or after login).. so that related view is rendered
	$rootScope.setViewType('afterLogin');
	$rootScope.sessionActive = true;
	
	// set scope variables
	$scope.frmChoiceMasterData = {};
	
	//console.log('Choice Master Controller');
	//// init
	init();
	function init() {
		initPlugins();
		
		// check session
		$timeout(function() {
			$rootScope.checkSessionExists();
		}, 0);
	}
	
		
	//--------------------------------------------------------------//
	//****************** CREATE CHOICE MASTER *********************//
	//------------------------------------------------------------//
	$scope.openModal = function(){
		modalService.openMenuModal('views/choiceMaster/choiceMasterModalCreate.php', 'choiceMasterCtrl');
    };
	$scope.cancel = function(){
		$scope.$dismiss('cancel');
	};	
	$scope.choiceMasterCreate = function(formName, formData) {
		$scope.isFormValid = false;		
		if(formName.$valid) {			
			$scope.isFormValid = true;		
			$http({
				url: 'php/admin/choiceMaster.php', 
				method: "POST",
				data: {
					httpRequest: 'createChoiceMaster',					
					name: formData.name,
					typeId: formData.typeId,
					description: (formData.description ? formData.description : ''),
					isActive: formData.isActive
				},
				headers : {
					'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
				}
			})
			.success(function(data){
				//console.log(data);
				
				if(data.statusCode == 200) {
					alertify.success(data.statusMessage);
					
					// reset form data
					$scope.frmChoiceMasterData = angular.copy({});
					formName.$setPristine();
					formName.$setUntouched();
					formName.$rollbackViewValue();

					//close modal
					$timeout(function() {
						$scope.$close(); 
					}, 5000);
				}				
				
				if(data.statusCode == 400) {
					alertify.error(data.statusMessage);
				}
				
			});
		}
		else {
			$scope.isFormValid = false;
		}
		
	}
	//--------------------------------------------------------------//
	
		
}
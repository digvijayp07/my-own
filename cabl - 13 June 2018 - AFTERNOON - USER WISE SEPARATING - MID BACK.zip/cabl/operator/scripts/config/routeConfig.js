myApp.config(['$routeProvider', function($routeProvider) {
		
		$routeProvider
		.when('/dashboard', {
			controller: 'dashboardCtrl',
            templateUrl: 'views/dashboard/dashboard.php'
		})	

		/* ACCOUNT */
		.when('/myAccount', {
			controller: 'accountCtrl',
            templateUrl: 'views/account/myAccount.php'
		})
		.when('/editAccount', {
			controller: 'accountCtrl',
            templateUrl: 'views/account/editAccount.php'
		})
		
		/* COMPLAINTS */
		.when('/complaints', {
			controller: 'complaintsCtrl',
            templateUrl: 'views/complaints/complaints.php'
		})

		/* BILLS */
		.when('/bills', {
			controller: 'billsCtrl',
            templateUrl: 'views/bills/bills.php'
		})	
			
		/* CUSTOMERS */
		.when('/myCustomers', {
			controller: 'customersCtrl',
            templateUrl: 'views/customers/myCustomers.php'
		})
		
		/* ERROR PAGES */
		.when('/404', {
			controller: 'applicationCtrl',
            templateUrl: 'views/errorPage/pageNotFound.php'
		})
		.otherwise({
			redirectTo: '/404'
		});		
		
		
		
}]);
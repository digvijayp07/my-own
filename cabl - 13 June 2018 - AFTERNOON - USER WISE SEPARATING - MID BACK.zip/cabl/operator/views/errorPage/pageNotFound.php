<div class="error-box">
	<div class="error-body text-center">
		<h1 class="text-muted"><i class="flaticon-number"></i></h1>
		<h3 class="text-uppercase">Page Not Found !</h3>
		<p class="text-muted m-t-30 m-b-30">YOU SEEM TO BE TRYING TO FIND HIS WAY HOME</p>
		
		<a ng-href="#/dashboard/" class="btn btn-info btn-rounded waves-effect waves-light m-b-40" ng-if="sessionActive">Back to home</a> 
		<a ng-href="#/login/" class="btn btn-info btn-rounded waves-effect waves-light m-b-40" ng-if="!sessionActive">Back to login</a> 
	</div>	
</div>
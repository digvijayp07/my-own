<div class="c-loginHeading">
	<h3>Sign in</h3>
	<p>Welcome user.</p>
</div>
<div class="c-frmLogin">
	<form name="frmLogin" class="form-material" novalidate>
		<div class="form-group">
			<label>Customer ID <span class="c-requiredSign">*</span></label>
			<input type="text" class="form-control" placeholder="e.g. 00001234" 
				name="txtCustomerId" 
				ng-model="frmUserLoginData.customerId" 
				required 				
				tabindex="1">
				
			<div class="c-errorMessages" ng-show="(frmLogin.txtCustomerId.$invalid)">				
				<p ng-show="(frmLogin.txtCustomerId.$touched && frmLogin.txtCustomerId.$error.required) || (frmLogin.txtCustomerId.$error.required && isFormValid==false)">Customer ID is required</p>
			</div>
		</div>
		<div class="form-group">
			<label>Password <span class="c-requiredSign">*</span></label>
			<input type="password" class="form-control" placeholder="**********" 
				name="txtPassword" 
				ng-model="frmUserLoginData.password" 
				required 
				tabindex="2">
				
			<div class="c-errorMessages" ng-show="(frmLogin.txtPassword.$invalid)">
				<p ng-show="(frmLogin.txtPassword.$touched && frmLogin.txtPassword.$error.required) || (frmLogin.txtPassword.$error.required && isFormValid==false)">Password is required</p>
			</div>
		</div>
		
		<div class="form-group text-center">
			<button type="button" class="btn btn-info btn-rounded c-btnMain" 
				ng-click="userLogin(frmLogin, frmUserLoginData);" 
				ng-enter="userLogin(frmLogin, frmUserLoginData);"
				tabindex="3">Login</button>
		</div>
		<div class="c-forgotPassword"><a ng-href="#/forgotPassword/" tabindex="4">Forgot password?</a> Don't worry.</div>
	</form>					
</div>

<div class="c-registrationLink">
	<a ng-href="#/registration/" class="btn btn-default btn-rounded">Regsiter with us</a>
</div>
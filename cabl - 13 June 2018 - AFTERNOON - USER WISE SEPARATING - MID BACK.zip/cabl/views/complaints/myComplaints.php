<div class="row bg-title">
	<div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
		<h4 class="page-title">My Complaints</h4> 
	</div>		
	<div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
		<button class="btn btn-info btn-rounded pull-right" data-toggle="modal" data-target="#c-createComplaintModal">Create Complaint</button>			
	</div>
</div>
<!-- /.row -->


<!-- ============================================================== -->
<!-- CUSTOMER -->
<!-- ============================================================== -->
<div class="row" ng-if="login.userSessionDetails.userTypeId == 1003">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="white-box c-myBillsWrapper c-brad4 p-0">
			
			<div class="c-tableFilters c-brad4">				
				<div class="c-filterBtnGroup c-btnGroupPaymentMode">
					<h5>Status</h5>
					<div class="btn-group" role="group">					  
					  <div class="btn-group" role="group">
						<button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						  Select
						  <span class="caret"></span>
						</button>
						<ul class="dropdown-menu">
						  <li><a href="#">Open</a></li>
						  <li><a href="#">In Progress</a></li>
						  <li><a href="#">Closed</a></li>
						  <li><a href="#">Rejected</a></li>
						</ul>
					  </div>
					</div>
				</div>
			</div>
			
			<div class="table-responsive c-customTable">
				<table class="table">
					<thead>
						<tr>
							<th width="80">ID.</th>							
							<th width="450">Complaint Title</th>
							<th width="150">Status</th>
							<th width="150">Created Date</th>
							<th width="150">Action</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td width="80">0006</td>
							<td width="450">
								Not receiving signals								
							</td>
							<td width="150"><span class="badge badge-info">Open</span></td>
							<td width="150">28 May, 2018</td>
							<td width="150">
								<button class="btn btn-default btn-rounded text-info btn-sm" data-toggle="modal" data-target="#c-updateComplaintModal">Edit</button>
							</td>
						</tr>
						<tr>
							<td width="80">0005</td>
							<td width="450">Cable wire broken down due to rain storm</td>
							<td width="150"><span class="badge badge-warning">In Progress</span></td>
							<td width="150">13 May, 2018</td>
							<td width="150">
								<button class="btn btn-default btn-rounded text-info btn-sm" data-toggle="modal" data-target="#c-updateComplaintModal">Edit</button>
							</td>
						</tr>
						<tr>
							<td width="80">0004</td>
							<td width="450">Not receiving signals
								<div>
									<button type="button" data-target="#c-allInOneModal" data-toggle="modal" class="btn btn-link btn-sm text-info p-0">Details</button>
								</div>
							</td>
							<td width="150"><span class="badge badge-success">Closed</span></td>
							<td width="150">10 Apr, 2018</td>
							<td width="150">
								<button class="btn btn-default btn-rounded text-info btn-sm" data-toggle="modal" data-target="#c-updateComplaintModal">Edit</button>
							</td>
						</tr>
						<tr>
							<td width="80">0003</td>
							<td width="450">Set top box settings changed mistakenly
								<div>
									<button type="button" data-target="#c-allInOneModal" data-toggle="modal" class="btn btn-link btn-sm text-info p-0">Details</button>
								</div>
							</td>
							<td width="150"><span class="badge badge-success">Closed</span></td>
							<td width="150">21 Mar, 2018</td>
							<td width="150">
								<button class="btn btn-default btn-rounded text-info btn-sm" data-toggle="modal" data-target="#c-updateComplaintModal">Edit</button>
							</td>
						</tr>
						<tr>
							<td width="80">0002</td>
							<td width="450">Set top box not working
								<div>
									<button type="button" data-target="#c-allInOneModal" data-toggle="modal" class="btn btn-link btn-sm text-info p-0">Details</button>
								</div>
							</td>
							<td width="150"><span class="badge badge-success">Closed</span></td>
							<td width="150">05 Feb, 2018</td>
							<td width="150">
								<button class="btn btn-default btn-rounded text-info btn-sm" data-toggle="modal" data-target="#c-updateComplaintModal">Edit</button>
							</td>
						</tr>
						<tr>
							<td width="80">0001</td>
							<td width="450">Picture is not clear
								<div>
									<button type="button" data-target="#c-allInOneModal" data-toggle="modal" class="btn btn-link btn-sm text-info p-0">Details</button>
								</div>
							</td>
							<td width="150"><span class="badge badge-success">Closed</span></td>
							<td width="150">29 Jan, 2018</td>
							<td width="150">
								<button class="btn btn-default btn-rounded text-info btn-sm" data-toggle="modal" data-target="#c-updateComplaintModal">Edit</button>
							</td>
						</tr>					
					</tbody>
				</table>
			</div>
			
		</div>
	</div>
</div>
<!-- /.row -->

<!-- MODAL -->
<div id="c-allInOneModal" class="modal fade c-customModal">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header"> 
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">X</button>
				<h4 class="modal-title text-info">0004 - Not receiving signals</h4>
			</div>
			<div class="modal-body">
				
				<div class="c-infoKeyValWrapper">					
					<div class="c-infoKeyValRow">
						<div class="c-infoKey col-md-6 col-sm-8 col-xs-12">Created On<br>28 May, 2018 @10:30 AM</div>
						<div class="c-infoVal col-md-6 col-sm-4 col-xs-12">
							<span class="badge badge-info">Open</span>
							<p><small>Some note goes here. Some note goes here.</small></p>
						</div>
					</div>
					<div class="c-infoKeyValRow">
						<div class="c-infoKey col-md-6 col-sm-8 col-xs-12">Updated On<br>28 May, 2018 @11:30 AM</div>
						<div class="c-infoVal col-md-6 col-sm-4 col-xs-12">
							<span class="badge badge-warning">In Progress</span>
							<p><small>Some note goes here. Some note goes here.</small></p>
						</div>
					</div>
					<div class="c-infoKeyValRow">
						<div class="c-infoKey col-md-6 col-sm-8 col-xs-12">Closed On<br>28 May, 2018 @12:05 PM</div>
						<div class="c-infoVal col-md-6 col-sm-4 col-xs-12">
							<span class="badge badge-success">Closed</span>
							<p><small>Some note goes here. Some note goes here.</small></p>
						</div>
					</div>					
				</div>			
				
			</div>
			<div class="modal-footer c-singleBtn">  
				<button type="button" class="btn btn-info c-btnAction" id="" data-dismiss="modal">Okay</button>
			</div>
		</div>
	</div>
</div>
<!-- END MODAL -->

<!-- CREATE COMPLAINT MODAL -->
<div id="c-createComplaintModal" class="modal fade c-customModal">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header"> 
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">X</button>
				<h4 class="modal-title text-info">0007</h4>
			</div>
			<div class="modal-body">
				
				<div class="c-formModal">
					<form class="form-horizontal form-material">
						<div class="form-group">
							<label class="col-md-3 col-sm-4 col-xs-12">Status</label>
							<div class="col-md-9 col-sm-8 col-xs-12">
								<select class="form-control form-control-line">
									<option value="">Select</option>
									<option value="">Not receiving signals</option>
									<option value="">Cable wire broken down due to rain storm</option>
									<option value="">Set top box settings changed mistakenly</option>
									<option value="">Set top box not working</option>
									<option value="">Picture is not clear</option>									
								</select>						
							</div>
						</div>
						<div class="form-group">
							<label class="col-md-3 col-sm-4 col-xs-12">Note</label>
							<div class="col-md-9 col-sm-8 col-xs-12">
								<textarea class="form-control form-control-line" name="" rows="10"></textarea>						
							</div>
						</div>
					</form>
				</div>
				
			</div>
			<div class="modal-footer c-singleBtn">  
				<button type="button" class="btn btn-info c-btnAction" id="" data-dismiss="modal">Submit</button>
			</div>
		</div>
	</div>
</div>
<!-- END CREATE COMPLAINT MODAL -->

<!-- UPDATE COMPLAINT MODAL -->
<div id="c-updateComplaintModal" class="modal fade c-customModal">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header"> 
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">X</button>
				<h4 class="modal-title text-info">0004 - Not receiving signals</h4>
			</div>
			<div class="modal-body">
				
				<div class="c-formModal">
					<form class="form-horizontal form-material">
						<div class="form-group">
							<label class="col-md-3 col-sm-4 col-xs-12">Status</label>
							<div class="col-md-9 col-sm-8 col-xs-12">
								<select class="form-control form-control-line">
									<option value="">Select</option>
									<option value="">Not receiving signals</option>
									<option value="">Cable wire broken down due to rain storm</option>
									<option value="">Set top box settings changed mistakenly</option>
									<option value="">Set top box not working</option>
									<option value="">Picture is not clear</option>									
								</select>						
							</div>
						</div>
						<div class="form-group">
							<label class="col-md-3 col-sm-4 col-xs-12">Note</label>
							<div class="col-md-9 col-sm-8 col-xs-12">
								<textarea class="form-control form-control-line" name="" rows="10"></textarea>						
							</div>
						</div>
					</form>
				</div>
				
			</div>
			<div class="modal-footer c-singleBtn">  
				<button type="button" class="btn btn-info c-btnAction" id="" data-dismiss="modal">Submit</button>
			</div>
		</div>
	</div>
</div>
<!-- END UPDATE COMPLAINT MODAL -->

<!-- ============================================================== -->
<!-- END CUSTOMER -->
<!-- ============================================================== -->


<!-- ============================================================== -->
<!-- OPERATOR -->
<!-- ============================================================== -->
<div class="row" ng-if="login.userSessionDetails.userTypeId == 1002">
	<div class="col-md-12 col-sm-12 col-xs-12">
		
		<div class="c-customTabsWrapper">
			<ul class="nav nav-tabs">
				<li class="active">
					<a href="javascript:void(0);" class="c-bradTopOnly4" data-toggle="tab" data-target="#tabComplaintsOpen">
						Open <span class="badge badge-info">01</span>
					</a>
				</li>
				<li>
					<a href="javascript:void(0);" class="c-bradTopOnly4" data-toggle="tab" data-target="#tabComplaintsInProgress">
						In Progress <span class="badge badge-warning">01</span>
					</a>
				</li>
				<li>
					<a href="javascript:void(0);" class="c-bradTopOnly4" data-toggle="tab" data-target="#tabComplaintsClosed">
						Closed <span class="badge badge-success">04</span>
					</a>
				</li>
				<li>
					<a href="javascript:void(0);" class="c-bradTopOnly4" data-toggle="tab" data-target="#tabComplaintsRejected">
						Rejected <span class="badge badge-danger">0</span>
					</a>
				</li>
			</ul>
			<div class="tab-content">
				<div id="tabComplaintsOpen" class="tab-pane fade in active">					
					<div class="white-box c-myBillsWrapper p-0 c-brad4">	
						<div class="c-tableFilters c-brad4">
							<div class="c-filterBtnGroup c-searchFilter">
								<h5>Search</h5>
								<form class="form-horizontal form-material1">
									<div class="form-group m-0">
										<input type="text" name="" class="form-control" placeholder="Search by ID, Complaint Title or Date" />										
									</div>
								</form>
							</div>
							<div class="c-filterBtnGroup c-btnGroupMonth">
								<h5>Colony / Lane</h5>
								<div class="btn-group" role="group">
									<button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
									  Select
									  <span class="caret"></span>
									</button>
									<ul class="dropdown-menu">
									  <li><a href="#" class="active">Ingawale Colony</a></li>
									  <li><a href="#">Chenani Colony</a></li>
									  <li><a href="#">Sarvesh Park</a></li>
									  <li><a href="#">Ajinkya Tarun Mandal</a></li>
									</ul>
								</div>
							</div>							
						</div>						
						<div class="table-responsive c-customTable">
							<table class="table">
								<thead>
									<tr>
										<th width="80">ID.</th>							
										<th width="350">Complaint Title</th>
										<th width="150">Customer Name</th>
										<th width="150">Colony / Lane</th>
										<th width="150">Created Date</th>
										<th width="150">Action</th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td width="80">0006</td>
										<td width="350">
											Not receiving signals								
										</td>
										<td width="150">
											<div>Rana Da V.</div>
											<div><button class="btn btn-link btn-sm text-info p-0" data-toggle="popover-x" data-target="#myPopover1" data-placement="top">Details</button></div>
										</td>
										<td width="150">Ingawale Colony</td>
										<td width="150">28 May, 2018</td>
										<td width="150">
											<button class="btn btn-default btn-rounded text-info btn-sm" data-toggle="modal" data-target="#c-updateComplaintModal">Change Status</button>
										</td>
									</tr>					
								</tbody>
							</table>
						</div>			
					</div>					
				</div>
				<div id="tabComplaintsInProgress" class="tab-pane fade">
					<div class="white-box c-myBillsWrapper p-0 c-brad4">	
						<div class="c-tableFilters c-brad4">
							<div class="c-filterBtnGroup c-searchFilter">
								<h5>Search</h5>
								<form class="form-horizontal form-material1">
									<div class="form-group m-0">
										<input type="text" name="" class="form-control" placeholder="Search by ID, Complaint Title or Date" />										
									</div>
								</form>
							</div>
							<div class="c-filterBtnGroup c-btnGroupMonth">
								<h5>Colony / Lane</h5>
								<div class="btn-group" role="group">
									<button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
									  Select
									  <span class="caret"></span>
									</button>
									<ul class="dropdown-menu">
									  <li><a href="#" class="active">Ingawale Colony</a></li>
									  <li><a href="#">Chenani Colony</a></li>
									  <li><a href="#">Sarvesh Park</a></li>
									  <li><a href="#">Ajinkya Tarun Mandal</a></li>
									</ul>
								</div>
							</div>							
						</div>						
						<div class="table-responsive c-customTable">
							<table class="table">
								<thead>
									<tr>
										<th width="80">ID.</th>							
										<th width="350">Complaint Title</th>
										<th width="150">Customer Name</th>
										<th width="150">Colony / Lane</th>
										<th width="150">Created Date</th>
										<th width="150">Action</th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td width="80">0005</td>
										<td width="350">Cable wire broken down due to rain storm</td>
										<td width="150">
											<div>Rana Da V.</div>
											<div><button class="btn btn-link btn-sm text-info p-0" data-toggle="popover-x" data-target="#myPopover1" data-placement="top">Details</button></div>
										</td>
										<td width="150">Ingawale Colony</td>
										<td width="150">13 May, 2018</td>
										<td width="150">
											<button class="btn btn-default btn-rounded text-info btn-sm" data-toggle="modal" data-target="#c-updateComplaintModal">Change Status</button>
										</td>
									</tr>					
								</tbody>
							</table>
						</div>			
					</div>
				</div>
				<div id="tabComplaintsClosed" class="tab-pane fade">
					<div class="white-box c-myBillsWrapper  p-0 c-brad4">	
						<div class="c-tableFilters c-brad4">
							<div class="c-filterBtnGroup c-searchFilter">
								<h5>Search</h5>
								<form class="form-horizontal form-material1">
									<div class="form-group m-0">
										<input type="text" name="" class="form-control" placeholder="Search by ID, Complaint Title or Date" />										
									</div>
								</form>
							</div>
							<div class="c-filterBtnGroup c-btnGroupMonth">
								<h5>Colony / Lane</h5>
								<div class="btn-group" role="group">
									<button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
									  Select
									  <span class="caret"></span>
									</button>
									<ul class="dropdown-menu">
									  <li><a href="#" class="active">Ingawale Colony</a></li>
									  <li><a href="#">Chenani Colony</a></li>
									  <li><a href="#">Sarvesh Park</a></li>
									  <li><a href="#">Ajinkya Tarun Mandal</a></li>
									</ul>
								</div>
							</div>							
						</div>						
						<div class="table-responsive c-customTable">
							<table class="table">
								<thead>
									<tr>
										<th width="80">ID.</th>							
										<th width="350">Complaint Title</th>
										<th width="150">Customer Name</th>
										<th width="150">Colony / Lane</th>
										<th width="150">Created Date</th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td width="80">0004</td>
										<td width="350">Not receiving signals
											<div>
												<button type="button" data-target="#c-allInOneModal" data-toggle="modal" class="btn btn-link btn-sm text-info p-0">Details</button>
											</div>
										</td>
										<td width="150">
											<div>Rana Da V.</div>
											<div><button class="btn btn-link btn-sm text-info p-0" data-toggle="popover-x" data-target="#myPopover1" data-placement="top">Details</button></div>
										</td>
										<td width="150">Ingawale Colony</td>
										<td width="150">10 Apr, 2018</td>
									</tr>
									<tr>
										<td width="80">0003</td>
										<td width="350">Set top box settings changed mistakenly
											<div>
												<button type="button" data-target="#c-allInOneModal" data-toggle="modal" class="btn btn-link btn-sm text-info p-0">Details</button>
											</div>
										</td>
										<td width="150">
											<div>Rana Da V.</div>
											<div><button class="btn btn-link btn-sm text-info p-0" data-toggle="popover-x" data-target="#myPopover1" data-placement="top">Details</button></div>
										</td>
										<td width="150">Ingawale Colony</td>
										<td width="150">21 Mar, 2018</td>
									</tr>
									<tr>
										<td width="80">0002</td>
										<td width="350">Set top box not working
											<div>
												<button type="button" data-target="#c-allInOneModal" data-toggle="modal" class="btn btn-link btn-sm text-info p-0">Details</button>
											</div>
										</td>
										<td width="150">
											<div>Rana Da V.</div>
											<div><button class="btn btn-link btn-sm text-info p-0" data-toggle="popover-x" data-target="#myPopover1" data-placement="top">Details</button></div>
										</td>
										<td width="150">Ingawale Colony</td>
										<td width="150">05 Feb, 2018</td>
									</tr>
									<tr>
										<td width="80">0001</td>
										<td width="350">Picture is not clear
											<div>
												<button type="button" data-target="#c-allInOneModal" data-toggle="modal" class="btn btn-link btn-sm text-info p-0">Details</button>
											</div>
										</td>
										<td width="150">
											<div>Rana Da V.</div>
											<div><button class="btn btn-link btn-sm text-info p-0" data-toggle="popover-x" data-target="#myPopover1" data-placement="top">Details</button></div>
										</td>
										<td width="150">Ingawale Colony</td>
										<td width="150">29 Jan, 2018</td>
									</tr>					
								</tbody>
							</table>
						</div>			
					</div>
				</div>
				<div id="tabComplaintsRejected" class="tab-pane fade">
					<div class="c-mutedMessage c-ht250 c-brad4">
						<span>
							<i class="flaticon-problem"></i>
							No Records Found
						</span>
					</div>
				</div>
			</div>	
		</div>
		
		
	</div>
</div>
<!-- /.row -->

<!-- FORM MODAL -->
<div id="c-updateComplaintModal" class="modal fade c-customModal">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header"> 
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">X</button>
				<h4 class="modal-title text-info">0004 - Not receiving signals</h4>
			</div>
			<div class="modal-body">
				
				<div class="c-formModal">
					<form class="form-horizontal form-material">
						<div class="form-group">
							<label class="col-md-3 col-sm-4 col-xs-12">Status</label>
							<div class="col-md-5 col-sm-6 col-xs-12">
								<select class="form-control form-control-line">
									<option value="">Select</option>
									<option value="">In Progress</option>
									<option value="">Closed</option>
									<option value="">Rejected</option>									
								</select>						
							</div>
						</div>
						<div class="form-group">
							<label class="col-md-3 col-sm-4 col-xs-12">Note</label>
							<div class="col-md-8 col-sm-8 col-xs-12">
								<textarea class="form-control form-control-line" name="" rows="10"></textarea>						
							</div>
						</div>
					</form>
				</div>
				
			</div>
			<div class="modal-footer c-singleBtn">  
				<button type="button" class="btn btn-info c-btnAction" id="" data-dismiss="modal">Submit</button>
			</div>
		</div>
	</div>
</div>
<!-- END FORM MODAL -->

<!-- DETAILS MODAL -->
<div id="c-allInOneModal" class="modal fade c-customModal">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header"> 
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">X</button>
				<h4 class="modal-title text-info">0004 - Not receiving signals</h4>
			</div>
			<div class="modal-body">
				
				<div class="c-infoKeyValWrapper">					
					<div class="c-infoKeyValRow">
						<div class="c-infoKey col-md-6 col-sm-8 col-xs-12">Created On<br>28 May, 2018 @10:30 AM</div>
						<div class="c-infoVal col-md-6 col-sm-4 col-xs-12">
							<span class="badge badge-info">Open</span>
							<p><small>Some note goes here. Some note goes here.</small></p>
						</div>
					</div>
					<div class="c-infoKeyValRow">
						<div class="c-infoKey col-md-6 col-sm-8 col-xs-12">Updated On<br>28 May, 2018 @11:30 AM</div>
						<div class="c-infoVal col-md-6 col-sm-4 col-xs-12">
							<span class="badge badge-warning">In Progress</span>
							<p><small>Some note goes here. Some note goes here.</small></p>
						</div>
					</div>
					<div class="c-infoKeyValRow">
						<div class="c-infoKey col-md-6 col-sm-8 col-xs-12">Closed On<br>28 May, 2018 @12:05 PM</div>
						<div class="c-infoVal col-md-6 col-sm-4 col-xs-12">
							<span class="badge badge-success">Closed</span>
							<p><small>Some note goes here. Some note goes here.</small></p>
						</div>
					</div>					
				</div>			
				
			</div>
			<div class="modal-footer c-singleBtn">  
				<button type="button" class="btn btn-info c-btnAction" id="" data-dismiss="modal">Okay</button>
			</div>
		</div>
	</div>
</div>
<!-- END DETAILS MODAL -->

<!-- PopoverX content -->
<div id="myPopover1" class="popover popover-x popover-default c-customPopover c-brad12">
	<div class="arrow"></div>
	<h3 class="popover-header popover-title c-bradTopOnly12">
		<!--<span class="close pull-right" data-dismiss="popover-x">&times;</span>-->
		Mr. Rana Da Vasagadekar
	</h3>
	<div class="popover-body popover-content">		
		<div class="c-infoKeyValWrapper">					
			<div class="c-infoKeyValRow">
				<div class="c-infoKey col-md-4 col-sm-4 col-xs-12">Cust. ID.</div>
				<div class="c-infoVal col-md-8 col-sm-8 col-xs-12"><span>00001234</span></div>
			</div>
			<div class="c-infoKeyValRow">
				<div class="c-infoKey col-md-4 col-sm-4 col-xs-12">Address</div>
				<div class="c-infoVal col-md-8 col-sm-8 col-xs-12">121, B Ward, Vasagade. Tal - Karvir. Dist - Kolhapur</div>
			</div>
			<div class="c-infoKeyValRow">
				<div class="c-infoKey col-md-4 col-sm-4 col-xs-12">Colony / Lane / Ward</div>
				<div class="c-infoVal col-md-8 col-sm-8 col-xs-12">Ingawale Colony</div>
			</div>
			<div class="c-infoKeyValRow">
				<div class="c-infoKey col-md-4 col-sm-4 col-xs-12">Mobile No.</div>
				<div class="c-infoVal col-md-8 col-sm-8 col-xs-12"><a href="tel:+919955885544">+91 9955885544</a></div>
			</div>					
		</div>		
	</div>	
	<div class="popover-footer c-bradBottomOnly12">
		<button type="button" class="btn btn-sm btn-default btn-bordered btn-rounded text-info" data-dismiss="popover-x">Close</button>
	</div>
</div>
<!-- ============================================================== -->
<!-- END OPERATOR -->
<!-- ============================================================== -->
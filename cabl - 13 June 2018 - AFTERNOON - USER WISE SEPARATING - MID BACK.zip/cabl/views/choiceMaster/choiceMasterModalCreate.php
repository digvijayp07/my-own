<div class="modal-header"> 
	<button type="button" class="close" ng-click="cancel()">X</button> <!-- data-dismiss="modal" aria-hidden="true" -->
	<h4 class="modal-title text-info">Create Choice Master</h4>
</div>
<div class="modal-body">
	<div class="c-formModal">
		<form class="form-horizontal form-material c-frmChoiceMaster" name="frmChoiceMaster" method="POST" novalidate>			
			<div class="form-group">
				<label class="col-md-3 col-sm-4 col-xs-12">Type <span class="c-requiredSign">*</span></label>
				<div class="col-md-9 col-sm-8 col-xs-12">
					<select class="form-control" 
						name="txtTypeId" 
						ng-init="getAllActiveChoiceMasters(0);"
						ng-model="frmChoiceMasterData.typeId" 
						required>
						<option value="" selected="selected">Select</option>
						<option value="0">Self Master</option>
						<option ng-repeat="data in allActiveChoiceMastersOptions" 
								value="{{data.chId}}">{{data.chName}}</option>
					</select>
					<div class="c-errorMessages" ng-show="(frmChoiceMaster.txtTypeId.$invalid)">				
						<p ng-show="(frmChoiceMaster.txtTypeId.$touched && frmChoiceMaster.txtTypeId.$error.required) || (frmChoiceMaster.txtTypeId.$error.required && isFormValid==false)">Type is required</p>
					</div>
				</div>
			</div>
			<div class="form-group">
				<label class="col-md-3 col-sm-4 col-xs-12">Name <span class="c-requiredSign">*</span></label>
				<div class="col-md-9 col-sm-8 col-xs-12">
					<input type="text" class="form-control" 
						name="txtName" 
						ng-model="frmChoiceMasterData.name" 
						required>
					
					<div class="c-errorMessages" ng-show="(frmChoiceMaster.txtName.$invalid)">				
						<p ng-show="(frmChoiceMaster.txtName.$touched && frmChoiceMaster.txtName.$error.required) || (frmChoiceMaster.txtName.$error.required && isFormValid==false)">Name is required</p>
					</div>
				</div>
			</div>
			<div class="form-group">
				<label class="col-md-3 col-sm-4 col-xs-12">Description</label>
				<div class="col-md-9 col-sm-8 col-xs-12">
					<textarea class="form-control form-control-line" rows="10" 
						name="txtDescription"  
						ng-model="frmChoiceMasterData.description" 
						ng-maxlength="1000" 
						ng-model-options="{allowInvalid: true}"></textarea>						
				</div>
			</div>
			<div class="form-group">
				<label class="col-md-3 col-sm-4 col-xs-12">Is Active? <span class="c-requiredSign">*</span></label>
				<div class="col-md-9 col-sm-8 col-xs-12">
					<select class="form-control" 
						name="txtIsActive"
						ng-model="frmChoiceMasterData.isActive"
						required>
						<option value="" selected="selected">Select</option>
						<option value="1">Active</option>
						<option value="0">In active</option>
					</select>	
					
					<div class="c-errorMessages" ng-show="(frmChoiceMaster.txtIsActive.$invalid)">				
						<p ng-show="(frmChoiceMaster.txtIsActive.$touched && frmChoiceMaster.txtIsActive.$error.required) || (frmChoiceMaster.txtIsActive.$error.required && isFormValid==false)">Is Active is required</p>
					</div>
				</div>
			</div>		
			
		</form>
	</div>
	
</div>
<div class="modal-footer c-singleBtn">  
	<button type="button" class="btn btn-info c-btnAction" 
				ng-click="choiceMasterCreate(frmChoiceMaster, frmChoiceMasterData);" 
				ng-enter="choiceMasterCreate(frmChoiceMaster, frmChoiceMasterData);">Submit</button>
</div>
<div class="row bg-title">
	<div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
		<h4 class="page-title">Choice Master</h4> 
	</div>		
	<div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
		<!--<button class="btn btn-info btn-rounded pull-right" data-toggle="modal" data-target="#c-choiceMasterModalCreate">Create Choice Master</button>-->
		<button class="btn btn-info btn-rounded pull-right" ng-click="openModal()">Create Choice Master</button>			
	</div>
</div>
<!-- /.row -->
<!-- .row -->
<div class="row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="white-box c-myBillsWrapper c-brad4 p-0">
			
			<div class="c-tableFilters c-brad4">				
				<div class="c-filterBtnGroup c-btnGroupPaymentMode">
					<h5>Status</h5>
					<div class="btn-group" role="group">					  
					  <div class="btn-group" role="group">
						<button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						  Select
						  <span class="caret"></span>
						</button>
						<ul class="dropdown-menu">
						  <li><a href="#">Master</a></li>
						  <li><a href="#">User Type</a></li>
						</ul>
					  </div>
					</div>
				</div>
			</div>
			
			<div class="table-responsive c-customTable">
				<table class="table">
					<thead>
						<tr>
							<th width="80">ID.</th>							
							<th width="350">Name</th>
							<th width="150">Type</th>
							<th width="150">Is Active?</th>
							<th width="150">Action</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td width="80">1</td>
							<td width="350">
								User Type							
							</td>
							<td width="150">Master</td>
							<td width="150"><span class="badge badge-success">Active</span></td>
							<td width="150">
								<button class="btn btn-default btn-rounded text-info btn-sm" data-toggle="modal" data-target="#c-choiceMasterModalEdit">Edit</button>
							</td>
						</tr>
						<tr>
							<td width="80">1001</td>
							<td width="350">
								Super IT Admin							
							</td>
							<td width="150">User Type</td>
							<td width="150"><span class="badge badge-success">Active</span></td>
							<td width="150">
								<button class="btn btn-default btn-rounded text-info btn-sm" data-toggle="modal" data-target="#c-choiceMasterModalEdit">Edit</button>
							</td>
						</tr>
						<tr>
							<td width="80">1002</td>
							<td width="350">
								Operator							
							</td>
							<td width="150">User Type</td>
							<td width="150"><span class="badge badge-success">Active</span></td>
							<td width="150">
								<button class="btn btn-default btn-rounded text-info btn-sm" data-toggle="modal" data-target="#c-choiceMasterModalEdit">Edit</button>
							</td>
						</tr>
						<tr>
							<td width="80">1003</td>
							<td width="350">
								Customer							
							</td>
							<td width="150">User Type</td>
							<td width="150"><span class="badge badge-success">Active</span></td>
							<td width="150">
								<button class="btn btn-default btn-rounded text-info btn-sm" data-toggle="modal" data-target="#c-choiceMasterModalEdit">Edit</button>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
			
		</div>
	</div>
</div>
<!-- /.row -->



<!-- MODAL -->
<div id="c-allInOneModal" class="modal fade c-customModal">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header"> 
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">X</button>
				<h4 class="modal-title text-info">0004 - Not receiving signals</h4>
			</div>
			<div class="modal-body">
				
				<div class="c-infoKeyValWrapper">					
					<div class="c-infoKeyValRow">
						<div class="c-infoKey col-md-6 col-sm-8 col-xs-12">Created On<br>28 May, 2018 @10:30 AM</div>
						<div class="c-infoVal col-md-6 col-sm-4 col-xs-12">
							<span class="badge badge-info">Open</span>
							<p><small>Some note goes here. Some note goes here.</small></p>
						</div>
					</div>
					<div class="c-infoKeyValRow">
						<div class="c-infoKey col-md-6 col-sm-8 col-xs-12">Updated On<br>28 May, 2018 @11:30 AM</div>
						<div class="c-infoVal col-md-6 col-sm-4 col-xs-12">
							<span class="badge badge-warning">In Progress</span>
							<p><small>Some note goes here. Some note goes here.</small></p>
						</div>
					</div>
					<div class="c-infoKeyValRow">
						<div class="c-infoKey col-md-6 col-sm-8 col-xs-12">Closed On<br>28 May, 2018 @12:05 PM</div>
						<div class="c-infoVal col-md-6 col-sm-4 col-xs-12">
							<span class="badge badge-success">Closed</span>
							<p><small>Some note goes here. Some note goes here.</small></p>
						</div>
					</div>					
				</div>			
				
			</div>
			<div class="modal-footer c-singleBtn">  
				<button type="button" class="btn btn-info c-btnAction" id="" data-dismiss="modal">Okay</button>
			</div>
		</div>
	</div>
</div>
<!-- END MODAL -->

<!-- CREATE COMPLAINT MODAL -->
<div id="c-choiceMasterModalCreate" class="modal fade c-customModal">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header"> 
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">X</button>
				<h4 class="modal-title text-info">Create Choice Master</h4>
			</div>
			<div class="modal-body">
				
				<div class="c-formModal">
					<form class="form-horizontal form-material">
						<div class="form-group">
							<label class="col-md-3 col-sm-4 col-xs-12">Status</label>
							<div class="col-md-9 col-sm-8 col-xs-12">
								<select class="form-control form-control-line">
									<option value="">Select</option>
									<option value="">Not receiving signals</option>
									<option value="">Cable wire broken down due to rain storm</option>
									<option value="">Set top box settings changed mistakenly</option>
									<option value="">Set top box not working</option>
									<option value="">Picture is not clear</option>									
								</select>						
							</div>
						</div>
						<div class="form-group">
							<label class="col-md-3 col-sm-4 col-xs-12">Note</label>
							<div class="col-md-9 col-sm-8 col-xs-12">
								<textarea class="form-control form-control-line" name="" rows="10"></textarea>						
							</div>
						</div>
					</form>
				</div>
				
			</div>
			<div class="modal-footer c-singleBtn">  
				<button type="button" class="btn btn-info c-btnAction" id="" data-dismiss="modal">Submit</button>
			</div>
		</div>
	</div>
</div>
<!-- END CREATE COMPLAINT MODAL -->

<!-- UPDATE COMPLAINT MODAL -->
<div id="c-choiceMasterModalEdit" class="modal fade c-customModal">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header"> 
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">X</button>
				<h4 class="modal-title text-info">0004 - Not receiving signals</h4>
			</div>
			<div class="modal-body">
				
				<div class="c-formModal">
					<form class="form-horizontal form-material">
						<div class="form-group">
							<label class="col-md-3 col-sm-4 col-xs-12">Status</label>
							<div class="col-md-9 col-sm-8 col-xs-12">
								<select class="form-control form-control-line">
									<option value="">Select</option>
									<option value="">Not receiving signals</option>
									<option value="">Cable wire broken down due to rain storm</option>
									<option value="">Set top box settings changed mistakenly</option>
									<option value="">Set top box not working</option>
									<option value="">Picture is not clear</option>									
								</select>						
							</div>
						</div>
						<div class="form-group">
							<label class="col-md-3 col-sm-4 col-xs-12">Note</label>
							<div class="col-md-9 col-sm-8 col-xs-12">
								<textarea class="form-control form-control-line" name="" rows="10"></textarea>						
							</div>
						</div>
					</form>
				</div>
				
			</div>
			<div class="modal-footer c-singleBtn">  
				<button type="button" class="btn btn-info c-btnAction" id="" data-dismiss="modal">Submit</button>
			</div>
		</div>
	</div>
</div>
<!-- END UPDATE COMPLAINT MODAL -->
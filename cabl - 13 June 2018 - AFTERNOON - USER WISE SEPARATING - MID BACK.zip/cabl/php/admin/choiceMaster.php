<?PHP

// include connection page or open database connection
require_once '../dbConnection.php';
	
	//--------------------------------------------------------------//
	// get all active masters
	if($_SERVER['REQUEST_METHOD'] === 'GET' && $_GET['httpRequest'] == 'getAllActiveChoiceMasters') {	
	
		$query = "SELECT * FROM tbl_choice_master 
		WHERE chTypeId = ".$_GET['chTypeId']." AND isActive = 1 AND isDelete = 0
		ORDER BY chName ASC";
		$result = mysqli_query($con, $query) or die(mysqli_error($con));
		$resultArr = array();

		if(mysqli_num_rows($result) > 0) {
			while($row = mysqli_fetch_assoc($result)) {
				$resultArr[] = $row;
			}
			
			$resultArr['statusCode'] = 200;
			print_r(json_encode($resultArr));
		}
		else {
			$resultArr['statusCode'] = 400;
			$resultArr['statusMessage'] = 'No data found';
			print_r(json_encode($resultArr));
		}			
	}
	//--------------------------------------------------------------//
	
	//--------------------------------------------------------------//
	if($_SERVER['REQUEST_METHOD'] === 'POST') {
		
		$postdata = file_get_contents("php://input");
		$request = json_decode($postdata);		
				
		//--------------------------------------------------------------//
		// Create Choice Master
		if($request->httpRequest == 'createChoiceMaster') {
			
			$query = "SELECT * FROM tbl_choice_master 
				WHERE chName = '".$request->name."'";
			$result = mysqli_query($con, $query) or die(mysqli_error($con));
			// Check if record already exists or not. 0 means does not exist. Valid.
			if(mysqli_num_rows($result) == 0) { 
			
					// GET LAST ID
					if($request->typeId == 0) {
						$query2 = "SELECT chId as totalCount FROM tbl_choice_master 
						WHERE chTypeId = 0 
						ORDER BY chId DESC 
						LIMIT 1";
						$result2 = mysqli_query($con, $query2) or die(mysqli_error($con));
						
						if(mysqli_num_rows($result2) == 0) {
							// if it is first record
							$id = 1;
						}
						else {
							$resultArr2=mysqli_fetch_assoc($result2);
							$id = $resultArr2['totalCount']+1;							
						}
					}
					else {
						$query2 = "SELECT chId as totalCount FROM tbl_choice_master 
						WHERE chTypeId != 0 
						ORDER BY chId DESC 
						LIMIT 1";
						$result2 = mysqli_query($con, $query2) or die(mysqli_error($con));						
						
						if(mysqli_num_rows($result2) == 0) {
							// if it is first of its type i.e not a master then start id from 1001 else 0
							$id = 1001;
						}
						else {
							$resultArr2=mysqli_fetch_assoc($result2);							
							$id = $resultArr2['totalCount']+1;
						}
					}
					// END GET LAST ID
					
					
					// INSERT
					$query3 = "INSERT INTO tbl_choice_master (chId, chName, chTypeId, chDescription, isActive) 
					VALUES(".$id.", '".$request->name."', '".$request->typeId."', '".$request->description."', '".$request->isActive."')";
					$result3 = mysqli_query($con, $query3) or die(mysqli_error($con));
					$resultArr3 = array();
				
					if($result3) {	
						$resultArr3['statusCode'] = 200;
						$resultArr3['statusMessage'] = 'Created choice master successfully.';
						print_r(json_encode($resultArr3));
					}
					else {
						$resultArr3['statusCode'] = 400;
						$resultArr3['statusMessage'] = 'Some thing went wrong.';
						print_r(json_encode($resultArr3));	
					}
					// END INSERT
			}
			else {
				$resultArr['statusCode'] = 400;
				$resultArr['statusMessage'] = 'The record with this name already exists. Kindly, use another name.';
				print_r(json_encode($resultArr));	
			}
		}
		//--------------------------------------------------------------//
			
	}
	//--------------------------------------------------------------//
	
	
	
// close database connection
mysqli_close($con);
?>
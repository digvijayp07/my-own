<?PHP

// include connection page or open database connection
require_once 'dbConnection.php';
	
	
	if($_SERVER['REQUEST_METHOD'] === 'POST') {
		
		$postdata = file_get_contents("php://input");
		$request = json_decode($postdata);		
		
		//--------------------------------------------------------------//
		// user login
		if($request->httpRequest == 'userLogin') {	
			// 
			$password = md5($request->password);
			
			// validate users id and password 
			$query = "SELECT * FROM tbl_users WHERE id = '".$request->customerId."' AND password = '".$password."'";
			$result = mysqli_query($con, $query) or die(mysqli_error($con));						
			$resultArr = array();
			
			if(mysqli_num_rows($result) > 0) {
				$resultArr = mysqli_fetch_assoc($result);
				
				if($resultArr['isActive'] == 0) {
					$resultArr['statusCode'] = 400;
					$resultArr['statusMessage'] = 'This user is not active. Kindly, contact your administrator now.';
					print_r(json_encode($resultArr));	
					return;
				}
				else if($resultArr['isDelete'] == 1) {
					$resultArr['statusCode'] = 400;
					$resultArr['statusMessage'] = 'This user is deleted from the system. Kindly, contact your administrator now.';
					print_r(json_encode($resultArr));	
					return;
				}
				else {
					// after successfull validation, Select users information from both tables to store as session data 
					$query2 = "SELECT users.id, usersInfo.firstName, usersInfo.middleName, usersInfo.lastName, usersInfo.lastName, 
						concat(usersInfo.firstName, ' ', usersInfo.lastName) as usersFullName, choiceMaster.chId as userTypeId, choiceMaster.chName as userType
						FROM tbl_users users, tbl_users_info usersInfo, tbl_choice_master choiceMaster  
						WHERE users.id = '".$request->customerId."' AND users.id = usersInfo.id AND users.userTypeId = choiceMaster.chId";
					$result2 = mysqli_query($con, $query2) or die(mysqli_error($con));					
					$resultArr = array();			
					 
					if(mysqli_num_rows($result2) > 0) {				
						
						while($row2 = mysqli_fetch_assoc($result2)) {
							$resultArr[] = $row2;
						}			
						
						// set users isOnline status as online (i.e. 1)
						$query3 = "UPDATE tbl_users 
							SET isOnline = 1
							WHERE id = '".$request->customerId."'";
						mysqli_query($con, $query3) or die(mysqli_error($con));	
						
						$resultArr['statusCode'] = 200;
						$resultArr['statusMessage'] = 'Login successful. Redirecting...';
						print_r(json_encode($resultArr));					
					}
					else {
						$resultArr['statusCode'] = 400;
						$resultArr['statusMessage'] = 'Did not find users information';
						print_r(json_encode($resultArr));	
					}
				}
			}
			else {
				$resultArr['statusCode'] = 400;
				$resultArr['statusMessage'] = 'Invalid Customer ID or Password';
				print_r(json_encode($resultArr));	
			}
		}
		//--------------------------------------------------------------//
		
		
		//--------------------------------------------------------------//
		// user logout			
		if($request->httpRequest == 'userLogout') {
			
			// set users isOnline status as online (i.e. 1)
			$query4 = "UPDATE tbl_users 
				SET isOnline = 0
				WHERE id = '".$request->customerId."'";
			$result4 = mysqli_query($con, $query4) or die(mysqli_error($con));	
			$resultArr = array();
			
			if(mysqli_affected_rows($con) > 0) {
				$resultArr['statusCode'] = 200;
				$resultArr['statusMessage'] = 'Logout successful. Redirecting...';
				print_r(json_encode($resultArr));	
				
				
				// session start
				session_start();			
				// remove all session variables
				session_unset(); 			
				// destroy the session 
				session_destroy(); 
			}
			else {
				$resultArr['statusCode'] = 400;
				$resultArr['statusMessage'] = 'Could not able to logout. Please try once again.';
				print_r(json_encode($resultArr));	
			}
		}
		//--------------------------------------------------------------//
			
	}
	//--------------------------------------------------------------//
	
	
	
	
	
	
	
// close database connection
mysqli_close($con);
?>
// Create application controller and add dependency injection here
var myApp = angular.module('myApp', 
	[
		'ngSanitize', 
		'ngRoute',
		'LocalStorageModule',
		'ngAnimate',
		'ui.bootstrap',
		'ngTable'
	]
);

myApp.constant('myConfig', {
    appName: 'Cabl App',
    appVersion: 1.0,
	appRoot: 'http://localhost:8080/cabl/',
    baseRouteUrl: 'http://localhost:8080/cabl/#/',
	operatorRouteUrl: 'http://localhost:8080/cabl/operator/#/'
});
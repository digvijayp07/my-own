myApp.config(['$routeProvider', function($routeProvider) {
		
		$routeProvider
		.when('/dashboard', {
			controller: 'dashboardCtrl',
            templateUrl: 'views/dashboard/dashboard.php'
		})
		
		/* =================================================================================
		COMMON  
		================================================================================= */	
		/* LOGIN PAGES */
		.when('/login', {
			controller: 'loginCtrl',
            templateUrl: 'views/login/login.php'
		})
		.when('/forgotPassword', {
			controller: 'loginCtrl',
            templateUrl: 'views/login/forgotPassword.php'
		})
		.when('/registrationRequest', {
			controller: 'loginCtrl',
            templateUrl: 'views/login/registrationRequest.php'
		})
		
		
		/* ACCOUNT */
		.when('/myAccount', {
			controller: 'accountCtrl',
            templateUrl: 'views/account/myAccount.php'
		})
		.when('/myAccountEdit', {
			controller: 'accountCtrl',
            templateUrl: 'views/account/myAccountEdit.php'
		})
		
		/* BILLS */
		.when('/myBills', {
			controller: 'billsCtrl',
            templateUrl: 'views/bills/myBills.php'
		})
		
		/* COMPLAINTS */
		.when('/myComplaints', {
			controller: 'complaintsCtrl',
            templateUrl: 'views/complaints/myComplaints.php'
		})	

		
		/* =================================================================================
		CUSTOMER  
		================================================================================= */	
		/* PACKAGE */
		.when('/myPackage', {
			controller: 'packageCtrl',
            templateUrl: 'views/package/myPackage.php'
		})


		
		/* =================================================================================
		ADMIN  
		================================================================================= */		
		/* REGISTRATION */
		.when('/registration', {
			controller: 'registrationCtrl',
            templateUrl: 'views/users/registration.php'
		})
		/* CHOICE MASTER */
		.when('/choiceMaster', {
			controller: 'choiceMasterCtrl',
            templateUrl: 'views/choiceMaster/choiceMaster.php'
		})
		
		/* =================================================================================
		OPERATOR  
		================================================================================= */	
		/* CUSTOMERS */
		.when('/myCustomers', {
			controller: 'customersCtrl',
            templateUrl: 'views/customers/myCustomers.php'
		})
		
		
		/* ERROR PAGES */
		.when('/404', {
			controller: 'applicationCtrl',
            templateUrl: 'views/errorPage/pageNotFound.php'
		})
		.otherwise({
			redirectTo: '/404'
		});		
		
		
		
}]);
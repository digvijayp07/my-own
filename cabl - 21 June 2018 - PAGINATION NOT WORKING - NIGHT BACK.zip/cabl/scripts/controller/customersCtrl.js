myApp.controller('customersCtrl', customersCtrl);

function customersCtrl($scope, $rootScope, $http, $location, localStorageService, $timeout, myConfig) {	
	
	// set page title
    $rootScope.rsPageTitle = 'My Customers | Operator';
	
	// set session and view type(login or after login).. so that related view is rendered
	$rootScope.rsSetViewType('afterLogin');
	$rootScope.rsSessionActive = true;
	
	//console.log('Customers Controller');
	//// init
	init();
	function init() {
		initPlugins();
		
		// check session
		$timeout(function() {
			$rootScope.rsCheckSessionExists();
		}, 0);
	}
	
}
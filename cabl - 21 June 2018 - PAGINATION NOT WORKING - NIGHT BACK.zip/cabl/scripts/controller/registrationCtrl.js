myApp.controller('registrationCtrl', registrationCtrl);

function registrationCtrl($scope, $rootScope, $http, $location, localStorageService, $timeout, myConfig) {	
	
	// set page title
    $rootScope.rsPageTitle = 'User Registration';	
	
	// set session and view type(login or after login).. so that related view is rendered
	$rootScope.rsSetViewType('afterLogin');
	$rootScope.rsSessionActive = true;
	
	// set scope variables
	$scope.frmRegistrationData = {};
	
	//console.log(Registration);
	//// init
	init();
	function init() {
		initPlugins();		
	}
	
	
	
	//---------------------------------------------------------------//
	//***************** Get Regsitered Users Count *****************//
	//-------------------------------------------------------------//
	getRegisteredUsersCount();
	
	function getRegisteredUsersCount() {
		$http({
			url: 'php/userRegistration.php', 
			method: "GET",
			params: {httpRequest: 'getRegisteredUsersCount'}
		})
		.success(function(data){
			//console.log(data);
			$scope.userId = data;			
			$scope.frmRegistrationData.userId = $scope.userId;
		});
		
	}
	//--------------------------------------------------------------//
	
	
	//--------------------------------------------------------------//
	//***************** New Registration Submit *******************//
	//------------------------------------------------------------//
	$scope.registerNewUser = function(formName, formData) {
		$scope.isFormValid = false;
		if(formName.$valid) {
			$scope.isFormValid = true;
			
			$http({
				url: 'php/userRegistration.php', 
				method: "POST",
				data: {
						httpRequest: 'registerNewUser',
						userId: formData.userId,
						userTypeId: formData.userTypeId, 
						password: formData.password,
						confirmPassword: formData.confirmPassword,
						firstName: formData.firstName,
						middleName: formData.middleName,
						lastName: formData.lastName,
						countryCode: formData.countryCode,
						mobileNumber: formData.mobileNumber,
						address: formData.address					
				},
				headers : {
						'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
				}
			})
			.success(function(data){
				//console.log(data);
				
				if(data.statusCode == 200) {
					alertify.success(data.statusMessage);
					
					// reset form data
					$scope.frmRegistrationData = angular.copy({});
					formName.$setPristine();
					formName.$setUntouched();
					formName.$rollbackViewValue();
					
					$timeout(function() {
						document.location.reload();
					}, 500);	
				}	
				
				if(data.statusCode == 400) {
					alertify.error(data.statusMessage);
				}
			});
		}
		else {
			$scope.isFormValid = false;
		}
		
	}
	//--------------------------------------------------------------//
	
}
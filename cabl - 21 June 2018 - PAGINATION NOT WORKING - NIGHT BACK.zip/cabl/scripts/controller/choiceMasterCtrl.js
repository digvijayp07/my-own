myApp.controller('choiceMasterCtrl', choiceMasterCtrl);

function choiceMasterCtrl($scope, $rootScope, $http, $location, localStorageService, $timeout, myConfig, $uibModal, NgTableParams) {	
	
	// set page title
    $rootScope.rsPageTitle = 'Choice Master';
	
	// set session and view type(login or after login).. so that related view is rendered
	$rootScope.rsSetViewType('afterLogin');
	$rootScope.rsSessionActive = true;
	
	// set scope variables
	$scope.frmChoiceMasterData = {};	
	if(Object.keys($rootScope.rsModalTempData).length != 0) {
		$scope.frmChoiceMasterData = $rootScope.rsGetmyModalData();	
		$rootScope.rsModalTempData = {};		
	}	
			
	//console.log('Choice Master Controller');
	//// init
	init();
	function init() {
		initPlugins();
		
		// check session
		$timeout(function() {
			$rootScope.rsCheckSessionExists();
		}, 0);
	}
	
	//--------------------------------------------------------------//
	//****************** COMMON FUNCTIONS *********************//
	//------------------------------------------------------------//	
	$scope.cancelModal = function(){
		$scope.$dismiss('cancel');
	};
	$scope.closeModal = function(){
		$scope.$close(); 
	};

	
	//--------------------------------------------------------------//
	//****************** CREATE EDIT CHOICE MASTER *********************//
	//------------------------------------------------------------//	
	$scope.choiceMasterCreateEdit = function(formName, formData) {
		$scope.isFormValid = false;		
		if(formName.$valid) {			
			$scope.isFormValid = true;						
			$http({
				url: 'php/choiceMaster.php', 
				method: "POST",
				data: {
					httpRequest: 'createEditChoiceMaster',					
					id: formData.chId,
					name: formData.chName,
					typeId: formData.chTypeId,
					value: (formData.chValue ? formData.chValue : ''),
					description: (formData.chDescription ? formData.chDescription : ''),
					isActive: formData.isActive
				},
				headers : {
					'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
				}
			})
			.success(function(data){
				//console.log(data);
				
				if(data.statusCode == 200) {
					alertify.success(data.statusMessage);
					
					// reset form data
					$scope.frmChoiceMasterData = angular.copy({});
					formName.$setPristine();
					formName.$setUntouched();
					formName.$rollbackViewValue();

					//close modal
					$timeout(function() {
						$scope.$close();
						$rootScope.rsGetAllChoiceMastersList();
					}, 500);
				}				
				if(data.statusCode == 400) {
					alertify.error(data.statusMessage);
				}
				
			});
		}
		else {
			$scope.isFormValid = false;
		}
		
	};
	
	$scope.viewChoiceMasterDetailsById = function(id) {
		$http({
			url: 'php/choiceMaster.php', 
			method: "GET", 
			dataType: 'json',
			params: {
				httpRequest: 'viewChoiceMasterDetailsById',
				id: id
			}
		})
		.success(function(data){
			//console.log(data);
									
			if(data.statusCode == 200) {
				$rootScope.rsRemoveNonData(data[0], ['statusCode', 'statusMessage']);
				
				//open modal
				$timeout(function() {
					$scope.frmChoiceMasterData = $rootScope.rsOpenModal('views/choiceMaster/choiceMasterModalView.php', 'choiceMasterCtrl', data[0], 'frmChoiceMasterData');
					$scope.frmChoiceMasterData = $rootScope.rsObjectToArray($scope.frmChoiceMasterData);
				}, 500);
			}
			if(data.statusCode == 400) {
				alertify.error(data.statusMessage);
			}
			
		});
	};
	
	$scope.getChoiceMasterDetailsById = function(id) {
		$http({
			url: 'php/choiceMaster.php', 
			method: "GET",
			dataType: 'json',
			params: {
				httpRequest: 'getChoiceMasterDetailsById',
				id: id
			}
		})
		.success(function(data){
			//console.log(data);
									
			if(data.statusCode == 200) {
				$rootScope.rsRemoveNonData(data[0], ['statusCode', 'statusMessage']);
				
				//open modal
				$timeout(function() {
					$scope.frmChoiceMasterData = $rootScope.rsOpenModal('views/choiceMaster/choiceMasterModalCreate.php', 'choiceMasterCtrl', data[0], 'frmChoiceMasterData');
					$scope.frmChoiceMasterData = $rootScope.rsObjectToArray($scope.frmChoiceMasterData);
				}, 500);
			}
			if(data.statusCode == 400) {
				alertify.error(data.statusMessage);
			}
			
		});
	};
	
	$scope.deleteChoiceMasterDetailsById = function(id) {
		alertify.confirm("Confirm", "Are you sure, you want to delete this record?", 
			function() {			
				//console.log('Ok');			
		
				$http({
					url: 'php/choiceMaster.php', 
					method: "DELETE",
					params: {
						httpRequest: 'deleteChoiceMasterDetailsById',
						id: id
					}
				})
				.success(function(data){
					//console.log(data);
											
					if(data.statusCode == 200) {				
						alertify.success(data.statusMessage);
						
						$rootScope.rsGetAllChoiceMastersList();
					}			
					if(data.statusCode == 400) {
						alertify.error(data.statusMessage);
					}
					
				});
			}, 
			function() {
				//console.log('Cancel');
			}
		);
	};
	//--------------------------------------------------------------//

	
		
}
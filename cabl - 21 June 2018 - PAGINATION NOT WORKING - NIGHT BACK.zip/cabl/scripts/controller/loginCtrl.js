myApp.controller('loginCtrl', loginCtrl);

function loginCtrl($scope, $rootScope, $http, $location, localStorageService, $timeout, myConfig) {	
	
	// set page title
    $rootScope.rsPageTitle = 'Login';	
	
	// set session and view type(login or after login).. so that related view is rendered
	$rootScope.rsSetViewType('beforeLogin');
	$rootScope.rsSessionActive = false;
	
	// set scope variables
	$scope.frmUserLoginData = {};
	
	//console.log('Login Controller');
	//// init
	init();
	function init() {
		initPlugins();
		
		// check session
		if(localStorageService.get("lsUserDetails") == null || localStorageService.get("lsUserDetails") == undefined) {
			//$location.path('/login');			
		}
		else {
			$rootScope.rsLogin.rsUserSessionDetails = localStorageService.get("lsUserDetails");
			$location.path('/dashboard');	
		}			
	}
	
	
	//--------------------------------------------------------------//
	//***************** User Login *******************//
	//------------------------------------------------------------//
	$scope.userLogin = function(formName, formData) {
		$scope.isFormValid = false;
		
		if(formName.$valid) {
			$scope.isFormValid = true;
			
			$http({
				url: 'php/userLogin.php', 
				method: "POST",
				data: {
						httpRequest: 'userLogin',
						userId: formData.userId,
						password: formData.password					
				},
				headers : {
						'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
				}
			})
			.success(function(data){	
			    //console.log(data);
				if(data.statusCode == 200) {
					alertify.success(data.statusMessage);
					
					// set user data in rootscope variable
					$rootScope.rsLogin.rsUserSessionDetails = data[0];					
					localStorageService.set('lsUserDetails', $rootScope.rsLogin.rsUserSessionDetails);			
					
					// reset form data
					$scope.frmUserLoginData = angular.copy({});
					formName.$setPristine();
					formName.$setUntouched();
					formName.$rollbackViewValue();
					
					$timeout(function() {
						$location.path("/dashboard");
					}, 1000);
				}
				
				if(data.statusCode == 400) {
					alertify.error(data.statusMessage);
				}
			});
		}
		else {
			$scope.isFormValid = false;
		}
		
	}
	//--------------------------------------------------------------//
	
}
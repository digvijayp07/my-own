myApp.controller('applicationCtrl', applicationCtrl);

function applicationCtrl($scope, $rootScope, $http, $location, localStorageService, $timeout, myConfig, $uibModal, NgTableParams) {	
	// set page title
    $rootScope.rsPageTitle = 'Cabl Inc.';
	
	// set footer copyright
    $rootScope.rsFooterCopyright = '&copy; 2018 Cabl Inc.';
	
	// set session true or false.. so that related view is rendered
	$rootScope.rsSessionActive;	
	$rootScope.rsLogin = {};
	$rootScope.rsLogin.rsUserSessionDetails = {};
	
	$rootScope.rsSetViewType = function (vt) {
		$rootScope.rsViewType = vt;
	}
	
	// set scope variables
	$rootScope.rsAllChoiceMastersList = {};	
	$rootScope.rsAllActiveMastersOnly = {};
	$rootScope.rsAllActiveUserTypes = {};
	$rootScope.rsAllActiveCountryCodes = {};
	$rootScope.rsModalTempData = {};
	
		
	//console.log('Application Controller');
	
	
	//// init
	init();
	function init() {
		initPlugins();
		
		// check session
		$timeout(function() {
			$rootScope.rsCheckSessionExists();
		}, 0);
	}
	
	$rootScope.rsCheckSessionExists = function(){
		if(localStorageService.get("lsUserDetails") == null || localStorageService.get("lsUserDetails") == undefined) {
			//console.log(myConfig.baseRouteUrl+'login');
			$location.path('/login');			
		}
		else {
			$rootScope.rsLogin.rsUserSessionDetails = localStorageService.get("lsUserDetails");
		}
	};
	
	
	
	//--------------------------------------------------------------//
	//***************** User Logout *******************//
	//------------------------------------------------------------//
	$scope.userLogout = function() {		
		$http({
			url: 'php/userLogin.php', 
			method: "POST",
			data: {
					httpRequest: 'userLogout',
					userId: $rootScope.rsLogin.rsUserSessionDetails.id					
			},
			headers : {
					'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
			}
		})
		.success(function(data){	
			//console.log(data);
			if(data.statusCode == 200) {
				alertify.success(data.statusMessage);
				
				$timeout(function() {
					$location.path( "/login" );	
					
					// clear local storage, clear root scope variable
					$rootScope.rsLogin.rsUserSessionDetails = {};
					localStorageService.clearAll();
				}, 1000);
			}
			
			if(data.statusCode == 400) {
				alertify.error(data.statusMessage);
			}
		});		
	}
	//--------------------------------------------------------------//
	
	
	
	
	
	/* ================ GLOBAL FUNCTIONS ================ */
	//--------------------------------------------------------------//
	//***************** OPEN MODAL *******************//
	//------------------------------------------------------------//
	$rootScope.rsOpenModal = function(templateLink, controllerName, objectData, objectName){		
		$rootScope.rsModalTempData = objectData;
		var modalObj = $uibModal.open({
			templateUrl: templateLink,
			backdrop: 'static',
			windowClass: 'c-customModal animated slideInDown',
			controller: controllerName,
			scope: $scope,
			
			/*function($scope,$modalInstance){
				$scope.ok = function(id){
					//Process OK Button Click
					$modalInstance.close(); 
				},
				$scope.cancel = function(){
					$modalInstance.dismiss('cancel');
				}
			},*/
			
			size: 'md',
			keyboard: true
			/*,
			resolve: {
				resolved: function () {
					console.log('close');
				}
			}*/
		});

		/*modalObj.opened.then(function() {					
			setTimeout(function() {
				objectData = $rootScope.rsModalTempData;
				returnFunction(objectData);
			}, 2000);				
		});			
		function returnFunction(objectData) {			
			return objectData;
		}*/
		
		return objectData;
    };	
	$rootScope.rsGetmyModalData = function() {		
		return $rootScope.rsModalTempData;
	}
	
	//--------------------------------------------------------------//
	//***************** Object To Array *******************//
	//------------------------------------------------------------//
	$rootScope.rsObjectToArray = function(obj) {
		  if (typeof(obj) === 'object') {
			var keys = Object.keys(obj);
			var allObjects = keys.every(x => typeof(obj[x]) === 'object');
			if (allObjects) {
			  return keys.map(x => $rootScope.rsObjectToArray(obj[x]));
			} else {
			  var o = {};
			  keys.forEach(x => {
				o[x] = $rootScope.rsObjectToArray(obj[x])
			  });
			  return o;
			}
		  } 
		  else {
			return obj;
		  }
	}
	//--------------------------------------------------------------//
	
	//--------------------------------------------------------------//
	//***************** Remove Status Code & Messages From Data *******************//
	//------------------------------------------------------------//
	$rootScope.rsRemoveNonData = function(allData, removeThis) {		
		for(var i = 0; i < removeThis.length; i++) {
			delete allData[removeThis[i]];			
		}
	}
	//--------------------------------------------------------------//	
		
	//---------------------------------------------------------------//
	//***************** Get All From Choice Master *****************//
	//-------------------------------------------------------------//
	$rootScope.rsGetAllChoiceMastersList = function() {
		$http({
			url: 'php/choiceMaster.php', 
			method: "GET",
			dataType: 'json',
			params: {	
				httpRequest: 'getAllChoiceMastersList'
			}
		})
		.success(function(data){
			//console.log(data);	
			if(data.statusCode == 200) {
				$rootScope.rsRemoveNonData(data, ['statusCode', 'statusMessage']);
				
				$rootScope.rsAllChoiceMastersList = $rootScope.rsObjectToArray(data);				
			}
			if(data.statusCode == 400) {
				$rootScope.rsRemoveNonData(data, ['statusCode', 'statusMessage']);
				$rootScope.rsAllChoiceMastersList = $rootScope.rsObjectToArray(data);		
			}
		});		
	};
	
	//--------------------------------------------------------------//
	
	//---------------------------------------------------------------//
	//***************** Get All From Choice Master Having chTypeId *****************//
	//-------------------------------------------------------------//
	$rootScope.rsGetAllActiveChoiceMasters = function(chType, modelName) {
		$http({
			url: 'php/choiceMaster.php', 
			method: "GET", 
			dataType: 'json',
			params: {	
				httpRequest: 'getAllActiveChoiceMastersHavingChType', 
				chTypeId: chType
			}
		})
		.success(function(data){
			//console.log(data);	
			
			if(data.statusCode == 200) {
				$rootScope.rsRemoveNonData(data, ['statusCode', 'statusMessage']);		
							
				switch(modelName) {
					case 'rsAllActiveUserTypes':
						$rootScope.rsAllActiveUserTypes = $rootScope.rsObjectToArray(data);
						break;
						
					case 'rsAllActiveCountryCodes':
						$rootScope.rsAllActiveCountryCodes = $rootScope.rsObjectToArray(data);
						break;	

					case 'rsAllActiveMastersOnly':
						$rootScope.rsAllActiveMastersOnly = $rootScope.rsObjectToArray(data);
						break;
				}
			}
		});		
	};
	//--------------------------------------------------------------//	
	
	//---------------------------------------------------------------//
	//***************** SET USER TYPE PREFIX *****************//
	//-------------------------------------------------------------//	
	$rootScope.rsSetUserTypePrefix = function() {		 		
		$rootScope.rsUserTypePrefix = $('.c-txtUserTypeId option:selected').attr('data-user-prefix');	
	};
	//--------------------------------------------------------------//
}
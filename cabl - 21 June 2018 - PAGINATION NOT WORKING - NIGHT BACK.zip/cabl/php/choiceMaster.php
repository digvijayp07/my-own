<?PHP

// include connection page or open database connection
require_once 'dbConnection.php';
	
	//--------------------------------------------------------------//
	// GET CALLS --------------------------------------------------------------//	
	if($_SERVER['REQUEST_METHOD'] === 'GET') {	
		// get all active & inactive choice masters
		if($_GET['httpRequest'] == 'getAllChoiceMastersList') {
			$query = "SELECT ch1.chId, ch1.chName, ch1.chValue, ch1.chTypeId, ch1.chDescription, ch1.isActive, ch1.isDelete, 
				IF(ch2.chName != 'null', ch2.chName, 'Master') AS chTypeName, 
				IF(ch1.isActive = '1', 'Active', 'In Active') AS isActiveInactiveText, 				
				IF(ch1.isDelete = '1', 'Yes', 'No') AS isDeleteText 				
				FROM tbl_choice_master ch1 
					LEFT JOIN tbl_choice_master ch2 
					ON ch1.chTypeId = ch2.chId 
				ORDER BY ch1.chId ASC";
			$result = mysqli_query($con, $query) or die(mysqli_error($con));
			$resultArr = array();
			
			if(mysqli_num_rows($result) > 0) {
				while($row = mysqli_fetch_assoc($result)) {
					$resultArr[] = $row;
				}
				
				$resultArr['statusCode'] = 200;
				print_r(json_encode($resultArr));
			}
			else {
				$resultArr['statusCode'] = 400;
				$resultArr['statusMessage'] = 'No data found';
				print_r(json_encode($resultArr));
			}
		}
		//--------------------------------------------------------------//
		
		
		//--------------------------------------------------------------//
		// get all active choice masters having chTypeId
		if($_GET['httpRequest'] == 'getAllActiveChoiceMastersHavingChType') {	
				$query = "SELECT * FROM tbl_choice_master 
					WHERE chTypeId = ".$_GET['chTypeId']." AND isActive = 1 AND isDelete = 0
					ORDER BY chName ASC";
				$result = mysqli_query($con, $query) or die(mysqli_error($con));
				$resultArr = array();

				if(mysqli_num_rows($result) > 0) {
					while($row = mysqli_fetch_assoc($result)) {
						$resultArr[] = $row;
					}
					
					$resultArr['statusCode'] = 200;
					print_r(json_encode($resultArr));
				}
				else {
					$resultArr['statusCode'] = 400;
					$resultArr['statusMessage'] = 'No data found';
					print_r(json_encode($resultArr));
				}
		}
		//--------------------------------------------------------------//
		
		//--------------------------------------------------------------//
		// get choice master details by id for form
		if($_GET['httpRequest'] == 'getChoiceMasterDetailsById') {
			if(isset($_GET['id']) && $_GET['id'] != '') {
				$query = "SELECT * FROM tbl_choice_master 
					WHERE chId = ".$_GET['id']."";
				$result = mysqli_query($con, $query) or die(mysqli_error($con));
				$resultArr = array();

				if(mysqli_num_rows($result) > 0) {
					while($row = mysqli_fetch_assoc($result)) {
						$resultArr[] = $row;
					}
					
					$resultArr['statusCode'] = 200;
					print_r(json_encode($resultArr));
				}
				else {
					$resultArr['statusCode'] = 400;
					$resultArr['statusMessage'] = 'No data found';
					print_r(json_encode($resultArr));
				}
			}	
			else {
				$resultArr['statusCode'] = 400;
				$resultArr['statusMessage'] = 'Something went wrong.';
				print_r(json_encode($resultArr));
			}
		}
		//--------------------------------------------------------------//
		
		//--------------------------------------------------------------//
		// get choice master details by id for view
		if($_GET['httpRequest'] == 'viewChoiceMasterDetailsById') {
			if(isset($_GET['id']) && $_GET['id'] != '') {
				$query = "SELECT ch1.*, 
					IF(ch2.chName != 'null', ch2.chName, 'Master') AS chTypeName, 
					IF(ch1.isActive = '1', 'Active', 'In Active') AS isActiveInactiveText, 
					IF(ch1.isDelete = '1', 'Yes', 'No') AS isDeleteText 
					FROM tbl_choice_master ch1 
						LEFT JOIN tbl_choice_master ch2 
						ON ch1.chTypeId = ch2.chId 
					WHERE ch1.chId = ".$_GET['id']."";
				$result = mysqli_query($con, $query) or die(mysqli_error($con));
				$resultArr = array();

				if(mysqli_num_rows($result) > 0) {
					while($row = mysqli_fetch_assoc($result)) {
						$resultArr[] = $row;
					}
					
					$resultArr['statusCode'] = 200;
					print_r(json_encode($resultArr));
				}
				else {
					$resultArr['statusCode'] = 400;
					$resultArr['statusMessage'] = 'No data found';
					print_r(json_encode($resultArr));
				}
			}	
			else {
				$resultArr['statusCode'] = 400;
				$resultArr['statusMessage'] = 'Something went wrong.';
				print_r(json_encode($resultArr));
			}
		}
		//--------------------------------------------------------------//


		
	}
	//--------------------------------------------------------------//
	
	
	
	//--------------------------------------------------------------//
	// POST CALLS --------------------------------------------------------------//
	if($_SERVER['REQUEST_METHOD'] === 'POST') {
		
		$postdata = file_get_contents("php://input");
		$request = json_decode($postdata);
		
		//--------------------------------------------------------------//
		// Create / Edit Choice Master
		if($request->httpRequest == 'createEditChoiceMaster') {
			// Check if record already exists or not.
			if($request->id == 0) {				
				$query = "SELECT * FROM tbl_choice_master 
					WHERE chName = '".$request->name."'";
				$result = mysqli_query($con, $query) or die(mysqli_error($con));
			}
			else {
				$query = "SELECT * FROM tbl_choice_master 
					WHERE chName = '".$request->name."' AND chId != ".$request->id."";
				$result = mysqli_query($con, $query) or die(mysqli_error($con));
			}
			
			// Check if record already exists or not. 0 means does not exist. Valid.
			if(mysqli_num_rows($result) == 0) { 
				
				// if id = 0 means create
				if($request->id == 0){
					// GET LAST ID
					if($request->typeId == 0) {
						$query = "SELECT chId as totalCount FROM tbl_choice_master 
							WHERE chTypeId = 0 
							ORDER BY chId DESC 
							LIMIT 1";
						$result = mysqli_query($con, $query) or die(mysqli_error($con));
						$resultArr = array();	
						
						if(mysqli_num_rows($result) == 0) {
							// if it is first record
							$id = 1;
						}
						else {
							$resultArr=mysqli_fetch_assoc($result2);
							$id = $resultArr['totalCount']+1;							
						}
					}
					else {
						$query = "SELECT chId as totalCount FROM tbl_choice_master 
							WHERE chTypeId != 0 
							ORDER BY chId DESC 
							LIMIT 1";
						$result = mysqli_query($con, $query) or die(mysqli_error($con));	
						$resultArr = array();	
											
						
						if(mysqli_num_rows($result) == 0) {
							// if it is first of its type i.e not a master then start id from 1001 else 0
							$id = 1001;
						}
						else {
							$resultArr=mysqli_fetch_assoc($result);							
							$id = $resultArr['totalCount']+1;
						}
					}
					// END GET LAST ID					
					
					// INSERT
					$query = "INSERT INTO tbl_choice_master (chId, chName, chTypeId, chValue, chDescription, isActive) 
						VALUES(".$id.", '".$request->name."', '".$request->typeId."', '".$request->value."', '".$request->description."', '".$request->isActive."')";
					$result = mysqli_query($con, $query) or die(mysqli_error($con));
					$resultArr = array();
				
					if($result) {	
						$resultArr['statusCode'] = 200;
						$resultArr['statusMessage'] = 'Choice master created successfully.';
						print_r(json_encode($resultArr));
					}
					else {
						$resultArr['statusCode'] = 400;
						$resultArr['statusMessage'] = 'Some thing went wrong.';
						print_r(json_encode($resultArr));	
					}
					// END INSERT
				}
				else {
					// EDIT / UPDATE
					$query = "UPDATE tbl_choice_master 
						SET chName = '".$request->name."', 
							chTypeId = '".$request->typeId."', 
							chValue = '".$request->value."', 
							chDescription = '".$request->description."', 
							isActive =  '".$request->isActive."' 
						WHERE chId = ".$request->id."";
					$result = mysqli_query($con, $query) or die(mysqli_error($con));
					$resultArr = array();
				
					if($result) {	
						$resultArr['statusCode'] = 200;
						$resultArr['statusMessage'] = 'Choice master updated successfully.';
						print_r(json_encode($resultArr));
					}
					else {
						$resultArr['statusCode'] = 400;
						$resultArr['statusMessage'] = 'Some thing went wrong.';
						print_r(json_encode($resultArr));	
					}
					// END EDIT / UPDATE
				}
			}
			else {
				$resultArr['statusCode'] = 400;
				$resultArr['statusMessage'] = 'The record with this name already exists. Kindly, use another name.';
				print_r(json_encode($resultArr));	
			}
		}
		//--------------------------------------------------------------//		
			
	}
	//--------------------------------------------------------------//
	
	//--------------------------------------------------------------//
	// DELETE CALLS --------------------------------------------------------------//	
	if($_SERVER['REQUEST_METHOD'] === 'DELETE') {
		$resultArr = array();
		// Delete Choice Master
		if(isset($_GET['id']) && $_GET['id'] != '') {			
			if($_GET['httpRequest'] == 'deleteChoiceMasterDetailsById') {			
				$query = "UPDATE tbl_choice_master 
					SET isDelete = 1, 
						isActive = 0
					WHERE chId = '".$_GET['id']."'";				
				$result = mysqli_query($con, $query) or die(mysqli_error($con));	
				$resultArr = array();
				
				if($result) {	
					$resultArr['statusCode'] = 200;
					$resultArr['statusMessage'] = 'Choice master deleted successfully.';
					print_r(json_encode($resultArr));
				}
				else {
					$resultArr['statusCode'] = 400;
					$resultArr['statusMessage'] = 'Something went wrong. Could not perform the action.';
					print_r(json_encode($resultArr));
				}
			}
		}
		else {
			$resultArr['statusCode'] = 400;
			$resultArr['statusMessage'] = 'Something went wrong.';
			print_r(json_encode($resultArr));
		}
		//--------------------------------------------------------------//
	}
	//--------------------------------------------------------------//
	
	
	
// close database connection
mysqli_close($con);
?>
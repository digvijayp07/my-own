<?PHP

// include connection page or open database connection
require_once 'dbConnection.php';
	
	//--------------------------------------------------------------//
	// get registered users count
	if($_SERVER['REQUEST_METHOD'] === 'GET' && $_GET['httpRequest'] == 'getRegisteredUsersCount') {	
	
		$query = "SELECT * FROM tbl_users";
		$result = mysqli_query($con, $query) or die(mysqli_error($con));
		$resultArr = array();

		if($result) {
			echo (mysqli_num_rows($result)) + 1;
		}
		else {
			echo mysqli_error($con);
		}
			
	}
	//--------------------------------------------------------------//
	
	//--------------------------------------------------------------//
	if($_SERVER['REQUEST_METHOD'] === 'POST') {
		
		$postdata = file_get_contents("php://input");
		$request = json_decode($postdata);		
		
		//--------------------------------------------------------------//
		// register new user
		if($request->httpRequest == 'registerNewUser') {		
			$password = md5($request->password);
			
			$query = "SELECT * FROM tbl_users_info 
				WHERE mobileNumber = '".$request->mobileNumber."'";
			$result = mysqli_query($con, $query) or die(mysqli_error($con));
			// Check if record already exists or not. 0 means does not exist. Valid.
			if(mysqli_num_rows($result) == 0) {
				
				$query2 = "INSERT INTO tbl_users (id, password, userTypeId, isOnline, isActive) 
				VALUES('".$request->userId."', '".$password."', ".$request->userTypeId.", 0, 1)";
				$result2 = mysqli_query($con, $query2) or die(mysqli_error($con));
				$resultArr2 = array();
			
				if($result2) {
					
					$createdDate = date("Y-m-d h:i:s");
					$modifiedDate = date("Y-m-d h:i:s");
					
					$query3 = "INSERT INTO tbl_users_info (id, firstName, middleName, lastName, countryCode, mobileNumber, address, createdDate, createdBy, modifiedDate, modifiedBy) 
					VALUES('".$request->userId."', '".$request->firstName."', '".$request->middleName."', '".$request->lastName."', '".$request->countryCode."', ".$request->mobileNumber.", '".$request->address."', '".$createdDate."', '".$request->userId."', '".$modifiedDate."', '".$request->userId."')";				
					
					$result3 = mysqli_query($con, $query3) or die(mysqli_error($con));
					
					if($result3) {			
						$resultArr['statusCode'] = 200;
						$resultArr['statusMessage'] = 'Registration successful. Redirecting...';
						print_r(json_encode($resultArr));	
					}
					else {
						// if failed, then delete entry from tbl_users_info
						$query4 = "DELETE FROM tbl_users 
							WHERE id = '".$request->userId."'";
						mysqli_query($con, $query4) or die(mysqli_error($con));	
						
						$resultArr['statusCode'] = 400;
						$resultArr['statusMessage'] = 'Registration failed. Redirecting...';
						print_r(json_encode($resultArr));	
					}
				}
				else {
					$resultArr['statusCode'] = 400;
					$resultArr['statusMessage'] = 'Registration failed. Redirecting...';
					print_r(json_encode($resultArr));	
				}
			}
			else {
				$resultArr['statusCode'] = 400;
				$resultArr['statusMessage'] = 'The record with this user already exists.';
				print_r(json_encode($resultArr));
			}
		}
		//--------------------------------------------------------------//
			
	}
	//--------------------------------------------------------------//
	
	
	
// close database connection
mysqli_close($con);
?>
<div class="modal-header"> 
	<button type="button" class="close" ng-click="closeModal()">X</button> <!-- data-dismiss="modal" aria-hidden="true" -->
	<h4 class="modal-title text-info">
		<div ng-bind="frmChoiceMasterData.chName"></div>
		<div class="c-subModalHeading text-muted">Choice Master</div>
	</h4>
</div>
<div class="modal-body">
	<div class="c-formModal">	
			
		<div class="c-infoKeyValWrapper">					
			<div class="c-infoKeyValRow">
				<div class="c-infoKey col-md-6 col-sm-8 col-xs-12">ID</div>
				<div class="c-infoVal col-md-6 col-sm-4 col-xs-12">
					<p ng-bind="frmChoiceMasterData.chId"></p>
				</div>
			</div>
			<div class="c-infoKeyValRow">
				<div class="c-infoKey col-md-6 col-sm-8 col-xs-12">Name</div>
				<div class="c-infoVal col-md-6 col-sm-4 col-xs-12">
					<p ng-bind="frmChoiceMasterData.chName"></p>
				</div>
			</div>
			<div class="c-infoKeyValRow">
				<div class="c-infoKey col-md-6 col-sm-8 col-xs-12">Type</div>
				<div class="c-infoVal col-md-6 col-sm-4 col-xs-12">
					<p ng-bind="frmChoiceMasterData.chTypeName"></p>
				</div>
			</div>
			<div class="c-infoKeyValRow">
				<div class="c-infoKey col-md-6 col-sm-8 col-xs-12">Value</div>
				<div class="c-infoVal col-md-6 col-sm-4 col-xs-12">
					<p ng-bind="frmChoiceMasterData.chValue"></p>
				</div>
			</div>			
			<div class="c-infoKeyValRow">
				<div class="c-infoKey col-md-6 col-sm-8 col-xs-12">Description</div>
				<div class="c-infoVal col-md-6 col-sm-4 col-xs-12">
					<p ng-bind="frmChoiceMasterData.chDescription"></p>
				</div>
			</div>
			<div class="c-infoKeyValRow">
				<div class="c-infoKey col-md-6 col-sm-8 col-xs-12">Is Active?</div>
				<div class="c-infoVal col-md-6 col-sm-4 col-xs-12">
					<p>
						<span class="badge"
							ng-class="(frmChoiceMasterData.isActive == 1) ? 'badge-success' : 'badge-danger'">
								{{frmChoiceMasterData.isActiveInactiveText}}
							</span>
					</p>
				</div>
			</div>
			<div class="c-infoKeyValRow">
				<div class="c-infoKey col-md-6 col-sm-8 col-xs-12">Is Deleted?</div>
				<div class="c-infoVal col-md-6 col-sm-4 col-xs-12">
					<p>
						<span class="badge"
							ng-class="(frmChoiceMasterData.isDelete == 0) ? 'badge-success' : 'badge-danger'">
								{{frmChoiceMasterData.isDeleteText}}
							</span>
					</p>
				</div>
			</div>
		</div>		
	
	</div>	
</div>
<div class="modal-footer c-singleBtn">  
	<button type="button" class="btn btn-default c-btnCancel" 
				ng-click="closeModal()">Close</button>
</div>
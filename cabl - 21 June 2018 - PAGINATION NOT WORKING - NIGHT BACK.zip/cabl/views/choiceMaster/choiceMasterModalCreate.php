<div class="modal-header"> 
	<button type="button" class="close" ng-click="closeModal()">X</button> <!-- data-dismiss="modal" aria-hidden="true" -->
	<h4 class="modal-title text-info"> 
		<span ng-bind="(frmChoiceMasterData.chId == '' || frmChoiceMasterData.chId == undefined) ? 'Create' : 'Edit'"></span>
		Choice Master
	</h4>
</div>
<div class="modal-body">
	<div class="c-formModal">
		<form class="form-horizontal form-material c-frmChoiceMaster" name="frmChoiceMaster" method="POST" novalidate>	
	
			<input type="hidden" class="form-control" 
						name="txtChId" 
						ng-init="frmChoiceMasterData.chId = ((frmChoiceMasterData.chId == '' || frmChoiceMasterData.chId == undefined) ? 0 : frmChoiceMasterData.chId)"
						ng-model="frmChoiceMasterData.chId" 
						required 
						readonly="readonly" 
						disabled="disabled">
		
			<div class="form-group">
				<label class="col-md-3 col-sm-4 col-xs-12">Type <span class="c-requiredSign">*</span></label>
				<div class="col-md-9 col-sm-8 col-xs-12">
					<select class="form-control" 
						name="txtChTypeId" 
						ng-init="rsGetAllActiveChoiceMasters(0, 'rsAllActiveMastersOnly');"
						ng-model="frmChoiceMasterData.chTypeId" 
						required>
						<option value="" selected="selected">Select</option>
						<optgroup label="Self Master">
							<option value="0">Self Master</option>
						</optgroup>
						<optgroup label="Parent Master">
							<option ng-repeat="data in rsAllActiveMastersOnly" 
								value="{{data.chId}}">{{data.chName}}</option>
						</optgroup>
					</select>
					<div class="c-errorMessages" ng-show="(frmChoiceMaster.txtChTypeId.$invalid)">				
						<p ng-show="(frmChoiceMaster.txtChTypeId.$touched && frmChoiceMaster.txtChTypeId.$error.required) || (frmChoiceMaster.txtChTypeId.$error.required && isFormValid==false)">Type is required</p>
					</div>
				</div>
			</div>
			<div class="form-group">
				<label class="col-md-3 col-sm-4 col-xs-12">Name <span class="c-requiredSign">*</span></label>
				<div class="col-md-9 col-sm-8 col-xs-12">
					<input type="text" class="form-control" 
						name="txtChName" 
						ng-model="frmChoiceMasterData.chName" 
						required 
						ng-maxlength="150">
					
					<div class="c-errorMessages" ng-show="(frmChoiceMaster.txtChName.$invalid)">				
						<p ng-show="(frmChoiceMaster.txtChName.$touched && frmChoiceMaster.txtChName.$error.required) || (frmChoiceMaster.txtChName.$error.required && isFormValid==false)">Name is required</p>
					</div>
				</div>
			</div>
			<div class="form-group">
				<label class="col-md-3 col-sm-4 col-xs-12">Value</label>
				<div class="col-md-9 col-sm-8 col-xs-12">
					<input type="text" class="form-control" 
						name="txtChValue" 
						ng-model="frmChoiceMasterData.chValue" 
						ng-maxlength="150">
				</div>
			</div>
			<div class="form-group">
				<label class="col-md-3 col-sm-4 col-xs-12">Description</label>
				<div class="col-md-9 col-sm-8 col-xs-12">
					<textarea class="form-control form-control-line" rows="10" 
						name="txtChDescription"  
						ng-model="frmChoiceMasterData.chDescription" 
						ng-maxlength="1000"></textarea>						
				</div>
			</div>
			<div class="form-group">
				<label class="col-md-3 col-sm-4 col-xs-12">Is Active? <span class="c-requiredSign">*</span></label>
				<div class="col-md-9 col-sm-8 col-xs-12">
					<select class="form-control" 
						name="txtIsActive"
						ng-model="frmChoiceMasterData.isActive"
						required>
						<option value="" selected="selected">Select</option>
						<option value="1">Active</option>
						<option value="0">In active</option>
					</select>	
					
					<div class="c-errorMessages" ng-show="(frmChoiceMaster.txtIsActive.$invalid)">				
						<p ng-show="(frmChoiceMaster.txtIsActive.$touched && frmChoiceMaster.txtIsActive.$error.required) || (frmChoiceMaster.txtIsActive.$error.required && isFormValid==false)">Is Active is required</p>
					</div>
				</div>
			</div>		
			
		</form>
	</div>
	
</div>
<div class="modal-footer c-singleBtn">  
	<button type="button" class="btn btn-info c-btnAction" 
				ng-click="choiceMasterCreateEdit(frmChoiceMaster, frmChoiceMasterData);" 
				ng-enter="choiceMasterCreateEdit(frmChoiceMaster, frmChoiceMasterData);">Submit</button>
</div>
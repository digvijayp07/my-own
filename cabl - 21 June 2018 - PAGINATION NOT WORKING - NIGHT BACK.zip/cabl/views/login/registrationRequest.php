<!--<div class="c-loginHeading">
	<h3>Registration</h3>
	<p>This is your first step towards connecting with us.</p>
</div>-->
<div class="c-loginForm">
	
		<div class="c-mutedMessage c-ht350 c-brad4">
			<span>
				<i class="flaticon-laptop"></i>
				<h3 class="text-uppercase">Hello user,</h3>
				<p>We're very happy to know that you want to be part of our family.</p>
				<p>To register yourself, kindly call on <br><strong>1800 55 44 55</strong>.</p>
			</span>
		</div>		
		
		<div class="c-forgotPassword"><a ng-href="#/login/">Sign in</a> instead</div>
		
</div>
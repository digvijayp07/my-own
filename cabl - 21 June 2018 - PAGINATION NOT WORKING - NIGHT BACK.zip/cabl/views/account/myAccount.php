<div class="row bg-title">
	<div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
		<h4 class="page-title">My Account</h4> 
	</div>		
	<!--<div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
		<a href="https://wrappixel.com/templates/ampleadmin/" target="_blank" class="btn btn-danger pull-right m-l-20 hidden-xs hidden-sm waves-effect waves-light">Upgrade to Pro</a>			
	</div>-->
</div>
<!-- /.row -->
<!-- .row -->
<div class="row">
	<div class="col-md-4 col-xs-12">
		<div class="white-box c-userAccountInfoSide c-brad4">
			<div class="user-bg c-bradTopOnly4"> 
				<img width="100%" alt="user" src="plugins/images/large/img1.jpg">
				<div class="overlay-box">
					<div class="user-content">
						<a href="javascript:void(0)"><img src="plugins/images/users/varun.jpg" class="thumb-lg img-circle" alt="img"></a>
						<h4 class="text-white">Mr. Rana Da</h4>
						<!--<h5 class="text-white">Cust. ID- 00001234</h5> -->
					</div>
				</div>
			</div>
			<div class="user-btm-box text-center">
				
				<a ng-href="#/myAccountEdit/" class="btn btn-link"><i class="flaticon-edit"></i>&nbsp; Edit Account</a>
				
				<!--<div class="col-md-4 col-sm-4 text-center">
					<p class="text-purple"><i class="ti-facebook"></i></p>
					<h1>258</h1> </div>
				<div class="col-md-4 col-sm-4 text-center">
					<p class="text-blue"><i class="ti-twitter"></i></p>
					<h1>125</h1> </div>
				<div class="col-md-4 col-sm-4 text-center">
					<p class="text-danger"><i class="ti-dribbble"></i></p>
					<h1>556</h1> </div>-->
			</div>
		</div>
	</div>
	<div class="col-md-8 col-xs-12">
		<div class="white-box c-userAccountInfoMain c-brad4">
			
			
			<div class="c-infoKeyValWrapper">
				<div class="c-infoKeyValRow">
					<div class="c-infoKey col-md-3 col-sm-4 col-xs-12">Status</div>
					<div class="c-infoVal col-md-9 col-sm-8 col-xs-12"><span class="text-success">Active</span></div>
				</div>
				
				
				<div class="c-infoKeyValRow" ng-if="rsLogin.rsUserSessionDetails.userTypeId == 1002">
					<div class="c-infoKey col-md-3 col-sm-4 col-xs-12">Operator ID</div>
					<div class="c-infoVal col-md-9 col-sm-8 col-xs-12"><span class="text-info">CABL-001</span></div>
				</div>
				<div class="c-infoKeyValRow" ng-if="rsLogin.rsUserSessionDetails.userTypeId == 1003">
					<div class="c-infoKey col-md-3 col-sm-4 col-xs-12">Customer ID</div>
					<div class="c-infoVal col-md-9 col-sm-8 col-xs-12"><span class="text-info">00001234</span></div>
				</div>
				
				
				<div class="c-infoKeyValRow">
					<div class="c-infoKey col-md-3 col-sm-4 col-xs-12">Name</div>
					<div class="c-infoVal col-md-9 col-sm-8 col-xs-12">Rana Da Vasagadekar</div>
				</div>				
				<div class="c-infoKeyValRow">
					<div class="c-infoKey col-md-3 col-sm-4 col-xs-12">Mobile No.</div>
					<div class="c-infoVal col-md-9 col-sm-8 col-xs-12">
						+91 9955885544 
						<div>
							<button class="btn btn-link btn-xs text-info">Verify</button>
						</div>
					</div>
				</div>

				<div class="c-infoKeyValRow">
					<div class="c-infoKey col-md-3 col-sm-4 col-xs-12">Email ID</div>
					<div class="c-infoVal col-md-9 col-sm-8 col-xs-12">rana.da@gmail.com</div>
				</div>
				
				<div class="c-infoKeyValRow">
					<div class="c-infoKey col-md-3 col-sm-4 col-xs-12">Address</div>
					<div class="c-infoVal col-md-9 col-sm-8 col-xs-12">121, B Ward, Vasagade. Tal - Karvir. Dist - Kolhapur</div>
				</div>
				<div class="c-infoKeyValRow">
					<div class="c-infoKey col-md-3 col-sm-4 col-xs-12">Colony / Lane / Ward</div>
					<div class="c-infoVal col-md-9 col-sm-8 col-xs-12">Ingawale Colony</div>
				</div>
				<div class="c-infoKeyValRow">
					<div class="c-infoKey col-md-3 col-sm-4 col-xs-12">Area Name &amp Code</div>
					<div class="c-infoVal col-md-9 col-sm-8 col-xs-12">Vasagade (VASG-001)</div>
				</div>
				
				<div class="c-infoKeyValRow" ng-if="rsLogin.rsUserSessionDetails.userTypeId == 1003">
					<div class="c-infoKey col-md-3 col-sm-4 col-xs-12">Operator Name &amp; Code</div>
					<div class="c-infoVal col-md-9 col-sm-8 col-xs-12">Mr. Lad (CABL-001)</div>
				</div>
				
				<div class="c-infoKeyValRow">
					<div class="c-infoKey col-md-3 col-sm-4 col-xs-12">City</div>
					<div class="c-infoVal col-md-9 col-sm-8 col-xs-12">Kolhapur</div>
				</div>
				<div class="c-infoKeyValRow">
					<div class="c-infoKey col-md-3 col-sm-4 col-xs-12">Taluka</div>
					<div class="c-infoVal col-md-9 col-sm-8 col-xs-12">Karvir</div>
				</div>
				<div class="c-infoKeyValRow">
					<div class="c-infoKey col-md-3 col-sm-4 col-xs-12">District</div>
					<div class="c-infoVal col-md-9 col-sm-8 col-xs-12">Kolhapur</div>
				</div>
				<div class="c-infoKeyValRow">
					<div class="c-infoKey col-md-3 col-sm-4 col-xs-12">State</div>
					<div class="c-infoVal col-md-9 col-sm-8 col-xs-12">Maharashtra</div>
				</div>
				<div class="c-infoKeyValRow">
					<div class="c-infoKey col-md-3 col-sm-4 col-xs-12">Country</div>
					<div class="c-infoVal col-md-9 col-sm-8 col-xs-12">India</div>
				</div>
			</div>
			
			
			<div class="clearfix"></div>	
		</div>
	</div>
</div>
<!-- /.row -->
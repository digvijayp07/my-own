<div class="row bg-title">
	<div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
		<h4 class="page-title">User Registration</h4> 
	</div>		
	<!--<div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
		<a href="https://wrappixel.com/templates/ampleadmin/" target="_blank" class="btn btn-danger pull-right m-l-20 hidden-xs hidden-sm waves-effect waves-light">Upgrade to Pro</a>			
	</div>-->
</div>
<!-- /.row -->
<!-- .row -->
<div class="row">	
	<div class="col-md-12 col-xs-12">
		<div class="white-box c-brad4">
			
			
			<div class="col-md-4 col-sm-6 col-xs-12">
				<form class="form-material c-frmRegisterNewUser" name="frmRegisterNewUser" method="POST" novalidate>
					<div class="form-group">
						<label>User Type <span class="c-requiredSign">*</span></label>			
						<select class="form-control c-txtUserTypeId" 
							name="txtUserTypeId" 
							ng-init="rsGetAllActiveChoiceMasters(1, 'rsAllActiveUserTypes');"
							ng-model="frmRegistrationData.userTypeId" 		
							ng-change="rsSetUserTypePrefix();"
							required>
							<option value="" selected="selected">Select</option>
							<option ng-repeat="data in rsAllActiveUserTypes" 
									value="{{data.chId}}" 
									data-user-prefix="{{data.chValue}}">{{data.chName}}</option>
						</select>
						<div class="c-errorMessages" ng-show="(frmRegisterNewUser.txtUserTypeId.$invalid)">				
							<p ng-show="(frmRegisterNewUser.txtUserTypeId.$touched && frmRegisterNewUser.txtUserTypeId.$error.required) || (frmRegisterNewUser.txtUserTypeId.$error.required && isFormValid==false)">User Type is required</p>
						</div>
					</div>
					
					<div class="form-group">
						<label>User ID <span class="c-requiredSign">*</span></label> <!-- value="CUST-{{customerId}}" -->
						<div class="input-group">
							<span class="input-group-addon c-width45">
								<input type="text" class="form-control" 
								name="txtPrefix" 
								ng-value="rsUserTypePrefix" 
								readonly="readonly" 
								disabled="disabled" 
								required>
							</span>
							<input type="text" class="form-control" 
							name="txtUserId" 
							ng-model="frmRegistrationData.userId" 
							readonly="readonly" 
							disabled="disabled">
							
							<div class="c-errorMessages" ng-show="(frmRegisterNewUser.txtPrefix.$invalid)">				
								<p ng-show="(frmRegisterNewUser.txtPrefix.$touched && frmRegisterNewUser.txtPrefix.$error.required) || (frmRegisterNewUser.txtPrefix.$error.required && isFormValid==false)">User Type Prefix is required</p>
							</div>
						</div>
					</div>
					
					<div class="form-group">
						<label>First Name <span class="c-requiredSign">*</span></label>
						<input type="text" class="form-control" 
						name="txtFirstName" 
						ng-model="frmRegistrationData.firstName" 
						required 
						tabindex="1">
						
						<div class="c-errorMessages" ng-show="(frmRegisterNewUser.txtFirstName.$invalid)">
							<p ng-show="(frmRegisterNewUser.txtFirstName.$touched && frmRegisterNewUser.txtFirstName.$error.required) || (frmRegisterNewUser.txtFirstName.$error.required && isFormValid==false)">First Name is required</p>
						</div>
					</div>
					<div class="form-group">
						<label>Middle Name</label>
						<input type="text" class="form-control" 
						name="txtMiddleName" 
						ng-model="frmRegistrationData.middleName" 
						tabindex="2">
					</div>
					<div class="form-group">
						<label>Last Name <span class="c-requiredSign">*</span></label>
						<input type="text" class="form-control" 
						name="txtLastName" 
						ng-model="frmRegistrationData.lastName" 
						required 
						tabindex="3">
						
						<div class="c-errorMessages" ng-show="(frmRegisterNewUser.txtLastName.$invalid)">
							<p ng-show="(frmRegisterNewUser.txtLastName.$touched && frmRegisterNewUser.txtLastName.$error.required) || (frmRegisterNewUser.txtLastName.$error.required && isFormValid==false)">Last Name is required</p>
						</div>
					</div>
					
					<div class="form-group">
						<label>Mobile Number <span class="c-requiredSign">*</span></label>			
						<div class="input-group">
							<span class="input-group-addon c-width100">
								<select class="form-control" 
									name="txtCountryCode" 
									ng-init="rsGetAllActiveChoiceMasters(2, 'rsAllActiveCountryCodes');"
									ng-model="frmRegistrationData.countryCode" 
									required 
									tabindex="4">
									<option value="" selected="selected">Select</option>
									<option ng-repeat="data in rsAllActiveCountryCodes" 
										value="{{data.chId}}" 
										data-user-prefix="{{data.chValue}}">{{data.chName +' '+ data.chValue}}</option>
								</select>
							</span>
							<input type="text" class="form-control" 
								name="txtMobileNumber" 
								ng-model="frmRegistrationData.mobileNumber" 
								required 
								tabindex="5">
						</div>
						<div class="c-errorMessages" ng-show="(frmRegisterNewUser.txtCountryCode.$invalid)">
							<p ng-show="(frmRegisterNewUser.txtCountryCode.$touched && frmRegisterNewUser.txtCountryCode.$error.required) || (frmRegisterNewUser.txtCountryCode.$error.required && isFormValid==false)">Country Code is required</p>
						</div>
						
						<div class="c-errorMessages" ng-show="(frmRegisterNewUser.txtMobileNumber.$invalid)">
							<p ng-show="(frmRegisterNewUser.txtMobileNumber.$touched && frmRegisterNewUser.txtMobileNumber.$error.required) || (frmRegisterNewUser.txtMobileNumber.$error.required && isFormValid==false)">Mobile Number is required</p>
						</div>
					</div>
					
					<div class="form-group">
						<label>Address</label>
						<textarea class="form-control" 
							name="txtAddress" 
							ng-model="frmRegistrationData.address" 
							tabindex="6"></textarea>
					</div>
					
					
					<div class="form-group">
						<label>Password <span class="c-requiredSign">*</span></label>
						<input type="password" class="form-control" 
							name="txtPassword" 
							ng-model="frmRegistrationData.password" 
							required 
							tabindex="7">
							
						<div class="c-errorMessages" ng-show="(frmRegisterNewUser.txtPassword.$invalid)">
							<p ng-show="(frmRegisterNewUser.txtPassword.$touched && frmRegisterNewUser.txtPassword.$error.required) || (frmRegisterNewUser.txtPassword.$error.required && isFormValid==false)">Password is required</p>
						</div>
					</div>
					<div class="form-group">
						<label>Confirm Password <span class="c-requiredSign">*</span></label>
						<input type="password" class="form-control" 
							name="txtConfirmPassword" 
							ng-model="frmRegistrationData.confirmPassword" 
							required 
							tabindex="8">
							
						<div class="c-errorMessages" ng-show="(frmRegisterNewUser.txtConfirmPassword.$invalid)">
							<p ng-show="(frmRegisterNewUser.txtConfirmPassword.$touched && frmRegisterNewUser.txtConfirmPassword.$error.required) || (frmRegisterNewUser.txtConfirmPassword.$error.required && isFormValid==false)">Confirm Password is required</p>					
						</div>
						<div class="c-errorMessages">
							<p ng-show="(frmRegisterNewUser.txtConfirmPassword.$touched && frmRegistrationData.confirmPassword != null) 
								&& (frmRegistrationData.confirmPassword != frmRegistrationData.password)">Confirm Password does not match with Password</p>
						</div>
					</div>
					
					<div class="form-group text-center">
						<button type="button" class="btn btn-info btn-rounded c-btnMain" id="btnRegisterNewUser" 
						ng-click="registerNewUser(frmRegisterNewUser, frmRegistrationData);" 
						ng-enter="registerNewUser(frmRegisterNewUser, frmRegistrationData);" 
						tabindex="9">Submit</button>
					</div>
				</form>	
			</div>
			
			<div class="clearfix"></div>	
		</div>
	</div>
</div>
<!-- /.row -->
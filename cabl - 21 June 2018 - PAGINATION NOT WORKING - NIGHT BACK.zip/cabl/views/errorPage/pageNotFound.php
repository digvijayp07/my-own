<div class="c-mutedMessage c-ht350 c-brad4">
	<span>
		<i class="flaticon-number"></i>
		<h3 class="text-uppercase">Page Not Found !</h3>
		<p class="m-b-30">You seem to be trying to find a way to home.</p>
		
		<div>
			<a ng-href="#/dashboard/" class="btn btn-info btn-rounded waves-effect waves-light m-b-40" ng-if="rsSessionActive">Back to home</a> 
			<a ng-href="#/login/" class="btn btn-info btn-rounded waves-effect waves-light m-b-40" ng-if="!rsSessionActive">Back to login</a>
		</div>
	</span>
</div>
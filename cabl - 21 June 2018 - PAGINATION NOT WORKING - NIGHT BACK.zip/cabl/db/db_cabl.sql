-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 20, 2018 at 02:22 PM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_cabl`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_choice_master`
--

CREATE TABLE `tbl_choice_master` (
  `chId` int(6) NOT NULL,
  `chName` varchar(150) NOT NULL,
  `chTypeId` int(6) NOT NULL,
  `chValue` varchar(150) DEFAULT NULL,
  `chDescription` varchar(1000) NOT NULL,
  `isActive` int(1) NOT NULL DEFAULT '1',
  `isDelete` int(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_choice_master`
--

INSERT INTO `tbl_choice_master` (`chId`, `chName`, `chTypeId`, `chValue`, `chDescription`, `isActive`, `isDelete`) VALUES
(1, 'User Type', 0, '', '', 1, 0),
(1001, 'Admin', 1, 'ADMN-', '', 1, 0),
(1002, 'Operator', 1, 'CABL-', '', 1, 0),
(1003, 'Customer', 1, 'CUST-', '', 1, 0),
(2, 'Country Code', 0, '', '', 1, 0),
(1004, 'India', 2, '+91', '', 1, 0),
(1005, 'USA', 2, '+2', '', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `id` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `userTypeId` int(6) NOT NULL,
  `isOnline` int(1) NOT NULL DEFAULT '0',
  `isActive` int(1) NOT NULL DEFAULT '0',
  `isDelete` int(1) NOT NULL DEFAULT '0',
  `createdDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `password`, `userTypeId`, `isOnline`, `isActive`, `isDelete`, `createdDate`) VALUES
('1', 'a8f5f167f44f4964e6c998dee827110c', 1001, 1, 1, 0, '2018-06-07 05:34:05'),
('3', 'a8f5f167f44f4964e6c998dee827110c', 1003, 0, 1, 0, '2018-06-13 07:47:42'),
('2', 'a8f5f167f44f4964e6c998dee827110c', 1002, 0, 1, 0, '2018-06-13 06:45:24');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users_info`
--

CREATE TABLE `tbl_users_info` (
  `id` varchar(50) NOT NULL,
  `firstName` varchar(50) DEFAULT NULL,
  `middleName` varchar(50) DEFAULT NULL,
  `lastName` varchar(50) DEFAULT NULL,
  `countryCode` varchar(5) DEFAULT NULL,
  `mobileNumber` bigint(12) DEFAULT NULL,
  `address` varchar(250) DEFAULT NULL,
  `createdDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` varchar(50) DEFAULT NULL,
  `modifiedDate` timestamp NULL DEFAULT NULL,
  `modifiedBy` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_users_info`
--

INSERT INTO `tbl_users_info` (`id`, `firstName`, `middleName`, `lastName`, `countryCode`, `mobileNumber`, `address`, `createdDate`, `createdBy`, `modifiedDate`, `modifiedBy`) VALUES
('1', 'Bhima', 'Riddhi', 'Infotainment', '+91', 1111111111, 'Kolhapur', '2018-06-07 00:04:05', '1', '2018-06-07 00:04:05', '1'),
('3', 'Digvijay', 'K', 'Patil', '+91', 9970804658, 'Fulewadi', '2018-06-13 02:17:42', '3', '2018-06-13 02:17:42', '3'),
('2', 'Dhananjay', 'M', 'Kesarkar', '+91', 1122334455, 'Fulewadi', '2018-06-13 01:15:24', '2', '2018-06-13 01:15:24', '2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_choice_master`
--
ALTER TABLE `tbl_choice_master`
  ADD PRIMARY KEY (`chId`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_users_info`
--
ALTER TABLE `tbl_users_info`
  ADD PRIMARY KEY (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

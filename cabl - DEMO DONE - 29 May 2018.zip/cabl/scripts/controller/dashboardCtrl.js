myApp.controller('dashboardCtrl', dashboardCtrl);

function dashboardCtrl($scope, $rootScope) {
	
	// set page title
    $rootScope.pageTitle = 'Dashboard';
	
	// set session and view type(login or after login).. so that related view is rendered
	$rootScope.setViewType('afterLogin');
	$rootScope.sessionActive = true;
	
	//// init
	init();
	function init() {
		initPlugins();
	}
	
}
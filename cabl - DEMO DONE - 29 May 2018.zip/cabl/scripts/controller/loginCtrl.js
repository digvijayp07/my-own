myApp.controller('loginCtrl', loginCtrl);

function loginCtrl($scope, $rootScope) {
	
	// set page title
    $rootScope.pageTitle = 'Login';	
	
	// set session and view type(login or after login).. so that related view is rendered
	$rootScope.setViewType('beforeLogin');
	$rootScope.sessionActive = false;
	
	//// init
	init();
	function init() {
		initPlugins();
	}
	
}
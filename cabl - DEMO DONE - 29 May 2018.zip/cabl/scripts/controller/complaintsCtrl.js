myApp.controller('complaintsCtrl', complaintsCtrl);

function complaintsCtrl($scope, $rootScope) {
	
	// set page title
    $rootScope.pageTitle = 'My Complaints';
	
	// set session and view type(login or after login).. so that related view is rendered
	$rootScope.setViewType('afterLogin');
	$rootScope.sessionActive = true;
	
	//// init
	init();
	function init() {
		initPlugins();
	}
	
}
myApp.controller('applicationCtrl', applicationCtrl);

function applicationCtrl($scope, $rootScope) {	
	// set page title
    $rootScope.pageTitle = 'Cabl Inc.';
	
	// set footer copyright
    $rootScope.footerCopyright = '&copy; 2018 Cabl Inc.';
	
	// set session true or false.. so that related view is rendered
	$rootScope.sessionActive;	
	
	$rootScope.setViewType = function (vt) {
		$rootScope.viewType = vt;
	}
	
	//// init
	init();
	function init() {
		initPlugins();
	}
}
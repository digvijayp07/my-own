// Create application controller and add dependency injection here
var myApp = angular.module('myApp', 
	[
		'ngSanitize', 
		'ngRoute'		
	]
);
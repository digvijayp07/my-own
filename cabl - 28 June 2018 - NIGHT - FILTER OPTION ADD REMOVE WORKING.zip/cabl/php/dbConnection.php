<?PHP

// connecting to mysql database : host name, username, password, db name
$con = mysqli_connect("localhost", "root", "", "db_cabl");

if (!$con)
{
	$resultArr2 = array();
	
	$resultArr2['statusCode'] = 400;
	$resultArr2['statusMessage'] = "Failed to connect to MySQL ".mysqli_connect_errno();
	
	
	print_r(json_encode($resultArr2));
	exit;
}

?>
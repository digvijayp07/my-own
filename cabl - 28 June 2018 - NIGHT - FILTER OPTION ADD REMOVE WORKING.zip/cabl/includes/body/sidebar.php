<div class="sidebar-nav slimscrollsidebar">	
	<ul class="nav" id="side-menu">
		<li style="padding: 70px 0 0;">
			<a ng-href="#/dashboard/" data-urls="#/dashboard" 
				class="waves-effect c-brad4"><i class="flaticon-dashboard" aria-hidden="true"></i>Dashboard</a>
		</li>
		
		
		<li>
			<a ng-href="#/myAccount/" data-urls="#/myAccount,#/myAccountEdit" 
				class="waves-effect c-brad4"><i class="flaticon-id-card" aria-hidden="true"></i>My Account</a>
		</li>
		<li>
			<a ng-href="#/myPackage/" data-urls="#/myPackage" 
				ng-if="rsLogin.rsUserSessionDetails.userTypeId == 1003"
				class="waves-effect c-brad4"><i class="flaticon-technology-1" aria-hidden="true"></i>My Package</a>
		</li>
		
		<li>
			<a ng-href="#/registration/" data-urls="#/registration" 
				ng-if="rsLogin.rsUserSessionDetails.userTypeId == 1001"
				class="waves-effect c-brad4"><i class="flaticon-id-card" aria-hidden="true"></i>Registration</a>
		</li>
		<li>
			<a ng-href="#/choiceMaster/" data-urls="#/choiceMaster" 
				ng-if="rsLogin.rsUserSessionDetails.userTypeId == 1001"
				class="waves-effect c-brad4"><i class="flaticon-technical-support" aria-hidden="true"></i>Choice Master</a>
		</li>
		
		
		<li>
			<a ng-href="#/myCustomers/" data-urls="#/myCustomers" 
				ng-if="rsLogin.rsUserSessionDetails.userTypeId == 1002"
				class="waves-effect c-brad4"><i class="flaticon-team" aria-hidden="true"></i>My Customers</a>
		</li>
		<li>
			<a ng-href="#/packageRequests/" data-urls="#/packageRequests" 
				ng-if="rsLogin.rsUserSessionDetails.userTypeId == 1002"
				class="waves-effect c-brad4"><i class="flaticon-technology-1" aria-hidden="true"></i>Package Requests</a>
		</li>
		
		<li>
			<a ng-href="#/myBills/" data-urls="#/myBills" 
				ng-if="rsLogin.rsUserSessionDetails.userTypeId == 1002 || rsLogin.rsUserSessionDetails.userTypeId == 1003"
				class="waves-effect c-brad4"><i class="flaticon-invoice" aria-hidden="true"></i>My Bills</a>
		</li>
		<li>
			<a ng-href="#/myComplaints/" data-urls="#/myComplaints" 
				ng-if="rsLogin.rsUserSessionDetails.userTypeId == 1002 || rsLogin.rsUserSessionDetails.userTypeId == 1003"
				class="waves-effect c-brad4"><i class="flaticon-speech-bubble" aria-hidden="true"></i>My Complaints</a>
		</li>
		
		
		<li>
			<a href="javascript:void(0);" ng-click="userLogout();" class="waves-effect c-brad4"><i class="flaticon-power-sign" aria-hidden="true"></i>Log Out</a>
		</li>

	</ul>	
</div>
<!-- LOADER -->
<div class="c-loader">
	<div class="c-loaderContent">
		<div class="c-loaderText">
			loading...
		</div>
	</div>
</div>
<!-- END LOADER -->


<span ng-bind-html="rsFooterCopyright"></span>

<div class="center text-muted">
	<small>Icon by Freepik from flaticon.com</small>
</div>
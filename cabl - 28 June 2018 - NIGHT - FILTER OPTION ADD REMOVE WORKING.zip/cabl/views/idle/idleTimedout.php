<div class="modal-header"> 
	<button type="button" class="close" ng-click="closeModal()">X</button> <!-- data-dismiss="modal" aria-hidden="true" -->
	<h4 class="modal-title text-info">
		<div>System Timed Out</div>
		<!--<div class="c-subModalHeading text-muted"></div>-->
	</h4>
</div>
<div class="modal-body">
	<div class="c-formModal">	
			
		<div class="c-mutedMessage c-ht250 c-brad4">
			<span>
				<i class="flaticon-time-left"></i>
				<p class="m-b-30">Your session is timed out. Please login again.</p>
			</span>
		</div>
	
	</div>	
</div>
<div class="modal-footer c-singleBtn">  
	<button type="button" class="btn btn-default c-btnCancel" 
				ng-click="closeModal()">Close</button>
</div>
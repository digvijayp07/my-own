<div class="c-loginHeading">
	<h3>Sign in</h3>
	<p>Welcome user.</p>
</div>
<div class="c-frmLogin">
	<form name="frmLogin" class="form-material" novalidate>
		<div class="form-group">
			<label>User ID <span class="c-requiredSign">*</span></label>
			<input type="text" class="form-control" placeholder="e.g. 00001234" 
				name="txtUserId" 
				ng-model="frmUserLoginData.userId" 
				required 				
				tabindex="1">
				
			<div class="c-errorMessages" ng-show="(frmLogin.txtUserId.$invalid)">				
				<p ng-show="(frmLogin.txtUserId.$touched && frmLogin.txtUserId.$error.required) || (frmLogin.txtUserId.$error.required && isFormValid==false)">User ID is required</p>
			</div>
		</div>
		<div class="form-group">
			<label>Password <span class="c-requiredSign">*</span></label>
			<input type="password" class="form-control" placeholder="**********" 
				name="txtPassword" 
				ng-model="frmUserLoginData.password" 
				required 
				tabindex="2">
				
			<div class="c-errorMessages" ng-show="(frmLogin.txtPassword.$invalid)">
				<p ng-show="(frmLogin.txtPassword.$touched && frmLogin.txtPassword.$error.required) || (frmLogin.txtPassword.$error.required && isFormValid==false)">Password is required</p>
			</div>
		</div>
		
		<div class="form-group text-center">
			<button type="button" class="btn btn-info btn-rounded c-btnMain" 
				ng-click="userLogin(frmLogin, frmUserLoginData);" 
				ng-enter="userLogin(frmLogin, frmUserLoginData);"
				tabindex="3">Login</button>
		</div>
		<div class="c-forgotPassword"><a ng-href="#/forgotPassword/" tabindex="4">Forgot password?</a> Don't worry.</div>
	</form>					
</div>

<div class="c-registrationLink">
	<a ng-href="#/registrationRequest/" class="btn btn-default btn-rounded">Regsiter with us</a>
</div>
<div class="c-loginHeading">
	<h3>Recover Password</h3>
	<p>Enter your User ID to reset your password.</p>
</div>
<div class="c-loginForm">
	<form class="form-material">
		<div class="form-group">
			<label>User ID</label>
			<input type="text" name="txtUserId" class="form-control" placeholder="e.g. 00001234">
		</div>
		<div class="form-group">
			<label>Mobile Number</label>
			<input type="text" name="txtMobileNumber" class="form-control" />
		</div>
		
		<div class="form-group text-center">
			<button type="submit" class="btn btn-info btn-rounded c-btnMain">Submit</button>
		</div>
		<div class="c-forgotPassword">Know your password? <a ng-href="#/login/">Sign in</a></div>
	</form>					
</div>
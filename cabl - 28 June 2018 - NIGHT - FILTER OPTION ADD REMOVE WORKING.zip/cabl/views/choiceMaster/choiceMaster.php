<div class="row bg-title">
	<div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
		<h4 class="page-title">Choice Master</h4> 
	</div>		
	<div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
		<!--<button class="btn btn-info btn-rounded pull-right" data-toggle="modal" data-target="#c-choiceMasterModalCreate">Create Choice Master</button>-->
		<button class="btn btn-info btn-rounded pull-right" ng-click="rsOpenModal('views/choiceMaster/choiceMasterModalCreate.php', 'choiceMasterCtrl', '', '')">
			<i class="flaticon-plus-symbol"></i> Create Choice Master
		</button>			
	</div>
</div>
<!-- /.row -->
<!-- .row -->
<div class="row">
	<div class="col-md-12 col-sm-12 col-xs-12">		
		<div class="white-box c-myBillsWrapper c-brad4 p-0">		
			
			
			<div class="c-tableFilters c-brad4" 
				ng-init="rsGetAllChoiceMastersList('');">	
				<div class="c-filterBtnGroup">
					<h5>
						Is Active?	
					</h5>					  
					<div class="btn-group" role="group">
						<button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						  Select					
							<span class="badge badge-info"
								ng-if="selectedOptions.isActive.length > 0" 
								ng-bind="selectedOptions.isActive.length"></span>
						  <span class="caret"></span>
						</button>
						<ul class="dropdown-menu">
						  <li>
							<label class="checkbox-inline">
								<input type="checkbox" name="txtFilIsActive[]" value="true" class="c-txtFilIsActive" 
									ng-checked="selectedOptions.isActive.indexOf(1) > -1"
									ng-click="addToFilterList('isActive', 1, 'Active');"> Yes
							</label>
						  </li>
						  <li>
							<label class="checkbox-inline">
								<input type="checkbox" name="txtFilIsActive[]" value="false" class="c-txtFilIsActive" 
									ng-checked="selectedOptions.isActive.indexOf(0) > -1"
									ng-click="addToFilterList('isActive', 0, 'In active');"> No
							</label>
						  </li>
						</ul>
					</div>
				</div>
				
				<div class="c-filterBtnGroup">
					<h5>
						Is Delete? 	
					</h5>					  
					<div class="btn-group" role="group">
						<button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						  Select					
							<span class="badge badge-info"
								ng-if="selectedOptions.isDelete.length > 0" 
								ng-bind="selectedOptions.isDelete.length"></span>
						  <span class="caret"></span>
						</button>
						<ul class="dropdown-menu">
						  <li>
							<label class="checkbox-inline">
								<input type="checkbox" name="txtFilIsDelete[]" value="true" class="c-txtFilIsDelete" 
									ng-checked="selectedOptions.isDelete.indexOf(1) > -1"
									ng-click="addToFilterList('isDelete', 1, 'Is Delete? : Yes');"> Yes
							</label>
						  </li>
						  <li>
							<label class="checkbox-inline">
								<input type="checkbox" name="txtFilIsDelete[]" value="false" class="c-txtFilIsDelete" 
									ng-checked="selectedOptions.isDelete.indexOf(0) > -1"
									ng-click="addToFilterList('isDelete', 0, 'Is Delete? : No');"> No
							</label>
						  </li>
						</ul>
					</div>
				</div>
				
				<div class="c-filterBtnGroup">
					<h5>
						Type
					</h5>					  
					<div class="btn-group" role="group">
						<button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						  Select					
							<span class="badge badge-info"
								ng-if="selectedOptions.chTypeId.length > 0" 
								ng-bind="selectedOptions.chTypeId.length"></span>
						  <span class="caret"></span>
						</button>
						<ul class="dropdown-menu">
						  <li>
							<label class="checkbox-inline">
								<input type="checkbox" name="txtFilChType[]" value="true" class="c-txtFilChType" 
									ng-checked="selectedOptions.chTypeId.indexOf(0) > -1"
									ng-click="addToFilterList('chTypeId', 0, 'Master');"> Master
							</label>
						  </li>
						  <li>
							<label class="checkbox-inline">
								<input type="checkbox" name="txtFilChType[]" value="true" class="c-txtFilChType" 
									ng-checked="selectedOptions.chTypeId.indexOf(1) > -1"
									ng-click="addToFilterList('chTypeId', 1, 'User Type');"> User Type
							</label>
						  </li>
						  <li>
							<label class="checkbox-inline">
								<input type="checkbox" name="txtFilChType[]" value="true" class="c-txtFilChType" 
									ng-checked="selectedOptions.chTypeId.indexOf(2) > -1"
									ng-click="addToFilterList('chTypeId', 2, 'Country Code');"> Country Code
							</label>
						  </li>
						</ul>
					</div>
				</div>
				
				<div class="c-filterBtnGroup c-filterBtnApplyClear">
					<button class="btn btn-info btn-sm btn-rounded" 
						ng-disabled="selectedOptionsCount == 0"
						ng-click="rsGetAllChoiceMastersList(selectedOptions);">Apply</button>
					<button class="btn btn-default btn-sm btn-rounded" 
						ng-disabled="selectedOptionsCount == 0"
						ng-click="clearFilterOptions();">Clear</button>
				</div>
				
				<!-- Filtered Options Display -->
				<div class="clearfix"></div>
				<div class="row">
					<div class="col-lg-12 col-md-12 c-filteredOptions" 
						ng-if="selectedOptionsCount > 0">
						<span class="badge badge-inverse c-filteredOption" 
							ng-repeat="data in selectedOptionsValues" 
							ng-click="addToFilterList(data.keyName, data.id,  data.value);">{{data.value}} <i class="flaticon-cancel"></i></span> 
					</div>
				</div>
			</div>
			
			
			<div class="table-responsive c-customTable" 
				ng-show="rsAllChoiceMastersListNgTblData.length > 0">
				<table class="table" ng-table="rsAllChoiceMastersListNgTbl">
					<tr ng-repeat="data in rsAllChoiceMastersListNgTblData"> <!--rsAllChoiceMastersList -->
						<td width="80" data-title="'ID'" sortable="'chId'">{{data.chId}}</td>
						<td width="250" data-title="'Name'" sortable="'chName'">
							{{data.chName}}						
						</td>
						<td width="150" data-title="'Type'" sortable="'chTypeName'">{{data.chTypeName}}</td>
						<td width="100" data-title="'Is Active?'" sortable="'isActiveInactiveText'">
							<span class="badge"
								ng-class="(data.isActive == 1) ? 'badge-success' : 'badge-danger'">
								{{data.isActiveInactiveText}}
							</span>
						</td>
						<td width="100" data-title="'Is Delete?'" sortable="'isDeleteText'">
							<span class="badge"
								ng-class="(data.isDelete == 0) ? 'badge-success' : 'badge-danger'">
								{{data.isDeleteText}}
							</span>
						</td>
						<td width="250" data-title="'Action'">
							<button class="btn btn-default btn-rounded text-info btn-xs" 
								ng-click="viewChoiceMasterDetailsById(data.chId);">
								<i class="flaticon-info"></i> View
							</button>
							<button class="btn btn-default btn-rounded text-info btn-xs" 
								ng-if="data.isDelete == 0" 
								ng-click="getChoiceMasterDetailsById(data.chId);">
								<i class="flaticon-edit"></i> Edit
							</button>								
							<button class="btn btn-default btn-rounded text-danger btn-xs" 
								ng-if="data.isDelete == 0" 
								ng-click="deleteChoiceMasterDetailsById(data.chId);">
								<i class="flaticon-trash"></i> Delete
							</button>
						</td>
					</tr>
				</table>				
			</div>
			
			<div class="c-mutedMessage c-ht350 c-brad4" 
				ng-show="rsAllChoiceMastersListNgTblData.length == 0">
				<span>
					<i class="flaticon-search-1"></i>
					<h3 class="text-uppercase">Records not found !</h3>
					<p class="m-b-30">It seem to be there are no records in database.</p>
				</span>
			</div>
					
		</div>
	</div>			
</div>
<!-- /.row -->



<!-- MODAL 
<div id="c-allInOneModal" class="modal fade c-customModal">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header"> 
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">X</button>
				<h4 class="modal-title text-info">0004 - Not receiving signals</h4>
			</div>
			<div class="modal-body">
				
				<div class="c-infoKeyValWrapper">					
					<div class="c-infoKeyValRow">
						<div class="c-infoKey col-md-6 col-sm-8 col-xs-12">Created On<br>28 May, 2018 @10:30 AM</div>
						<div class="c-infoVal col-md-6 col-sm-4 col-xs-12">
							<span class="badge badge-info">Open</span>
							<p><small>Some note goes here. Some note goes here.</small></p>
						</div>
					</div>
					<div class="c-infoKeyValRow">
						<div class="c-infoKey col-md-6 col-sm-8 col-xs-12">Updated On<br>28 May, 2018 @11:30 AM</div>
						<div class="c-infoVal col-md-6 col-sm-4 col-xs-12">
							<span class="badge badge-warning">In Progress</span>
							<p><small>Some note goes here. Some note goes here.</small></p>
						</div>
					</div>
					<div class="c-infoKeyValRow">
						<div class="c-infoKey col-md-6 col-sm-8 col-xs-12">Closed On<br>28 May, 2018 @12:05 PM</div>
						<div class="c-infoVal col-md-6 col-sm-4 col-xs-12">
							<span class="badge badge-success">Closed</span>
							<p><small>Some note goes here. Some note goes here.</small></p>
						</div>
					</div>					
				</div>			
				
			</div>
			<div class="modal-footer c-singleBtn">  
				<button type="button" class="btn btn-info c-btnAction" id="" data-dismiss="modal">Okay</button>
			</div>
		</div>
	</div>
</div>-->
<!-- END MODAL -->

<!-- CREATE COMPLAINT MODAL 
<div id="c-choiceMasterModalCreate" class="modal fade c-customModal">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header"> 
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">X</button>
				<h4 class="modal-title text-info">Create Choice Master</h4>
			</div>
			<div class="modal-body">
				
				<div class="c-formModal">
					<form class="form-horizontal form-material">
						<div class="form-group">
							<label class="col-md-3 col-sm-4 col-xs-12">Status</label>
							<div class="col-md-9 col-sm-8 col-xs-12">
								<select class="form-control form-control-line">
									<option value="">Select</option>
									<option value="">Not receiving signals</option>
									<option value="">Cable wire broken down due to rain storm</option>
									<option value="">Set top box settings changed mistakenly</option>
									<option value="">Set top box not working</option>
									<option value="">Picture is not clear</option>									
								</select>						
							</div>
						</div>
						<div class="form-group">
							<label class="col-md-3 col-sm-4 col-xs-12">Note</label>
							<div class="col-md-9 col-sm-8 col-xs-12">
								<textarea class="form-control form-control-line" name="" rows="10"></textarea>						
							</div>
						</div>
					</form>
				</div>
				
			</div>
			<div class="modal-footer c-singleBtn">  
				<button type="button" class="btn btn-info c-btnAction" id="" data-dismiss="modal">Submit</button>
			</div>
		</div>
	</div>
</div>-->
<!-- END CREATE COMPLAINT MODAL -->

<!-- UPDATE COMPLAINT MODAL 
<div id="c-choiceMasterModalEdit" class="modal fade c-customModal">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header"> 
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">X</button>
				<h4 class="modal-title text-info">0004 - Not receiving signals</h4>
			</div>
			<div class="modal-body">
				
				<div class="c-formModal">
					<form class="form-horizontal form-material">
						<div class="form-group">
							<label class="col-md-3 col-sm-4 col-xs-12">Status</label>
							<div class="col-md-9 col-sm-8 col-xs-12">
								<select class="form-control form-control-line">
									<option value="">Select</option>
									<option value="">Not receiving signals</option>
									<option value="">Cable wire broken down due to rain storm</option>
									<option value="">Set top box settings changed mistakenly</option>
									<option value="">Set top box not working</option>
									<option value="">Picture is not clear</option>									
								</select>						
							</div>
						</div>
						<div class="form-group">
							<label class="col-md-3 col-sm-4 col-xs-12">Note</label>
							<div class="col-md-9 col-sm-8 col-xs-12">
								<textarea class="form-control form-control-line" name="" rows="10"></textarea>						
							</div>
						</div>
					</form>
				</div>
				
			</div>
			<div class="modal-footer c-singleBtn">  
				<button type="button" class="btn btn-info c-btnAction" id="" data-dismiss="modal">Submit</button>
			</div>
		</div>
	</div>
</div>-->
<!-- END UPDATE COMPLAINT MODAL -->
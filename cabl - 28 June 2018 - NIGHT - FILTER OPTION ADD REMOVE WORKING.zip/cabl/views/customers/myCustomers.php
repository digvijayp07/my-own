<div class="row bg-title">
	<div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
		<h4 class="page-title">My Customers</h4> 
	</div>		
	<!--<div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
		<a href="https://wrappixel.com/templates/ampleadmin/" target="_blank" class="btn btn-danger pull-right m-l-20 hidden-xs hidden-sm waves-effect waves-light">Upgrade to Pro</a>			
	</div>-->
</div>
<!-- /.row -->
<!-- .row -->
<div class="row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		
		<div class="c-customTabsWrapper">
			<ul class="nav nav-tabs">
				<li class="active">
					<a href="javascript:void(0);" class="c-bradTopOnly4" data-toggle="tab" data-target="#tabCustActive">
						Active <span class="badge badge-success">1500</span>
					</a>
				</li>
				<li>
					<a href="javascript:void(0);" class="c-bradTopOnly4" data-toggle="tab" data-target="#tabCustInactive">
						In active <span class="badge badge-danger">200</span>
					</a>
				</li>
			</ul>
			<div class="tab-content">
			
				<div id="tabCustActive" class="tab-pane fade in active">		
					<div class="white-box c-myBillsWrapper c-brad4 p-0">			
						<div class="c-tableFilters c-brad4">														
							<div class="c-filterBtnGroup c-btnGroupMonth">
								<h5>Year</h5>
								<div class="btn-group" role="group">
								  <button type="button" class="btn btn-default btn-sm"><i class="fa fa-angle-left"></i></button>
								  <div class="btn-group" role="group">
									<button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
									  May
									  <span class="caret"></span>
									</button>
									<ul class="dropdown-menu">
									  <li><a href="#">January</a></li>
									  <li><a href="#">February</a></li>
									  <li><a href="#">March</a></li>
									  <li><a href="#">April</a></li>
									  <li><a href="#">May</a></li>
									  <li><a href="#">June</a></li>
									  <li><a href="#">July</a></li>
									  <li><a href="#">August</a></li>
									  <li><a href="#">September</a></li>
									  <li><a href="#">October</a></li>
									  <li><a href="#">November</a></li>
									  <li><a href="#">December</a></li>
									</ul>
								  </div>
								  <div class="btn-group" role="group">
									<button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
									  2018
									  <span class="caret"></span>
									</button>
									<ul class="dropdown-menu">
									  <li><a href="#">2015</a></li>
									  <li><a href="#">2016</a></li>
									  <li><a href="#">2017</a></li>
									  <li><a href="#" class="active">2018</a></li>
									</ul>
								  </div>
								  <button type="button" class="btn btn-default btn-sm"><i class="fa fa-angle-right"></i></button>
								</div>
							</div>
							<div class="c-filterBtnGroup c-btnGroupMonth">
								<h5>Package</h5>
								<div class="btn-group" role="group">
									<button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
									  Select
									  <span class="caret"></span>
									</button>
									<ul class="dropdown-menu">
									  <li><a href="#" class="active">Standard</a></li>
									  <li><a href="#">HD</a></li>
									</ul>
								</div>
							</div>
							<div class="c-filterBtnGroup c-btnGroupMonth">
								<h5>Colony / Lane</h5>
								<div class="btn-group" role="group">
									<button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
									  Select
									  <span class="caret"></span>
									</button>
									<ul class="dropdown-menu">
									  <li><a href="#" class="active">Ingawale Colony</a></li>
									  <li><a href="#">Chenani Colony</a></li>
									  <li><a href="#">Sarvesh Park</a></li>
									  <li><a href="#">Ajinkya Tarun Mandal</a></li>
									</ul>
								</div>
							</div>
							<div class="c-filterBtnGroup c-searchFilter">
								<h5>Search</h5>
								<form class="form-horizontal form-material1">
									<div class="form-group m-0">
										<input type="text" name="" class="form-control" placeholder="Search by ID, Customer Name or Date" />										
									</div>
								</form>
							</div>
						</div>
						
						<div class="table-responsive c-customTable">
							<table class="table">
								<thead>
									<tr>
										<th width="100">Cust. ID.</th>
										<th width="150">Customer Name</th>
										<th width="150">Colony / Lane</th>
										<th width="200">Mobile No.</th>
										<th width="100">Package</th>										
										<th width="150">Date Registered</th>
										<th width="150">Action</th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td width="100">00001234</td>
										<td width="150">
											<div>Rana Da V.</div>
											<div><button class="btn btn-link btn-sm text-info p-0" data-toggle="popover-x" data-target="#myPopover1" data-placement="top">Details</button></div>
										</td>
										<td width="150">Ingawale Colony</td>
										<td width="200">
											<a href="tel:+91 9955885544">+91 9955885544</a>
										</td>
										<td width="100">Standard</td>
										<td width="150">29 May, 2018</td>
										<td width="150">
											<button class="btn btn-danger btn-sm btn-rounded">Make Inactive</button>
										</td>
									</tr>
								</tbody>
							</table>
						</div>			
					</div>		
				</div>
				
				
				<div id="tabCustInactive" class="tab-pane fade">
		
					<div class="white-box c-myBillsWrapper c-brad4 p-0">			
						<div class="c-tableFilters c-brad4">														
							<div class="c-filterBtnGroup c-btnGroupMonth">
								<h5>Year</h5>
								<div class="btn-group" role="group">
								  <button type="button" class="btn btn-default btn-sm"><i class="fa fa-angle-left"></i></button>
								  <div class="btn-group" role="group">
									<button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
									  May
									  <span class="caret"></span>
									</button>
									<ul class="dropdown-menu">
									  <li><a href="#">January</a></li>
									  <li><a href="#">February</a></li>
									  <li><a href="#">March</a></li>
									  <li><a href="#">April</a></li>
									  <li><a href="#">May</a></li>
									  <li><a href="#">June</a></li>
									  <li><a href="#">July</a></li>
									  <li><a href="#">August</a></li>
									  <li><a href="#">September</a></li>
									  <li><a href="#">October</a></li>
									  <li><a href="#">November</a></li>
									  <li><a href="#">December</a></li>
									</ul>
								  </div>
								  <div class="btn-group" role="group">
									<button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
									  2018
									  <span class="caret"></span>
									</button>
									<ul class="dropdown-menu">
									  <li><a href="#">2015</a></li>
									  <li><a href="#">2016</a></li>
									  <li><a href="#">2017</a></li>
									  <li><a href="#" class="active">2018</a></li>
									</ul>
								  </div>
								  <button type="button" class="btn btn-default btn-sm"><i class="fa fa-angle-right"></i></button>
								</div>
							</div>
							<div class="c-filterBtnGroup c-btnGroupMonth">
								<h5>Package</h5>
								<div class="btn-group" role="group">
									<button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
									  Select
									  <span class="caret"></span>
									</button>
									<ul class="dropdown-menu">
									  <li><a href="#" class="active">Standard</a></li>
									  <li><a href="#">HD</a></li>
									</ul>
								</div>
							</div>
							<div class="c-filterBtnGroup c-btnGroupMonth">
								<h5>Colony / Lane</h5>
								<div class="btn-group" role="group">
									<button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
									  Select
									  <span class="caret"></span>
									</button>
									<ul class="dropdown-menu">
									  <li><a href="#" class="active">Ingawale Colony</a></li>
									  <li><a href="#">Chenani Colony</a></li>
									  <li><a href="#">Sarvesh Park</a></li>
									  <li><a href="#">Ajinkya Tarun Mandal</a></li>
									</ul>
								</div>
							</div>
							<div class="c-filterBtnGroup c-searchFilter">
								<h5>Search</h5>
								<form class="form-horizontal form-material1">
									<div class="form-group m-0">
										<input type="text" name="" class="form-control" placeholder="Search by ID, Customer Name or Date" />										
									</div>
								</form>
							</div>
						</div>
						
						<div class="table-responsive c-customTable">
							<table class="table">
								<thead>
									<tr>
										<th width="100">Cust. ID.</th>
										<th width="150">Customer Name</th>
										<th width="150">Colony / Lane</th>
										<th width="200">Mobile No.</th>
										<th width="100">Package</th>										
										<th width="150">Date Registered</th>
										<th width="150">Date Canceled</th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td width="100">00001234</td>
										<td width="150">
											<div>Rana Da V.</div>
											<div><button class="btn btn-link btn-sm text-info p-0" data-toggle="popover-x" data-target="#myPopover1" data-placement="top">Details</button></div>
										</td>
										<td width="150">Ingawale Colony</td>
										<td width="200">
											<a href="tel:+91 9955885544">+91 9955885544</a>
										</td>
										<td width="100">Standard</td>
										<td width="150">29 May, 2017</td>
										<td width="150">31 May, 2018</td>
									</tr>
								</tbody>
							</table>
						</div>			
					</div>		
				</div>
				
				
				
			</div>
		</div>
		
	</div>
</div>
<!-- /.row -->


<!-- MODAL BILL DETAILS -->
<div id="c-allInOneModal" class="modal fade c-customModal">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header"> 
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">X</button>
				<h4 class="modal-title text-info">Bill Details (May-0005)</h4>
			</div>
			<div class="modal-body">
				
				<div class="c-infoKeyValWrapper">
					<div class="c-infoKeyValRow">
						<div class="c-infoKey col-md-3 col-sm-4 col-xs-12">Date &amp; Time</div>
						<div class="c-infoVal col-md-9 col-sm-8 col-xs-12">29 Apr, 2018 @10:30 AM</div>
					</div>
					<div class="c-infoKeyValRow">
						<div class="c-infoKey col-md-3 col-sm-4 col-xs-12">Payment Mode</div>
						<div class="c-infoVal col-md-9 col-sm-8 col-xs-12">Debit Card</div>
					</div>
					<div class="c-infoKeyValRow">
						<div class="c-infoKey col-md-3 col-sm-4 col-xs-12">Transaction ID</div>
						<div class="c-infoVal col-md-9 col-sm-8 col-xs-12">123456789</div>
					</div>					
					<div class="c-infoKeyValRow">
						<div class="c-infoKey col-md-3 col-sm-4 col-xs-12">Bank Name</div>
						<div class="c-infoVal col-md-9 col-sm-8 col-xs-12">HDFC Bank Ltd.</div>
					</div>
					<div class="c-infoKeyValRow">
						<div class="c-infoKey col-md-3 col-sm-4 col-xs-12">Card's Last 4 Digit</div>
						<div class="c-infoVal col-md-9 col-sm-8 col-xs-12">XXXX-XXXX-XXXX-5458</div>
					</div>
					<div class="c-infoKeyValRow">
						<div class="c-infoKey col-md-3 col-sm-4 col-xs-12">Transaction Status</div>
						<div class="c-infoVal col-md-9 col-sm-8 col-xs-12"><span class="badge badge-success">Success</span></div>
					</div>
					<div class="c-infoKeyValRow">
						<div class="c-infoKey col-md-3 col-sm-4 col-xs-12">Amount</div>
						<div class="c-infoVal col-md-9 col-sm-8 col-xs-12">250.00</div>
					</div>
				</div>
				
				
			</div>
			<div class="modal-footer c-singleBtn">  
				<button type="button" class="btn btn-info c-btnAction" id="" data-dismiss="modal">Okay</button>
			</div>
		</div>
	</div>
</div>
<!-- END MODAL BILL DETAILS -->



<!-- MODAL PAY MY BILL -->
<div id="c-payMyBillModal" class="modal fade c-customModal">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header"> 
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">X</button>
				<h4 class="modal-title text-info">Bill Payment (June-0006)</h4>
			</div>
			<div class="modal-body">
				
				<div class="c-infoKeyValWrapper">
					<div class="c-infoKeyValRow">
						<div class="c-infoKey col-md-3 col-sm-4 col-xs-12">Amount</div>
						<div class="c-infoVal col-md-9 col-sm-8 col-xs-12">250.00</div>
					</div>
				</div>

				<div class="c-formModal">
					<form class="form-horizontal form-material">
						<div class="form-group">
							<label class="col-md-3 col-sm-4 col-xs-12">Payment Mode</label>
							<div class="col-md-9 col-sm-8 col-xs-12">
								<label class="radio-inline m-r-10"><input type="radio" name="txtPayMode" value="cash" data-target-div="c-pmodeCashDiv" class="c-txtPayMode"> Cash</label>
								<label class="radio-inline m-r-10"><input type="radio" name="txtPayMode" value="debit card" data-target-div="c-pmodeDebitDiv" class="c-txtPayMode"> Debit Card</label>
								<label class="radio-inline m-r-10"><input type="radio" name="txtPayMode" value="credit card" data-target-div="c-pmodeCreditDiv" class="c-txtPayMode"> Credit Card</label>								
							</div>
						</div>
						
						<div class="c-pmodeDiv c-pmodeCashDiv">
							<div class="form-group">
								<label class="col-md-3 col-sm-4 col-xs-12">Amount</label>
								<div class="col-md-9 col-sm-8 col-xs-12">
									<input type="text" name="txtPaidAmount" class="form-control" value="250.00" readonly="readonly" disabled="disabled">								
								</div>
							</div>
						</div>
						
						<div class="c-pmodeDiv c-pmodeDebitDiv">
							<div class="form-group">
								<label class="col-md-3 col-sm-4 col-xs-12">Bank Name</label>
								<div class="col-md-9 col-sm-8 col-xs-12">
									<input type="text" name="txtBankName" class="form-control">								
								</div>
							</div>
							<div class="form-group">
								<label class="col-md-3 col-sm-4 col-xs-12">Card Holder Name</label>
								<div class="col-md-9 col-sm-8 col-xs-12">
									<input type="text" name="txtCardHolderName" placeholder="As per card" class="form-control">								
								</div>
							</div>
							<div class="form-group">
								<label class="col-md-3 col-sm-4 col-xs-12">Card Type</label>
								<div class="col-md-9 col-sm-8 col-xs-12">
									<select class="form-control form-control-line">
										<option value="">Select</option>
										<option value="">American Express</option>
										<option value="">RuPay</option>
										<option value="">Master Card</option>
										<option value="">Visa</option>										
									</select>						
								</div>
							</div>
							<div class="form-group">
								<label class="col-md-3 col-sm-4 col-xs-12">Card Number</label>
								<div class="col-md-9 col-sm-8 col-xs-12">
									<div class="col-md-3 col-sm-3 col-xs-3 p-l-0 c-cardNumberInput">
										<input type="text" name="txtCardNo1" class="form-control" placeholder="XXXX" maxlength="4">
									</div>
									<div class="col-md-3 col-sm-3 col-xs-3 p-l-0 c-cardNumberInput">
										<input type="text" name="txtCardNo2" class="form-control" placeholder="XXXX" maxlength="4">
									</div>
									<div class="col-md-3 col-sm-3 col-xs-3 p-l-0 c-cardNumberInput">
										<input type="text" name="txtCardNo3" class="form-control" placeholder="XXXX" maxlength="4">
									</div>
									<div class="col-md-3 col-sm-3 col-xs-3 p-l-0 c-cardNumberInput">
										<input type="text" name="txtCardNo4" class="form-control" placeholder="XXXX" maxlength="4">
									</div>
								</div>
							</div>
							<div class="form-group">
								<label class="col-md-3 col-sm-4 col-xs-12">Expiry Date</label>
								<div class="col-md-9 col-sm-8 col-xs-12">
									<div class="col-md-2 col-sm-3 col-xs-3 p-l-0 c-expiryDateInput">
										<input type="text" name="txtExpiryMonth" class="form-control" placeholder="XX" maxlength="2">
									</div>
									<div class="col-md-2 col-sm-3 col-xs-3 p-l-0">
										<input type="text" name="txtExpiryYear" class="form-control" placeholder="XX" maxlength="2">
									</div>
								</div>
							</div>
							<div class="form-group">
								<label class="col-md-3 col-sm-4 col-xs-12">CVV Code</label>
								<div class="col-md-3 col-sm-4 col-xs-4">
									<input type="password" name="txtCvv" class="form-control" placeholder="XXX" maxlength="3">
								</div>
							</div>							
						</div>
						
						<div class="c-pmodeDiv c-pmodeCreditDiv">
							<div class="form-group">
								<label class="col-md-3 col-sm-4 col-xs-12">Bank Name</label>
								<div class="col-md-9 col-sm-8 col-xs-12">
									<input type="text" name="txtBankName" class="form-control">								
								</div>
							</div>
							<div class="form-group">
								<label class="col-md-3 col-sm-4 col-xs-12">Card Holder Name</label>
								<div class="col-md-9 col-sm-8 col-xs-12">
									<input type="text" name="txtCardHolderName" placeholder="As per card" class="form-control">								
								</div>
							</div>
							<div class="form-group">
								<label class="col-md-3 col-sm-4 col-xs-12">Card Type</label>
								<div class="col-md-9 col-sm-8 col-xs-12">
									<select class="form-control form-control-line">
										<option value="">Select</option>
										<option value="">American Express</option>
										<option value="">RuPay</option>
										<option value="">Master Card</option>
										<option value="">Visa</option>										
									</select>						
								</div>
							</div>
							<div class="form-group">
								<label class="col-md-3 col-sm-4 col-xs-12">Card Number</label>
								<div class="col-md-9 col-sm-8 col-xs-12">
									<div class="col-md-3 col-sm-3 col-xs-3 p-l-0 c-cardNumberInput">
										<input type="text" name="txtCardNo1" class="form-control" placeholder="XXXX" maxlength="4">
									</div>
									<div class="col-md-3 col-sm-3 col-xs-3 p-l-0 c-cardNumberInput">
										<input type="text" name="txtCardNo2" class="form-control" placeholder="XXXX" maxlength="4">
									</div>
									<div class="col-md-3 col-sm-3 col-xs-3 p-l-0 c-cardNumberInput">
										<input type="text" name="txtCardNo3" class="form-control" placeholder="XXXX" maxlength="4">
									</div>
									<div class="col-md-3 col-sm-3 col-xs-3 p-l-0 c-cardNumberInput">
										<input type="text" name="txtCardNo4" class="form-control" placeholder="XXXX" maxlength="4">
									</div>
								</div>
							</div>
							<div class="form-group">
								<label class="col-md-3 col-sm-4 col-xs-12">Expiry Date</label>
								<div class="col-md-9 col-sm-8 col-xs-12">
									<div class="col-md-2 col-sm-3 col-xs-3 p-l-0 c-expiryDateInput">
										<input type="text" name="txtExpiryMonth" class="form-control" placeholder="XX" maxlength="2">
									</div>
									<div class="col-md-2 col-sm-3 col-xs-3 p-l-0">
										<input type="text" name="txtExpiryYear" class="form-control" placeholder="XX" maxlength="2">
									</div>
								</div>
							</div>
							<div class="form-group">
								<label class="col-md-3 col-sm-4 col-xs-12">CVV Code</label>
								<div class="col-md-3 col-sm-4 col-xs-4">
									<input type="password" name="txtCvv" class="form-control" placeholder="XXX" maxlength="3">
								</div>
							</div>							
						</div>
						
						<div class="form-group">
							<label class="col-md-3 col-sm-4 col-xs-12">Narration</label>
							<div class="col-md-9 col-sm-8 col-xs-12">
								<input type="text" name="txtNarration" class="form-control" value="">								
							</div>
						</div>
						
						<div class="form-group">
							<label class="col-md-3 col-sm-4 col-xs-12">Paid By</label>
							<div class="col-md-9 col-sm-8 col-xs-12">
								<input type="text" name="txtPaidBy" class="form-control" value="Rana Da">								
							</div>
						</div>
					</form>
				</div>
				
			</div>
			<div class="modal-footer c-singleBtn">  
				<button type="button" class="btn btn-info c-btnAction" id="" data-dismiss="modal">Pay Now</button>
			</div>
		</div>
	</div>
</div>
<!-- END MODAL PAY MY BILL -->


<!-- PopoverX content -->
<div id="myPopover1" class="popover popover-x popover-default c-customPopover c-brad12">
	<div class="arrow"></div>
	<h3 class="popover-header popover-title c-bradTopOnly12">
		<!--<span class="close pull-right" data-dismiss="popover-x">&times;</span>-->
		Mr. Rana Da Vasagadekar
	</h3>
	<div class="popover-body popover-content">		
		<div class="c-infoKeyValWrapper">					
			<div class="c-infoKeyValRow">
				<div class="c-infoKey col-md-4 col-sm-4 col-xs-12">Cust. ID.</div>
				<div class="c-infoVal col-md-8 col-sm-8 col-xs-12"><span>00001234</span></div>
			</div>
			<div class="c-infoKeyValRow">
				<div class="c-infoKey col-md-4 col-sm-4 col-xs-12">Address</div>
				<div class="c-infoVal col-md-8 col-sm-8 col-xs-12">121, B Ward, Vasagade. Tal - Karvir. Dist - Kolhapur</div>
			</div>
			<div class="c-infoKeyValRow">
				<div class="c-infoKey col-md-4 col-sm-4 col-xs-12">Colony / Lane / Ward</div>
				<div class="c-infoVal col-md-8 col-sm-8 col-xs-12">Ingawale Colony</div>
			</div>
			<div class="c-infoKeyValRow">
				<div class="c-infoKey col-md-4 col-sm-4 col-xs-12">Mobile No.</div>
				<div class="c-infoVal col-md-8 col-sm-8 col-xs-12"><a href="tel:+919955885544">+91 9955885544</a></div>
			</div>					
		</div>		
	</div>	
	<div class="popover-footer c-bradBottomOnly12">
		<button type="button" class="btn btn-sm btn-default btn-bordered btn-rounded text-info" data-dismiss="popover-x">Close</button>
	</div>
</div>
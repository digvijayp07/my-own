<div class="row bg-title">
	<div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
		<h4 class="page-title">My Package</h4> 
	</div>		
	<div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
		<button class="btn btn-danger btn-rounded pull-right">Cancel Subscription</button>		
	</div>
</div>
<!-- /.row -->

<!-- .row -->
<div class="row hidden">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="c-mutedMessage error-body c-ht350 c-brad4">
			<span>
				<i class="flaticon-laptop"></i>
				<h3>Hello user,</h3>
				<p>Your <strong>Cancel Subsription</strong> request has been sent to cabel operator. </p>
				<p>To continue our service, contact your cabel operator now.</p>
			</span>
		</div>
	</div>
</div>


<!-- .row -->
<div class="row">
	<div class="col-md-4 col-md-offset-2 col-sm-6 col-xs-12">
		<div class="white-box c-userPackageBox c-userPackageSelected c-brad4">
			<div class="c-upHead text-center">
				<div class="c-upIcon">
					<i class="flaticon-technology-1 text-info"></i>
				</div>
				<h3 class="c-upPackageName text-info">Premium</h3>
				<h4 class="c-upPackagePrice">Rs. 300</h4>
				<h6 class="c-upPackageDuration text-muted">per month</h6>
			</div>
			<div class="c-upContent text-center">				
				<ul>
					<li>This package contains all channels + all HD channels. Experience true HD quality with us.</li>
				</ul>
			</div>
			<div class="c-upFooter text-center">
				<button class="btn btn-info btn-rounded">Selected</button>
			</div>
		</div>
	</div>

	<div class="col-md-4 col-sm-6 col-xs-12">
		<div class="white-box c-userPackageBox c-brad4">			
			<div class="c-upHead text-center">
				<div class="c-upIcon text-info">
					<i class="flaticon-technology"></i>
				</div>
				<h3 class="c-upPackageName text-info">Standard</h3>
				<h4 class="c-upPackagePrice">Rs. 200</h4>
				<h6 class="c-upPackageDuration text-muted">per month</h6>
			</div>
			<div class="c-upContent text-center">				
				<ul>
					<li>This package contains all standard channels.</li>
				</ul>
			</div>
			<div class="c-upFooter text-center">
				<button class="btn btn-default btn-rounded">Purchase Now</button>
				<button class="btn btn-warning btn-rounded">Request Sent</button>
			</div>
		</div>
	</div>
</div>
<!-- /.row -->
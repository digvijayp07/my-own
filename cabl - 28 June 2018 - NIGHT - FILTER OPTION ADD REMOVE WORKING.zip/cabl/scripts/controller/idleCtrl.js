myApp.controller('idleCtrl', idleCtrl);

function idleCtrl($scope, $rootScope, $http, $location, localStorageService, $timeout, myConfig, $uibModal, Idle, Keepalive, IdleLocalStorage) {	
	
		
	//--------------------------------------------------------------//
	//****************** COMMON FUNCTIONS *********************//
	//------------------------------------------------------------//	
	$scope.cancelModal = function(){
		if($scope.$dismiss) {
			$scope.$dismiss('cancel');
		}
	};
	$scope.closeModal = function(){
		if($scope.$close) {
			$scope.$close();
		}		 
	};
	//------------------------------------------------------------//	
	
	
	$scope.started = false;	
	$scope.$on('IdleStart', function() {				
		$scope.closeModal();
		$rootScope.rsOpenModal('views/idle/idleWarning.php', 'idleCtrl', '', '');
	});

	$scope.$on('IdleEnd', function() {
		$scope.closeModal();
	});	
	
	$scope.$on('IdleTimeout', function() {
		$scope.closeModal();		
		if($scope.$close) {			
			$scope.closeModal();
			$rootScope.rsOpenModal('views/idle/idleTimedout.php', 'idleCtrl', '', ''); 	
			IdleLocalStorage.remove('expiry');	
			$scope.started = false;
			
			// do logout
			$scope.userLogout();
		}
	});

	$scope.start = function() {
		$scope.closeModal();
		Idle.watch();
		$scope.started = true;
	};

	$scope.stop = function() {
		$scope.closeModal();
		Idle.unwatch();
		$scope.started = false;
	};
	
}
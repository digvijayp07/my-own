myApp.controller('modalInstanceCtrl', modalInstanceCtrl);

function modalInstanceCtrl($scope, $rootScope, $http, $location, localStorageService, $timeout, myConfig) {	
	
	// set page title
    $rootScope.rsPageTitle = 'My Package';
	
	// set session and view type(login or after login).. so that related view is rendered
	$rootScope.rsSetViewType('afterLogin');
	$rootScope.rsSessionActive = true;
	
	//console.log('Modal Instance Controller');
	//// init
	init();
	function init() {
		initPlugins();
		
		// check session
		$timeout(function() {
			$rootScope.rsCheckSessionExists();
		}, 0);
	}
	
	
	//--------------------------------------------------------------//
	//****************** CLOSE CANCEL MODAL *********************//
	//------------------------------------------------------------//
	$scope.cancelModal = function(){
		$scope.$dismiss('cancel');
	};
}
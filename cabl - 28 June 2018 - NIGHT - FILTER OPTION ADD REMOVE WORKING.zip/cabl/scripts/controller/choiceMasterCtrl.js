myApp.controller('choiceMasterCtrl', choiceMasterCtrl);

function choiceMasterCtrl($scope, $rootScope, $http, $location, localStorageService, $timeout, myConfig, $uibModal, Idle, Keepalive, IdleLocalStorage, NgTableParams, $filter) {	
	
	// set page title
    $rootScope.rsPageTitle = 'Choice Master';
	
	// set session and view type(login or after login).. so that related view is rendered
	$rootScope.rsSetViewType('afterLogin');
	$rootScope.rsSessionActive = true;
	
	// set scope variables
	$scope.frmChoiceMasterData = {};	
	if(Object.keys($rootScope.rsModalTempData).length != 0) {
		$scope.frmChoiceMasterData = $rootScope.rsGetmyModalData();	
		$rootScope.rsModalTempData = {};		
	}	
	
	// filter options
	$scope.selectedOptions = {};	
	$scope.selectedOptions.isActive = [];
	$scope.selectedOptions.isDelete = [];
	$scope.selectedOptions.chTypeId = [];
	$scope.selectedOptionsCount = 0;
	$scope.selectedOptionsValues = [];
			
	//console.log('Choice Master Controller');
	//// init
	init();
	function init() {
		initPlugins();
		
		// check session
		$timeout(function() {
			$rootScope.rsCheckSessionExists();
		}, 0);
	}
	
	//--------------------------------------------------------------//
	//****************** COMMON FUNCTIONS *********************//
	//------------------------------------------------------------//	
	$scope.cancelModal = function(){
		if($scope.$dismiss) {
			$scope.$dismiss('cancel');
		}
	};
	$scope.closeModal = function(){
		if($scope.$close) {
			$scope.$close();
		}		 
	};
	//------------------------------------------------------------//

	//--------------------------------------------------------------//
	//****************** FILTER *********************//
	//------------------------------------------------------------//	
	$scope.addToFilterList = function(keyName, id, value){			
		switch(keyName) {
			case 'isActive' :
				var idx = $scope.selectedOptions.isActive.indexOf(id);
				
				if (idx > -1) {	// is currently selected 
					$scope.selectedOptions.isActive.splice(idx, 1);
					removeFromSelectedOptionsValues($scope.selectedOptionsValues, keyName, value);
				}				
				else { // is newly selected 
					$scope.selectedOptions.isActive.push(id);
					$scope.selectedOptionsValues.push({keyName: keyName, value: value, id: id}); /*{keyName: keyName, value: value, id: id}*/
				}
			break;
			
			case 'isDelete' :
				var idx = $scope.selectedOptions.isDelete.indexOf(id);
				
				if (idx > -1) {	// is currently selected
					$scope.selectedOptions.isDelete.splice(idx, 1);
					removeFromSelectedOptionsValues($scope.selectedOptionsValues, keyName, value);
				}				
				else {	// is newly selected
					$scope.selectedOptions.isDelete.push(id);
					$scope.selectedOptionsValues.push({keyName: keyName, value: value, id: id});
				}
			break;
			
			case 'chTypeId' :
				var idx = $scope.selectedOptions.chTypeId.indexOf(id);
				
				if (idx > -1) {	// is currently selected
					$scope.selectedOptions.chTypeId.splice(idx, 1);
					removeFromSelectedOptionsValues($scope.selectedOptionsValues, keyName, value);
				}				
				else {	// is newly selected
					$scope.selectedOptions.chTypeId.push(id);
					$scope.selectedOptionsValues.push({keyName: keyName, value: value, id: id});
				}
			break;
		}
		$scope.selectedOptionsCount = getSelectedOptionsCount();
	};	
	
	function removeFromSelectedOptionsValues(myArray, keyName, value) {
		for(var i=0 ; i < myArray.length; i++) {
			if(myArray[i].value == value) {
				console.log(myArray[i]);
				myArray.splice(i, 1);
			}
		}		
		$scope.selectedOptionsValues = myArray;		
	}	
	function getSelectedOptionsCount() {
		var log = 0;
		angular.forEach($scope.selectedOptions, function(value, key) {			
			if($scope.selectedOptions[key].length > 0) {				
				log = parseInt(log) + parseInt($scope.selectedOptions[key].length);
			}			
		}, log);
		
		if(log == 0) {
			// call get call 
			$rootScope.rsGetAllChoiceMastersList('');
		}
		return log;
	}
	// Clear filter options
	$scope.clearFilterOptions = function(){
		// filter options
		$scope.selectedOptions = {};	
		$scope.selectedOptions.isActive = [];
		$scope.selectedOptions.isDelete = [];
		$scope.selectedOptions.chTypeId = [];
		$scope.selectedOptionsCount = 0;
		$scope.selectedOptionsValues = [];
		
		// call get call 
		$rootScope.rsGetAllChoiceMastersList('');
	};
	//------------------------------------------------------------//
	
	//--------------------------------------------------------------//
	//****************** CREATE EDIT DELETE VIEW GET CHOICE MASTER *********************//
	//------------------------------------------------------------//	
	$scope.choiceMasterCreateEdit = function(formName, formData) {				
		$scope.isFormValid = false;		
		if(formName.$valid) {			
			$scope.isFormValid = true;						
			$http({
				url: 'php/choiceMaster.php', 
				method: "POST",
				data: {
					httpRequest: 'createEditChoiceMaster',					
					id: formData.chId,
					name: formData.chName,
					typeId: formData.chTypeId,
					value: (formData.chValue ? formData.chValue : ''),
					description: (formData.chDescription ? formData.chDescription : ''),
					isActive: formData.isActive
				},
				headers : {
					'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
				}
			})
			.success(function(data){
				//console.log(data);
				
				if(data.statusCode == 200) {
					alertify.success(data.statusMessage);
					
					// reset form data
					$scope.frmChoiceMasterData = angular.copy({});
					formName.$setPristine();
					formName.$setUntouched();
					formName.$rollbackViewValue();

					//close modal
					$timeout(function() {
						$scope.$close();
						$rootScope.rsGetAllChoiceMastersList('');
					}, 500);
				}				
				if(data.statusCode == 400) {
					alertify.error(data.statusMessage);
				}
				
			});
		}
		else {
			$scope.isFormValid = false;
		}
		
	};
	
	$scope.viewChoiceMasterDetailsById = function(id) {
		$http({
			url: 'php/choiceMaster.php', 
			method: "GET", 
			dataType: 'json',
			params: {
				httpRequest: 'viewChoiceMasterDetailsById',
				id: id
			}
		})
		.success(function(data){
			//console.log(data);
									
			if(data.statusCode == 200) {
				$rootScope.rsRemoveNonData(data[0], ['statusCode', 'statusMessage']);
				
				//open modal
				$timeout(function() {
					$scope.frmChoiceMasterData = $rootScope.rsOpenModal('views/choiceMaster/choiceMasterModalView.php', 'choiceMasterCtrl', data[0], 'frmChoiceMasterData');
					$scope.frmChoiceMasterData = $rootScope.rsObjectToArray($scope.frmChoiceMasterData);
				}, 500);
			}
			if(data.statusCode == 400) {
				alertify.error(data.statusMessage);
			}
			
		});
	};
	
	$scope.getChoiceMasterDetailsById = function(id) {
		$http({
			url: 'php/choiceMaster.php', 
			method: "GET",
			dataType: 'json',
			params: {
				httpRequest: 'getChoiceMasterDetailsById',
				id: id
			}
		})
		.success(function(data){
			//console.log(data);
									
			if(data.statusCode == 200) {
				$rootScope.rsRemoveNonData(data[0], ['statusCode', 'statusMessage']);
				
				//open modal
				$timeout(function() {
					$scope.frmChoiceMasterData = $rootScope.rsOpenModal('views/choiceMaster/choiceMasterModalCreate.php', 'choiceMasterCtrl', data[0], 'frmChoiceMasterData');
					$scope.frmChoiceMasterData = $rootScope.rsObjectToArray($scope.frmChoiceMasterData);
				}, 500);
			}
			if(data.statusCode == 400) {
				alertify.error(data.statusMessage);
			}
			
		});
	};
	
	$scope.deleteChoiceMasterDetailsById = function(id) {
		alertify.confirm("Confirm", "Are you sure, you want to delete this record?", 
			function() {			
				//console.log('Ok');			
		
				$http({
					url: 'php/choiceMaster.php', 
					method: "DELETE",
					params: {
						httpRequest: 'deleteChoiceMasterDetailsById',
						id: id
					}
				})
				.success(function(data){
					//console.log(data);
											
					if(data.statusCode == 200) {				
						alertify.success(data.statusMessage);
						
						$rootScope.rsGetAllChoiceMastersList('');
					}			
					if(data.statusCode == 400) {
						alertify.error(data.statusMessage);
					}
					
				});
			}, 
			function() {
				//console.log('Cancel');
			}
		);
	};
	//--------------------------------------------------------------//

	
		
}
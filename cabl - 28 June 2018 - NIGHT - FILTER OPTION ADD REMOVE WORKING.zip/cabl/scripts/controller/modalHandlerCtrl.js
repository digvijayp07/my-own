myApp.factory('modalService', ['$uibModal', function($uibModal, $scope, $rootScope) {

	return {
		openGenericModal: function(templateLink, controllerName, someDataObject, objectName) {			
						
			var modalObj = $uibModal.open({
				templateUrl: templateLink,
				backdrop: 'static',
				windowClass: 'c-customModal animated slideInDown',
				controller: controllerName,
				
				/*function($scope,$modalInstance){
					$scope.ok = function(id){
						//Process OK Button Click
						$modalInstance.close(); 
					},
					$scope.cancel = function(){
						$modalInstance.dismiss('cancel');
					}
				},*/
				
				size: 'md',
				keyboard: true
				/*,
				resolve: {
					someData: function () {
						console.log(someDataObject);
					}
				}*/
			});
			
			//modalObj.opened.then(function() {					
				//setTimeout(function() {
					
					//console.log(someDataObject);
					//return someDataObject;
				//}, 2000);				
			//});
		}
	};
	
}]);
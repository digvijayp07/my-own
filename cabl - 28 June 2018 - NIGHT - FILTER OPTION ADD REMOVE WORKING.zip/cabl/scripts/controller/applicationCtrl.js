myApp.controller('applicationCtrl', applicationCtrl);

function applicationCtrl($scope, $rootScope, $http, $location, localStorageService, $timeout, myConfig, $uibModal, Idle, Keepalive, IdleLocalStorage, ngTableParams, $filter) {	
	// set page title
    $rootScope.rsPageTitle = 'Cabl Inc.';
	
	// set footer copyright
    $rootScope.rsFooterCopyright = '&copy; 2018 Cabl Inc.';
	
	// set session true or false.. so that related view is rendered
	$rootScope.rsSessionActive;	
	$rootScope.rsLogin = {};
	$rootScope.rsLogin.rsUserSessionDetails = {};
	
	$rootScope.rsSetViewType = function (vt) {
		$rootScope.rsViewType = vt;
	}
	
	// common values
	$scope.common = {};
	$scope.common.ngTablePageCount = 5;
	$scope.common.ngTablePaginationCount = [5, 10, 20, 25];
	
	// set scope variables
	$rootScope.rsAllChoiceMastersList = {};
	$rootScope.rsAllActiveMastersOnly = {};
	$rootScope.rsAllActiveUserTypes = {};
	$rootScope.rsAllActiveCountryCodes = {};
	$rootScope.rsModalTempData = {};
	
		
	//console.log('Application Controller');
	
	
	//// init
	init();
	function init() {
		initPlugins();
		
		// check session
		$timeout(function() {
			$rootScope.rsCheckSessionExists();
		}, 0);
	}
	
	//--------------------------------------------------------------//
	//***************** Check Session Exists *******************//
	//------------------------------------------------------------//
	$rootScope.rsCheckSessionExists = function(){
		if(localStorageService.get("lsUserDetails") == null || localStorageService.get("lsUserDetails") == undefined) {
			//console.log(myConfig.baseRouteUrl+'login');
			$location.path('/login');			
		}
		else {
			$rootScope.rsLogin.rsUserSessionDetails = localStorageService.get("lsUserDetails");
		}
	};
	//------------------------------------------------------------//
	
	
	//--------------------------------------------------------------//
	//****************** COMMON FUNCTIONS *********************//
	//------------------------------------------------------------//	
	$scope.cancelModal = function(){
		if($scope.$dismiss) {
			$scope.$dismiss('cancel');
		}
	};
	$scope.closeModal = function(){
		if($scope.$close) {
			$scope.$close();
		}		 
	};
	//------------------------------------------------------------//
	
	//--------------------------------------------------------------//
	//***************** User Logout *******************//
	//------------------------------------------------------------//
	$scope.userLogout = function() {		
		$http({
			url: 'php/userLogin.php', 
			method: "POST",
			data: {
					httpRequest: 'userLogout',
					userId: $rootScope.rsLogin.rsUserSessionDetails.id					
			},
			headers : {
					'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
			}
		})
		.success(function(data){	
			//console.log(data);
			if(data.statusCode == 200) {
				alertify.success(data.statusMessage);
				
				$timeout(function() {
					$location.path( "/login" );	
					
					// clear local storage, clear root scope variable
					$rootScope.rsLogin.rsUserSessionDetails = {};
					localStorageService.clearAll();
					// session idle clear and unwatch
					IdleLocalStorage.remove('expiry');
					Idle.unwatch();
					$scope.started = false;
				}, 1000);
			}
			
			if(data.statusCode == 400) {
				alertify.error(data.statusMessage);
			}
		});		
	}
	//--------------------------------------------------------------//	
	
	
	
	
	/* ================ GLOBAL FUNCTIONS ================ */
	//--------------------------------------------------------------//
	//***************** ENCODE DECODE HTTP URL *******************//
	//------------------------------------------------------------//
    $rootScope.rsEncodeUrl = function (input) {
		var keyStr = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
		// Create Base64 Object
		var Base64={_keyStr:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",encode:function(e){var t="";var n,r,i,s,o,u,a;var f=0;e=Base64._utf8_encode(e);while(f<e.length){n=e.charCodeAt(f++);r=e.charCodeAt(f++);i=e.charCodeAt(f++);s=n>>2;o=(n&3)<<4|r>>4;u=(r&15)<<2|i>>6;a=i&63;if(isNaN(r)){u=a=64}else if(isNaN(i)){a=64}t=t+this._keyStr.charAt(s)+this._keyStr.charAt(o)+this._keyStr.charAt(u)+this._keyStr.charAt(a)}return t},_utf8_encode:function(e){e=e.replace(/rn/g,"n");var t="";for(var n=0;n<e.length;n++){var r=e.charCodeAt(n);if(r<128){t+=String.fromCharCode(r)}else if(r>127&&r<2048){t+=String.fromCharCode(r>>6|192);t+=String.fromCharCode(r&63|128)}else{t+=String.fromCharCode(r>>12|224);t+=String.fromCharCode(r>>6&63|128);t+=String.fromCharCode(r&63|128)}}return t}}

		// Define the string
		var string = ''+input+'';

		// Encode the String
		var encodedString = Base64.encode(string);
		return encodedString;		
	}
	$rootScope.rsDecodeUrl = function (input) {
		var keyStr = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
		// Create Base64 Object
		var Base64={_keyStr:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",decode:function(e){var t="";var n,r,i;var s,o,u,a;var f=0;e=e.replace(/[^A-Za-z0-9]/g,"");while(f<e.length){s=this._keyStr.indexOf(e.charAt(f++));o=this._keyStr.indexOf(e.charAt(f++));u=this._keyStr.indexOf(e.charAt(f++));a=this._keyStr.indexOf(e.charAt(f++));n=s<<2|o>>4;r=(o&15)<<4|u>>2;i=(u&3)<<6|a;t=t+String.fromCharCode(n);if(u!=64){t=t+String.fromCharCode(r)}if(a!=64){t=t+String.fromCharCode(i)}}t=Base64._utf8_decode(t);return t},_utf8_decode:function(e){var t="";var n=0;var r=c1=c2=0;while(n<e.length){r=e.charCodeAt(n);if(r<128){t+=String.fromCharCode(r);n++}else if(r>191&&r<224){c2=e.charCodeAt(n+1);t+=String.fromCharCode((r&31)<<6|c2&63);n+=2}else{c2=e.charCodeAt(n+1);c3=e.charCodeAt(n+2);t+=String.fromCharCode((r&15)<<12|(c2&63)<<6|c3&63);n+=3}}return t}}

		// Define the string
		var string = ''+input+'';

		// Encode the String
		var decodedString = Base64.decode(string);
		
		return decodedString;
		
	}
	//--------------------------------------------------------------//
	
	//--------------------------------------------------------------//
	//***************** OPEN MODAL *******************//
	//------------------------------------------------------------//
	$rootScope.rsOpenModal = function(templateLink, controllerName, objectData, objectName){		
		$rootScope.rsModalTempData = objectData;
		var modalObj = $uibModal.open({
			templateUrl: templateLink,
			backdrop: 'static',
			windowClass: 'c-customModal animated slideInDown',
			controller: controllerName,
			scope: $scope,
			
			/*function($scope,$modalInstance){
				$scope.ok = function(id){
					//Process OK Button Click
					$modalInstance.close(); 
				},
				$scope.cancel = function(){
					$modalInstance.dismiss('cancel');
				}
			},*/
			
			size: 'md',
			keyboard: true
			/*,
			resolve: {
				resolved: function () {
					console.log('close');
				}
			}*/
		});

		/*modalObj.opened.then(function() {					
			setTimeout(function() {
				objectData = $rootScope.rsModalTempData;
				returnFunction(objectData);
			}, 2000);				
		});			
		function returnFunction(objectData) {			
			return objectData;
		}*/
		
		return objectData;
    };	
	$rootScope.rsGetmyModalData = function() {		
		return $rootScope.rsModalTempData;
	}
	//--------------------------------------------------------------//
	
	//--------------------------------------------------------------//
	//***************** Object To Array *******************//
	//------------------------------------------------------------//
	$rootScope.rsObjectToArray = function(obj) {
		  if (typeof(obj) === 'object') {
			var keys = Object.keys(obj);
			var allObjects = keys.every(x => typeof(obj[x]) === 'object');
			if (allObjects) {
			  return keys.map(x => $rootScope.rsObjectToArray(obj[x]));
			} else {
			  var o = {};
			  keys.forEach(x => {
				o[x] = $rootScope.rsObjectToArray(obj[x])
			  });
			  return o;
			}
		  } 
		  else {
			return obj;
		  }
	}
	//--------------------------------------------------------------//
	
	//--------------------------------------------------------------//
	//***************** Return pagination count *******************//
	//------------------------------------------------------------//
	//Generic method for getting proper Table Pagesize list
	$rootScope.rsGetTablePagesizeList = function (totalRecordCount) {
		var tablePagesizeList = [];
		var higherPageSizeFound = false;
		angular.forEach($scope.common.ngTablePaginationCount, function (value, index) {
		  if (!higherPageSizeFound) {
			  if (value < totalRecordCount)
				  tablePagesizeList.push(value);
			  else if (value >= totalRecordCount) {
				  tablePagesizeList.push(value);
				  higherPageSizeFound = true;
			  }
		  }
		});

		if (tablePagesizeList.length == 1)
		  tablePagesizeList = [];

		return tablePagesizeList;
	};
	//--------------------------------------------------------------//	
	
	//--------------------------------------------------------------//
	//***************** Remove Status Code & Messages From Data *******************//
	//------------------------------------------------------------//
	$rootScope.rsRemoveNonData = function(allData, removeThis) {		
		for(var i = 0; i < removeThis.length; i++) {
			delete allData[removeThis[i]];			
		}
	}
	//--------------------------------------------------------------//	
		
	//---------------------------------------------------------------//
	//***************** Get All From Choice Master *****************//
	//-------------------------------------------------------------//
	$rootScope.rsGetAllChoiceMastersList = function(filterOptionsObject) {
		$http({
			url: 'php/choiceMaster.php', 
			method: "GET",
			dataType: 'json',
			params: {	
				httpRequest: 'getAllChoiceMastersList', 
				filterOptions: filterOptionsObject
			}
		})
		.success(function(data){
			//console.log(data);
			if(data.statusCode == 200) {				
				$rootScope.rsRemoveNonData(data, ['statusCode', 'statusMessage']);	
				$rootScope.rsAllChoiceMastersList = $rootScope.rsObjectToArray(data);	
				
				// populate ng-table
				populateChoiceMastersTableList($rootScope.rsAllChoiceMastersList);				
			}
			if(data.statusCode == 400) {
				$rootScope.rsRemoveNonData(data, ['statusCode', 'statusMessage']);
				$rootScope.rsAllChoiceMastersList = $rootScope.rsObjectToArray(data);
				$scope.rsAllChoiceMastersListNgTblData = $rootScope.rsAllChoiceMastersList;
			}
		});		
	};
	function populateChoiceMastersTableList(inputData) {
		if (angular.isDefined($rootScope.rsAllChoiceMastersListNgTbl)) {
			$rootScope.rsAllChoiceMastersListNgTbl.reload();
		}
		//else {
			$rootScope.rsAllChoiceMastersListNgTbl = new ngTableParams({
				page: 1,
				count: $scope.common.ngTablePageCount
			}, {
				counts: $rootScope.rsGetTablePagesizeList(inputData.length),
				total: inputData.length, 
				getData: function ($defer, params) {
					//console.log(params);
					$scope.rsAllChoiceMastersListNgTblData = params.sorting() ? $filter('orderBy')(inputData, params.orderBy()) : inputData;
					$scope.rsAllChoiceMastersListNgTblData = $scope.rsAllChoiceMastersListNgTblData.slice((params.page() - 1) * params.count(), params.page() * params.count());  
					$defer.resolve($scope.rsAllChoiceMastersListNgTblData);
				}
			});
		//}
	}
	//--------------------------------------------------------------//
	
	//---------------------------------------------------------------//
	//***************** Get All From Choice Master Having chTypeId *****************//
	//-------------------------------------------------------------//
	$rootScope.rsGetAllActiveChoiceMasters = function(chType, modelName) {
		$http({
			url: 'php/choiceMaster.php', 
			method: "GET", 
			dataType: 'json',
			params: {	
				httpRequest: 'getAllActiveChoiceMastersHavingChType', 
				chTypeId: chType
			}
		})
		.success(function(data){
			//console.log(data);	
			
			if(data.statusCode == 200) {
				$rootScope.rsRemoveNonData(data, ['statusCode', 'statusMessage']);		
							
				switch(modelName) {
					case 'rsAllActiveUserTypes':
						$rootScope.rsAllActiveUserTypes = $rootScope.rsObjectToArray(data);
						break;
						
					case 'rsAllActiveCountryCodes':
						$rootScope.rsAllActiveCountryCodes = $rootScope.rsObjectToArray(data);
						break;	

					case 'rsAllActiveMastersOnly':
						$rootScope.rsAllActiveMastersOnly = $rootScope.rsObjectToArray(data);
						break;
				}
			}
		});		
	};
	//--------------------------------------------------------------//	
	
	//---------------------------------------------------------------//
	//***************** SET USER TYPE PREFIX *****************//
	//-------------------------------------------------------------//	
	$rootScope.rsSetUserTypePrefix = function() {		 		
		$rootScope.rsUserTypePrefix = $('.c-txtUserTypeId option:selected').attr('data-user-prefix');	
	};
	//--------------------------------------------------------------//
}
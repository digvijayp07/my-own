myApp.config(['KeepaliveProvider', 'IdleProvider', function(KeepaliveProvider, IdleProvider) {
  IdleProvider.idle(7200);
  IdleProvider.timeout(3600);
  
  //KeepaliveProvider.interval(15); 
}]);

myApp.run(['Idle', 'localStorageService', function(Idle, localStorageService) {
	if(localStorageService.get("lsUserDetails") != null || localStorageService.get("lsUserDetails") != undefined) {
		Idle.watch();
	}
}]);
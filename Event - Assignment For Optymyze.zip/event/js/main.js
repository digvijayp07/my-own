/* On scroll - Hide top navbar */
window.addEventListener('scroll',function(e) {    
    calculateScroll(this);
});

function calculateScroll(thisScroll) {
	if(thisScroll.pageYOffset > 70) {
    	// means scroll down
    	document.getElementById("c-customNavbar").classList.add("c-hideTopbar");
    }
    else {
    	// means scroll up and reaching top
    	document.getElementById("c-customNavbar").classList.remove("c-hideTopbar");
    }
}
// Also call on page load
calculateScroll(window);